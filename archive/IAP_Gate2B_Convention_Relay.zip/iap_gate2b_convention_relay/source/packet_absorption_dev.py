import sys,copy,json,struct
from pathlib import Path
import numpy as np, torch
from torch import nn
from torch.nn import functional as F
sys.path.insert(0,'/mnt/data/fly_gate3_source/unzip/fly_doom_gate3')
from internal_model import InternalFly
from convention_relay_v2_dev import ST,TY,state,target,INPUTS,ACTIONS,STAGES,CONTEXTS

TEACHER_GRAPH='/mnt/data/fly_gate3_source/unzip/fly_doom_gate3/data/graph_211.npz'
STUDENT_GRAPHS={7102:'/mnt/data/fly_gate3_source/unzip/fly_doom_gate3/data/graph_223.npz',7103:'/mnt/data/fly_gate3_source/unzip/fly_doom_gate3/data/graph_239.npz'}

class Tiny(nn.Module):
    def __init__(self):super().__init__();self.l1=nn.Linear(6,8);self.l2=nn.Linear(8,2)
    def forward(self,x):return self.l2(torch.tanh(self.l1(x)))

def teacher_q():
    m=InternalFly(TEACHER_GRAPH,7101,inputs=6,actions=2);m.load_state_dict(torch.load('/mnt/data/convention_v2_teacher.pt',weights_only=True));m.eval()
    with torch.no_grad():q=m(torch.tensor(ST)).numpy()
    # center and scale each state to carry preference rather than arbitrary offset
    q=q-q.mean(1,keepdims=True);scale=np.maximum(np.abs(q).max(),1e-6);q=q/scale
    return q.astype(np.float32),float(scale)

def train_packet(q):
    torch.manual_seed(44);net=Tiny();opt=torch.optim.Adam(net.parameters(),lr=.03);x=torch.tensor(ST);y=torch.tensor(q)
    for i in range(3000):
        p=net(x);loss=F.mse_loss(p,y);opt.zero_grad();loss.backward();opt.step()
    with torch.no_grad():acc=float((net(x).argmax(1).numpy()==TY).mean());mse=float(F.mse_loss(net(x),y))
    return net,acc,mse

def quant_tensor(a):
    a=np.asarray(a,np.float32);s=max(float(np.max(np.abs(a)))/127,1e-8);q=np.clip(np.round(a/s),-127,127).astype(np.int8);return q,s

def make_packet(net):
    arrays=[];scales=[]
    for p in [net.l1.weight,net.l1.bias,net.l2.weight,net.l2.bias]:
        q,s=quant_tensor(p.detach().numpy());arrays.append(q);scales.append(s)
    raw=b'IAPCV2\0'+struct.pack('<4f',*scales)+b''.join(a.tobytes() for a in arrays)
    return raw,arrays,scales

def packet_predict(arrays,scales,x):
    w1=arrays[0].astype(np.float32)*scales[0];b1=arrays[1].astype(np.float32)*scales[1];w2=arrays[2].astype(np.float32)*scales[2];b2=arrays[3].astype(np.float32)*scales[3]
    return np.tanh(np.asarray(x)@w1.T+b1)@w2.T+b2

def eval_model(m):
    with torch.no_grad():p=m(torch.tensor(ST)).argmax(1).numpy();acc=float(np.mean(p==TY));seq=[]
    for c in range(8):seq.append(np.all(p[c*3:(c+1)*3]==TY[c*3:(c+1)*3]))
    return acc,float(np.mean(seq))

def absorb(flyseed,graph,packet_q,wrong=False,budgets=(0,16,32,64,128,256),seed=7000):
    torch.manual_seed(seed+flyseed);m=InternalFly(graph,flyseed,inputs=6,actions=2);opt=torch.optim.Adam(m.parameters(),lr=.03);rng=np.random.default_rng(seed+flyseed)
    results=[];seen=0
    results.append((0,*eval_model(m)))
    samples=rng.integers(len(ST),size=max(budgets))
    for i,idx in enumerate(samples,1):
        x=torch.tensor(ST[idx]);t=np.asarray(packet_q[idx]).copy()
        if wrong:t=t[::-1].copy()
        # local cultural exposure: only this observed state + packet values
        pred=m(x).flatten();loss=F.mse_loss(pred,torch.tensor(t,dtype=torch.float32));opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();m.project()
        if i in budgets:results.append((i,*eval_model(m)))
    return results,m

def main():
    torch.set_num_threads(1);q,scale=teacher_q();net,acc,mse=train_packet(q);raw,arrays,scales=make_packet(net);pq=packet_predict(arrays,scales,ST)
    packet_acc=float(np.mean(pq.argmax(1)==TY));Path('/mnt/data/convention_teacher.iap').write_bytes(raw)
    summary={'packet_bytes':len(raw),'teacher_scale':scale,'float_packet_acc':acc,'quant_packet_acc':packet_acc,'packet_mse':mse,'students':{}}
    print('packet',len(raw),'bytes float acc',acc,'quant acc',packet_acc,'mse',mse,flush=True)
    for fs,g in STUDENT_GRAPHS.items():
        good,_=absorb(fs,g,pq,False);bad,_=absorb(fs,g,pq,True);summary['students'][str(fs)]={'culture':good,'wrong':bad};print(fs,'good',good,'wrong',bad,flush=True)
    Path('/mnt/data/convention_absorption_dev.json').write_text(json.dumps(summary,indent=2))
if __name__=='__main__':main()
