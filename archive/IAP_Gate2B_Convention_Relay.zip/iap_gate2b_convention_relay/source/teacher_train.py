import copy,json,sys
from collections import deque
from pathlib import Path
import numpy as np, torch
from torch.nn import functional as F
sys.path.insert(0,'/mnt/data/fly_gate3_source/unzip/fly_doom_gate3')
from internal_model import InternalFly
INPUTS=6;ACTIONS=2;STAGES=3;CONTEXTS=8

def target(ctx,stage):
    b=np.array([(ctx>>2)&1,(ctx>>1)&1,ctx&1],dtype=np.int64)
    if stage==0:return int(b[0]^b[1]^b[2])          # parity
    if stage==1:return int(b[0]^b[2])               # xor ends
    return int((b.sum()>=2))                        # majority

def state(ctx,stage):
    b=np.array([(ctx>>2)&1,(ctx>>1)&1,ctx&1],np.float32)*2-1
    s=np.zeros(3,np.float32);s[stage]=1
    return np.r_[b,s].astype(np.float32)
ST=np.stack([state(c,s) for c in range(8) for s in range(3)])
TY=np.array([target(c,s) for c in range(8) for s in range(3)])

class Learner:
    def __init__(self,graph,fly_seed,seed,lr=.03,epsilon=.25):
        torch.manual_seed(seed);self.model=InternalFly(graph,fly_seed,inputs=INPUTS,actions=ACTIONS);self.opt=torch.optim.Adam(self.model.parameters(),lr=lr)
        self.pr=np.random.default_rng(seed+11);self.rr=np.random.default_rng(seed+12);self.eps=epsilon;self.replay=deque(maxlen=256);self.pending=deque();self.updates=0
    def choose(self,x,epsilon=None):
        with torch.inference_mode():q=self.model(torch.tensor(x)).flatten()
        e=self.eps if epsilon is None else epsilon;u=self.pr.random();ra=int(self.pr.integers(2));return ra if u<e else int(q.argmax())
    def deliver(self,event):
        st,a,r=event;self.replay.append((st,a,r));batch=[self.replay[j] for j in self.rr.integers(len(self.replay),size=min(32,len(self.replay)))]
        ss=torch.tensor(np.stack([b[0] for b in batch]));aa=torch.tensor([b[1] for b in batch]);rr=torch.tensor([b[2] for b in batch])
        pred=self.model(ss).gather(1,aa[:,None]).flatten();loss=F.mse_loss(pred,rr);self.opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(self.model.parameters(),1.);self.opt.step();self.model.project();self.updates+=1
    def observe(self,x,a,r):
        self.pending.append((x.copy(),a,float(r)))
        if len(self.pending)>3:self.deliver(self.pending.popleft())
    def flush(self):
        while self.pending:self.deliver(self.pending.popleft())
    def eval(self):
        with torch.inference_mode():q=self.model(torch.tensor(ST)).numpy();p=q.argmax(1)
        acc=float(np.mean(p==TY));seq=[]
        for c in range(8):seq.append(np.all(p[c*3:(c+1)*3]==TY[c*3:(c+1)*3]))
        return dict(action_accuracy=acc,sequence_success=float(np.mean(seq)),contexts_mastered=int(sum(seq)))

def run(trials=6144):
    torch.set_num_threads(1);L=Learner('/mnt/data/fly_gate3_source/unzip/fly_doom_gate3/data/graph_211.npz',7101,5201);cps={0:L.eval()};print(0,cps[0],flush=True)
    rng=np.random.default_rng(9101);check={256,512,1024,2048,3072,4096,6144}
    for t in range(1,trials+1):
        c=int(rng.integers(8));s=int(rng.integers(3));x=state(c,s);a=L.choose(x);r=1. if a==target(c,s) else -1.;L.observe(x,a,r)
        if t in check:cps[t]=L.eval();print(t,cps[t],flush=True)
    L.flush();cps['final']=L.eval();print('final',cps['final'],flush=True)
    Path('/mnt/data/convention_v2_teacher_dev.json').write_text(json.dumps(cps,indent=2));torch.save(L.model.state_dict(),'/mnt/data/convention_v2_teacher.pt')
if __name__=='__main__':run()
