import sys,json,copy,argparse
from collections import deque
from pathlib import Path
import numpy as np, torch
from torch.nn import functional as F
sys.path.insert(0,'/mnt/data/fly_gate3_source/unzip/fly_doom_gate3')
from internal_model import InternalFly
sys.path.insert(0,'/mnt/data')
from convention_relay_v2_dev import ST,TY,target
from convention_packet_absorb import teacher_q,train_packet,make_packet,packet_predict
STUDENTS={7102:'/mnt/data/fly_gate3_source/unzip/fly_doom_gate3/data/graph_223.npz',7103:'/mnt/data/fly_gate3_source/unzip/fly_doom_gate3/data/graph_239.npz'}
CULTURE_BUDGET=256;LOCAL_TRIALS=512;CHECKPOINTS=[0,32,64,128,256,384,512];REPS=[101,202,303]

def ev(m):
    with torch.no_grad():p=m(torch.tensor(ST)).argmax(1).numpy()
    acc=float(np.mean(p==TY));seq=np.array([np.all(p[c*3:(c+1)*3]==TY[c*3:(c+1)*3]) for c in range(8)])
    return {'action_accuracy':acc,'sequence_success':float(seq.mean()),'contexts_mastered':int(seq.sum())}

def init(fs,g,rep):torch.manual_seed(100000+fs+rep);return InternalFly(g,fs,inputs=6,actions=2)

def absorb(m,pq,fs,rep,wrong):
    opt=torch.optim.Adam(m.parameters(),lr=.03);rng=np.random.default_rng(200000+fs*10+rep);buf=[]
    for _ in range(CULTURE_BUDGET):
        idx=int(rng.integers(len(ST)));t=pq[idx].copy();t=t[::-1].copy() if wrong else t
        buf.append((ST[idx].copy(),t.copy()));ids=rng.integers(len(buf),size=min(32,len(buf)))
        xs=torch.tensor(np.stack([buf[j][0] for j in ids]));ts=torch.tensor(np.stack([buf[j][1] for j in ids]));loss=F.mse_loss(m(xs),ts)
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();m.project()

def local(m,fs,rep):
    opt=torch.optim.Adam(m.parameters(),lr=.03);rr=np.random.default_rng(400000+fs*10+rep);env=np.random.default_rng(700000+rep)
    state_idx=env.integers(len(ST),size=LOCAL_TRIALS);u=env.random(LOCAL_TRIALS);ra=env.integers(2,size=LOCAL_TRIALS);noise=env.random(LOCAL_TRIALS)<.1
    replay=deque(maxlen=256);pending=deque();rows={0:ev(m)}
    def deliver(e):
        st,a,r=e;replay.append((st,a,r));batch=[replay[j] for j in rr.integers(len(replay),size=min(32,len(replay)))]
        ss=torch.tensor(np.stack([b[0] for b in batch]));aa=torch.tensor([b[1] for b in batch]);rw=torch.tensor([b[2] for b in batch]);pred=m(ss).gather(1,aa[:,None]).flatten();loss=F.mse_loss(pred,rw)
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();m.project()
    for t in range(LOCAL_TRIALS):
        idx=int(state_idx[t]);st=ST[idx];c=idx//3;s=idx%3
        with torch.no_grad():q=m(torch.tensor(st)).flatten();a=int(ra[t]) if u[t]<.25 else int(q.argmax())
        r=1. if a==target(c,s) else -1.;r=-r if noise[t] else r;pending.append((st.copy(),a,float(r)))
        if len(pending)>3:deliver(pending.popleft())
        if t+1 in CHECKPOINTS:rows[t+1]=ev(m)
    while pending:deliver(pending.popleft())
    rows[LOCAL_TRIALS]=ev(m);return rows

def auc(rows,k):
    xs=np.array(CHECKPOINTS,float);ys=np.array([rows[x][k] for x in CHECKPOINTS],float);return float(np.trapezoid(ys,xs)/xs[-1])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--fly',type=int,required=True);a=ap.parse_args();fs=a.fly;g=STUDENTS[fs]
    torch.set_num_threads(1);q,_=teacher_q();net,_,_=train_packet(q);raw,arr,sc=make_packet(net);pq=packet_predict(arr,sc,ST);Path('/mnt/data/convention_relay_teacher_97b.iap').write_bytes(raw)
    out=[]
    for rep in REPS:
      for var in ['scratch','culture','wrong_culture']:
        m=init(fs,g,rep)
        if var=='culture':absorb(m,pq,fs,rep,False)
        elif var=='wrong_culture':absorb(m,pq,fs,rep,True)
        post=ev(m);rows=local(m,fs,rep);r={'fly':fs,'rep':rep,'variant':var,'postculture':post,'auc_action':auc(rows,'action_accuracy'),'auc_sequence':auc(rows,'sequence_success'),'checkpoints':rows};out.append(r);print(fs,rep,var,post,round(r['auc_action'],3),round(r['auc_sequence'],3),rows[512],flush=True)
    Path(f'/mnt/data/convention_confirm_{fs}.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
