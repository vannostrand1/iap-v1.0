# IAP Alien Brain Transplant v0

A small falsifiable test of architecture-neutral knowledge transfer under hidden representational permutations.

## What it tests

A teacher learns a 64-state predator/resource decision world. Its learned Q-function is distilled into a quantized IAP packet. The alien world independently permutes observation channels, signs, and action IDs. A student gets only a small calibration budget plus the IAP packet; a matched scratch MLP gets the same calibration interactions but no packet.

Negative controls use row-shuffled and random packets of the same shape. The learned packet can also be compiled into different student architectures (MLP, decision tree, quadratic linear model).

This is a **Gate 0 transport experiment**, not a claim that an emergent machine language has been discovered. The packet schema and decoder family are fixed in advance. The next gate is to learn the packet format/encoder itself and move to a sequential environment.

## Run

```bash
python experiment.py --seeds 30 --out results
```

For a quick smoke test:

```bash
python experiment.py --seeds 3 --out smoke_results
```

## Dependencies

- Python 3.10+
- numpy
- pandas
- torch
- scikit-learn

## Primary outputs

- `sample_efficiency.csv`
- `negative_controls.csv`
- `architecture_compile.csv`
- `summary.json`

