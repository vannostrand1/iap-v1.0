import argparse
import itertools
import json
import os
import struct
import zlib

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.linear_model import Ridge
from sklearn.preprocessing import PolynomialFeatures
from sklearn.tree import DecisionTreeRegressor

DIRS = [(dx, dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1) if not (dx == 0 and dy == 0)]
STATES = np.array([(fx, fy, tx, ty) for fx, fy in DIRS for tx, ty in DIRS], dtype=np.int8)
MOVES = np.array([[-1, 0], [1, 0], [0, 1], [0, -1]], dtype=np.float32)
STATE_TO_IDX = {tuple(map(int, s)): i for i, s in enumerate(STATES)}
OBS_PERMS = list(itertools.permutations(range(4)))
FLIPS = list(itertools.product([-1, 1], repeat=4))
OBS_TRANSFORMS = [(p, f) for p in OBS_PERMS for f in FLIPS]
ACTION_PERMS = list(itertools.permutations(range(4)))


def true_q_for_state(s):
    f = np.array(s[:2], dtype=float)
    t = np.array(s[2:], dtype=float)
    out = []
    for m in MOVES:
        pf = float(np.dot(m, f))
        pt = float(np.dot(m, t))
        r = 1.0 * pf - 1.35 * pt
        if pf > 0 and pt <= 0:
            r += 0.45
        if pt > 0:
            r -= 0.65
        if pf < 0 and pt > 0:
            r -= 0.25
        if pf > 0 and pt > 0:
            r -= 0.35
        out.append(r)
    return np.array(out, dtype=np.float32)


TRUE_Q = np.stack([true_q_for_state(s) for s in STATES])


class QMLP(nn.Module):
    def __init__(self, hidden=48):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(4, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 4),
        )

    def forward(self, x):
        return self.net(x)


def train_teacher(seed=0, n_samples=8000, epochs=250):
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(STATES), size=n_samples)
    acts = rng.integers(0, 4, size=n_samples)
    X = STATES[idx].astype(np.float32)
    y = TRUE_Q[idx, acts] + rng.normal(0, 0.12, size=n_samples)

    xt = torch.tensor(X)
    at = torch.tensor(acts, dtype=torch.long)
    yt = torch.tensor(y, dtype=torch.float32)
    torch.manual_seed(seed)
    model = QMLP(48)
    opt = optim.Adam(model.parameters(), lr=0.01, weight_decay=1e-5)
    for _ in range(epochs):
        pred = model(xt).gather(1, at[:, None]).squeeze(1)
        loss = ((pred - yt) ** 2).mean()
        opt.zero_grad(); loss.backward(); opt.step()
    with torch.no_grad():
        q = model(torch.tensor(STATES.astype(np.float32))).numpy()
    return model, q


def quantize_packet(q):
    qmin, qmax = float(q.min()), float(q.max())
    scale = (qmax - qmin) / 255.0
    q8 = np.clip(np.round((q - qmin) / scale), 0, 255).astype(np.uint8)
    raw = b"IAP0" + struct.pack("<ff", qmin, qmax) + q8.tobytes()
    compressed = zlib.compress(raw, 9)
    decoded = qmin + q8.astype(np.float32) * scale
    return decoded, raw, compressed


def apply_obs_transform(canon, p, f):
    canon = np.asarray(canon)
    return np.array([canon[p[k]] * f[k] for k in range(4)], dtype=np.int8)


def invert_obs_transform(obs, p, f):
    c = np.empty(4, dtype=np.int8)
    for k in range(4):
        c[p[k]] = obs[k] * f[k]
    return c


def make_calib(seed, nmax=256, noise=0.12):
    rng = np.random.default_rng(seed)
    p = OBS_PERMS[rng.integers(len(OBS_PERMS))]
    f = FLIPS[rng.integers(len(FLIPS))]
    ap = ACTION_PERMS[rng.integers(len(ACTION_PERMS))]
    sidx = rng.integers(0, len(STATES), size=nmax)
    aobs = rng.integers(0, 4, size=nmax)
    obs = np.stack([apply_obs_transform(STATES[i], p, f) for i in sidx])
    r = np.array([TRUE_Q[si, ap[ao]] for si, ao in zip(sidx, aobs)], dtype=float)
    r += rng.normal(0, noise, size=nmax)
    return (p, f, ap), (obs, aobs, r, sidx)


def subset_calib(calib, n):
    return tuple(x[:n] for x in calib)


def ground_packet(calib, qtable):
    obs, aobs, r, _ = calib
    best = (float("inf"), None)
    for p, f in OBS_TRANSFORMS:
        cidx = []
        valid = True
        for o in obs:
            key = tuple(map(int, invert_obs_transform(o, p, f)))
            if key not in STATE_TO_IDX:
                valid = False
                break
            cidx.append(STATE_TO_IDX[key])
        if not valid:
            continue
        base = qtable[np.array(cidx, dtype=int)]
        for ap in ACTION_PERMS:
            pred = np.array([base[i, ap[aobs[i]]] for i in range(len(obs))])
            mse = float(np.mean((pred - r) ** 2))
            if mse < best[0]:
                best = (mse, (p, f, ap))
    if best[1] is None:
        raise RuntimeError("No valid grounding candidate")
    return best


def policy_metrics_from_packet(true_transform, est_transform, qtable):
    tp, tf, tap = true_transform
    ep, ef, eap = est_transform
    inv_eap = {can: obs for obs, can in enumerate(eap)}
    default_can = int(qtable.mean(axis=0).argmax())
    correct, invalid = 0, 0
    regrets, rewards = [], []
    for si, s in enumerate(STATES):
        obs = apply_obs_transform(s, tp, tf)
        key = tuple(map(int, invert_obs_transform(obs, ep, ef)))
        if key in STATE_TO_IDX:
            a_can_est = int(qtable[STATE_TO_IDX[key]].argmax())
        else:
            invalid += 1
            a_can_est = default_can
        a_obs = inv_eap[a_can_est]
        a_true = tap[a_obs]
        rew = float(TRUE_Q[si, a_true])
        opt = float(TRUE_Q[si].max())
        if a_true in np.flatnonzero(np.isclose(TRUE_Q[si], opt)):
            correct += 1
        regrets.append(opt - rew)
        rewards.append(rew)
    return {
        "optimal_action_rate": correct / len(STATES),
        "mean_regret": float(np.mean(regrets)),
        "mean_reward": float(np.mean(rewards)),
        "invalid_state_rate": invalid / len(STATES),
    }


def train_scratch_mlp(calib, seed, epochs=220, hidden=48):
    obs, aobs, r, _ = calib
    X = torch.tensor(obs.astype(np.float32))
    A = torch.tensor(aobs, dtype=torch.long)
    Y = torch.tensor(r, dtype=torch.float32)
    torch.manual_seed(seed)
    model = QMLP(hidden)
    opt = optim.Adam(model.parameters(), lr=0.02, weight_decay=1e-4)
    for _ in range(epochs):
        pred = model(X).gather(1, A[:, None]).squeeze(1)
        loss = ((pred - Y) ** 2).mean()
        opt.zero_grad(); loss.backward(); opt.step()
    return model


def eval_predictor(predict_fn, true_transform):
    tp, tf, tap = true_transform
    obs_all = np.stack([apply_obs_transform(s, tp, tf) for s in STATES]).astype(np.float32)
    q = predict_fn(obs_all)
    aobs = q.argmax(1)
    true_actions = np.array([tap[int(a)] for a in aobs])
    chosen = TRUE_Q[np.arange(len(STATES)), true_actions]
    opts = TRUE_Q.max(1)
    opt_rate = np.mean([
        a in np.flatnonzero(np.isclose(TRUE_Q[i], opts[i]))
        for i, a in enumerate(true_actions)
    ])
    return {
        "optimal_action_rate": float(opt_rate),
        "mean_regret": float(np.mean(opts - chosen)),
        "mean_reward": float(np.mean(chosen)),
    }


def synth_from_packet(est_transform, qtable):
    ep, ef, eap = est_transform
    X = np.stack([apply_obs_transform(s, ep, ef) for s in STATES]).astype(np.float32)
    Y = np.stack([
        [qtable[i, eap[aobs]] for aobs in range(4)]
        for i in range(len(STATES))
    ]).astype(np.float32)
    return X, Y


def train_transfer_mlp(est_transform, qtable, seed, epochs=300):
    X, Y = synth_from_packet(est_transform, qtable)
    xt, yt = torch.tensor(X), torch.tensor(Y)
    torch.manual_seed(seed)
    model = QMLP(32)
    opt = optim.Adam(model.parameters(), lr=0.02, weight_decay=1e-5)
    for _ in range(epochs):
        pred = model(xt)
        loss = ((pred - yt) ** 2).mean()
        opt.zero_grad(); loss.backward(); opt.step()
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=30)
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    _, teacher_q = train_teacher(seed=0)
    packet_q, raw, compressed = quantize_packet(teacher_q)
    opts = TRUE_Q.max(1)
    pa = packet_q.argmax(1)
    teacher_opt = float(np.mean([a in np.flatnonzero(np.isclose(TRUE_Q[i], opts[i])) for i, a in enumerate(pa)]))
    teacher_regret = float(np.mean(opts - TRUE_Q[np.arange(len(STATES)), pa]))

    budgets = [8, 16, 32, 64, 128, 256]
    rows = []
    for seed in range(args.seeds):
        tt, ccmax = make_calib(1000 + seed, 256)
        for n in budgets:
            cc = subset_calib(ccmax, n)
            mse, est = ground_packet(cc, packet_q)
            tm = policy_metrics_from_packet(tt, est, packet_q)
            rows.append({"seed": seed, "N": n, "condition": "IAP", "ground_mse": mse, **tm})
            sm = train_scratch_mlp(cc, 5000 + seed * 10 + n)
            scm = eval_predictor(lambda x, m=sm: m(torch.tensor(x)).detach().numpy(), tt)
            rows.append({"seed": seed, "N": n, "condition": "Scratch-MLP", "ground_mse": np.nan, "invalid_state_rate": np.nan, **scm})
    sample_df = pd.DataFrame(rows)
    sample_df.to_csv(os.path.join(args.out, "sample_efficiency.csv"), index=False)

    rng = np.random.default_rng(12345)
    shuffled_q = packet_q[rng.permutation(len(STATES))].copy()
    random_q = rng.normal(packet_q.mean(), packet_q.std(), size=packet_q.shape).astype(np.float32)
    controls = []
    for seed in range(args.seeds):
        tt, ccmax = make_calib(3000 + seed, 64)
        for n in [8, 16, 32]:
            cc = subset_calib(ccmax, n)
            for name, qtab in [("Correct IAP", packet_q), ("Row-shuffled packet", shuffled_q), ("Random packet", random_q)]:
                mse, est = ground_packet(cc, qtab)
                met = policy_metrics_from_packet(tt, est, qtab)
                controls.append({"seed": seed, "N": n, "condition": name, "ground_mse": mse, **met})
    control_df = pd.DataFrame(controls)
    control_df.to_csv(os.path.join(args.out, "negative_controls.csv"), index=False)

    arch = []
    for seed in range(args.seeds):
        tt, ccmax = make_calib(2000 + seed, 64)
        cc = subset_calib(ccmax, 16)
        _, est = ground_packet(cc, packet_q)
        mlp = train_transfer_mlp(est, packet_q, 7000 + seed)
        met = eval_predictor(lambda x, m=mlp: m(torch.tensor(x)).detach().numpy(), tt)
        arch.append({"seed": seed, "architecture": "MLP compiled from IAP", **met})

        X, Y = synth_from_packet(est, packet_q)
        tree = DecisionTreeRegressor(random_state=seed).fit(X, Y)
        met = eval_predictor(lambda x, t=tree: t.predict(x), tt)
        arch.append({"seed": seed, "architecture": "Decision tree compiled from IAP", **met})

        poly = PolynomialFeatures(degree=2, include_bias=True)
        ridge = Ridge(alpha=1e-4).fit(poly.fit_transform(X), Y)
        met = eval_predictor(lambda x, p=poly, r=ridge: r.predict(p.transform(x)), tt)
        arch.append({"seed": seed, "architecture": "Quadratic linear compiled from IAP", **met})
    arch_df = pd.DataFrame(arch)
    arch_df.to_csv(os.path.join(args.out, "architecture_compile.csv"), index=False)

    sample_summary = sample_df.groupby(["N", "condition"]).agg(
        optimal_action_rate=("optimal_action_rate", "mean"),
        optimal_action_sd=("optimal_action_rate", "std"),
        mean_regret=("mean_regret", "mean"),
        mean_reward=("mean_reward", "mean"),
    ).reset_index()
    control_summary = control_df.groupby(["N", "condition"]).agg(
        optimal_action_rate=("optimal_action_rate", "mean"),
        optimal_action_sd=("optimal_action_rate", "std"),
        mean_regret=("mean_regret", "mean"),
        grounding_mse=("ground_mse", "mean"),
    ).reset_index()
    arch_summary = arch_df.groupby("architecture").agg(
        optimal_action_rate=("optimal_action_rate", "mean"),
        optimal_action_sd=("optimal_action_rate", "std"),
        mean_regret=("mean_regret", "mean"),
    ).reset_index()

    summary = {
        "seeds": args.seeds,
        "packet_raw_bytes": len(raw),
        "packet_zlib_bytes": len(compressed),
        "packet_bits": len(compressed) * 8,
        "teacher_packet_optimal_action_rate": teacher_opt,
        "teacher_packet_mean_regret": teacher_regret,
        "sample_efficiency": sample_summary.to_dict(orient="records"),
        "negative_controls": control_summary.to_dict(orient="records"),
        "architecture_compile": arch_summary.to_dict(orient="records"),
    }
    with open(os.path.join(args.out, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
