import os,importlib.util,numpy as np,torch,time,json
from scipy.optimize import linear_sum_assignment
HERE=os.path.dirname(os.path.abspath(__file__)); BASE=HERE; CBASE=HERE
spec=importlib.util.spec_from_file_location('lc',os.path.join(BASE,'learned_codec.py'));lc=importlib.util.module_from_spec(spec);spec.loader.exec_module(lc)
spec2=importlib.util.spec_from_file_location('hc',os.path.join(CBASE,'learned_hypothesis_critic.py'));hc=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(hc)
N_ACT=24;STATE_MAPS=hc.STATE_MAPS.numpy()

def load():
 ck=torch.load(os.path.join(BASE,'codec.pt'),map_location='cpu');codec=lc.Codec(16);codec.load_state_dict(ck['state_dict']);codec.eval();net=hc.Critic();net.load_state_dict(torch.load(os.path.join(CBASE,'critic.pt'),map_location='cpu'));net.eval();return codec,net

def cost_features(dq,pos,r):
 si=pos//4;ao=pos%4;cost=np.zeros((128,4,4),np.float32);counts=np.zeros(4,np.float32)
 for aobs in range(4):
  mask=ao==aobs;counts[aobs]=mask.sum()
  if not np.any(mask):continue
  for oi in range(128):
   ci=STATE_MAPS[oi,si[mask]];q=dq.reshape(64,4)[ci];cost[oi,aobs]=((q-r[mask,None])**2).sum(0)
 return torch.tensor(cost)[None],torch.tensor(counts)[None]
def solve_action(cost,N):
 c=cost;rows,cols=linear_sum_assignment(c);ap=np.zeros(4,dtype=int);ap[rows]=cols;return ap,float(c[rows,cols].sum()/N)
def pred_all(dq,oi,ap):
 arr=np.zeros(256)
 for s in range(64):
  ci=STATE_MAPS[oi,s]
  for a in range(4):arr[s*4+a]=dq.reshape(64,4)[ci,int(ap[a])]
 return arr

def ground_rank(net,dq,pos,r,K):
 cost,counts=cost_features(dq,pos,r)
 with torch.no_grad():scores=net(cost,counts)[0].numpy()
 top=np.argsort(scores)[:K];hyps=[]
 for oi in top:
  ap,mse=solve_action(cost.numpy()[0,int(oi)],len(pos));hyps.append((mse,int(oi),ap,float(scores[int(oi)])))
 hyps.sort(key=lambda x:x[0]);return hyps,scores

def episode(net,dq,trueq,true_tid,total=8,start=2,K=16,noise=.08,seed=0,active=True):
 rng=np.random.default_rng(seed);pos=[];r=[]
 for _ in range(start):
  p=int(rng.integers(256));pos.append(p);r.append(trueq[lc.MAPS[true_tid][p]]+rng.normal(0,noise))
 while len(pos)<total:
  if active:
   hyps,scores=ground_rank(net,dq,np.array(pos),np.array(r),K)
   preds=np.stack([pred_all(dq,oi,ap) for _,oi,ap,_ in hyps])
   hs=np.array([h[3] for h in hyps]);temp=max(np.std(hs),.05);w=np.exp(-(hs-hs.min())/(temp+1e-8));w/=w.sum();mean=(preds*w[:,None]).sum(0);var=((preds-mean[None])**2*w[:,None]).sum(0);var[np.array(pos,dtype=int)]=-1;p=int(np.argmax(var))
  else:p=int(rng.integers(256))
  pos.append(p);r.append(trueq[lc.MAPS[true_tid][p]]+rng.normal(0,noise))
 hyps,_=ground_rank(net,dq,np.array(pos),np.array(r),K);mse,oi,ap,_=hyps[0];ai=lc.ACTION_PERMS.index(tuple(int(x) for x in ap));return oi*24+ai

def acc(dq,tq,est,true):
 p=dq[lc.MAPS[est]].reshape(64,4);t=tq[lc.MAPS[true]].reshape(64,4);return float(np.mean(p.argmax(1)==t.argmax(1)))
def run(total,K,tasks=250,seed=0):
 codec,net=load();sp=lc.make_split(123);rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+1)
 with torch.no_grad():qs=lc.sample_q(tasks,torch.device('cpu'),g).flatten(1);dqs=codec.decode(codec.encode(qs,True)).numpy();qnp=qs.numpy()
 aa=[];pa=[];ae=[];pe=[];t0=time.time()
 for i in range(tasks):
  tid=int(rng.choice(sp.held_both));ea=episode(net,dqs[i],qnp[i],tid,total,2,K,.08,seed*10000+i,True);ep=episode(net,dqs[i],qnp[i],tid,total,2,K,.08,seed*10000+i,False);aa.append(acc(dqs[i],qnp[i],ea,tid));pa.append(acc(dqs[i],qnp[i],ep,tid));ae.append(ea==tid);pe.append(ep==tid)
 return {'total':total,'K':K,'tasks':tasks,'learned_active_policy':float(np.mean(aa)),'learned_passive_policy':float(np.mean(pa)),'active_exact':float(np.mean(ae)),'passive_exact':float(np.mean(pe)),'seconds':time.time()-t0}
if __name__=='__main__':
 torch.set_num_threads(4)
 for total in [6,8,12]:
  for K in [8,16]:print(json.dumps(run(total,K,180,600+total*10+K),indent=2),flush=True)
