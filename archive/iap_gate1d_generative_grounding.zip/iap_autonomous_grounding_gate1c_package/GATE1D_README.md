# IAP Gate 1D — Generative Grounding

Goal: remove the fixed 128-observation-transform dictionary used by Gate 1C. The receiver must construct semantic mappings compositionally.

## Search grammar

The generator constructs arbitrary signed permutations of four observation coordinates (24 coordinate permutations × 16 sign patterns = 384 possible structures). Many generated structures are not valid symmetries of the world manifold. No `OBS_TRANSFORMS` table is used by the proposal search itself.

For each generated observation semantics, the action mapping is solved by a 4×4 assignment problem. A learned hypothesis critic from Gate 1C can score complete generated hypotheses; an active loop selects calibration queries from disagreement among independently generated interpretations.

## Result

Across 3 seeds × 20 held-out tasks per seed on the hardest held-out split:

- 8 interactions: mean policy transfer 0.8292; exact observation semantics 0.7000; exact action map 0.7500.
- 12 interactions: mean policy transfer 0.8596; exact observation semantics 0.7833; exact action map 0.8167.

Gate 1C's fixed-vocabulary learned-active grounder was about 0.934 at 8 interactions and about 0.960 at 12 interactions, so Gate 1D does **not** yet match the prior gate.

## Interpretation

The knowledge packet and critic remain adequate. The failure is proposal recall: once the fixed semantic vocabulary is removed, stochastic grammar search does not reliably place the correct interpretation in the high-quality candidate set. More calibration evidence helps only modestly.

This is a useful negative result. The next experiment should learn an autoregressive / structured proposal policy over semantic constructions, trained from reward-derived search targets rather than hidden transform labels, while retaining critic verification and active querying.
