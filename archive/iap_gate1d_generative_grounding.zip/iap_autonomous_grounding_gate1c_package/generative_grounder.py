import os, importlib.util, itertools, json, time
import numpy as np, torch, pandas as pd
from functools import lru_cache
from scipy.optimize import linear_sum_assignment

HERE=os.path.dirname(os.path.abspath(__file__))
spec=importlib.util.spec_from_file_location('lc',os.path.join(HERE,'learned_codec.py'));lc=importlib.util.module_from_spec(spec);spec.loader.exec_module(lc)
spec2=importlib.util.spec_from_file_location('hc',os.path.join(HERE,'learned_hypothesis_critic.py'));hc=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(hc)
STI={tuple(map(int,s)):i for i,s in enumerate(lc.STATES.astype(np.int8))}
ALL_PERMS=list(itertools.permutations(range(4)))


def load_models():
 ck=torch.load(os.path.join(HERE,'codec.pt'),map_location='cpu'); codec=lc.Codec(16); codec.load_state_dict(ck['state_dict']); codec.eval()
 net=hc.Critic(); net.load_state_dict(torch.load(os.path.join(HERE,'critic.pt'),map_location='cpu')); net.eval()
 return codec,net

@lru_cache(maxsize=512)
def state_map_of(h):
 # h=(perm tuple, signs tuple). Same convention as training transforms: c[p[k]]=o[k]*f[k].
 p,f=h; out=np.full(64,-1,dtype=np.int64)
 for i,o in enumerate(lc.STATES.astype(np.int8)):
  c=np.empty(4,dtype=np.int8)
  for k in range(4): c[p[k]]=int(o[k])*int(f[k])
  out[i]=STI.get(tuple(map(int,c)),-1)
 return out

def random_h(rng):
 return (tuple(rng.permutation(4).tolist()), tuple(rng.choice([-1,1],size=4).tolist()))

def mutate(h,rng):
 p=list(h[0]); f=list(h[1]); mode=int(rng.integers(3))
 if mode==0:
  i,j=rng.choice(4,size=2,replace=False); p[i],p[j]=p[j],p[i]
 elif mode==1:
  i=int(rng.integers(4)); f[i]*=-1
 else:
  i,j=rng.choice(4,size=2,replace=False); p[i],p[j]=p[j],p[i]; f[int(rng.integers(4))]*=-1
 return (tuple(p),tuple(f))

def candidate_cost(dq,pos,r,h):
 sm=state_map_of(h); si=pos//4; ao=pos%4; ci=sm[si]
 if np.any(ci<0): return None,None,None
 q=dq.reshape(64,4)[ci]; cost=np.zeros((4,4),np.float32); counts=np.zeros(4,np.float32)
 for aobs in range(4):
  mask=ao==aobs; counts[aobs]=mask.sum()
  if np.any(mask): cost[aobs]=((q[mask]-r[mask,None])**2).sum(0)
 rows,cols=linear_sum_assignment(cost); ap=np.zeros(4,dtype=int);ap[rows]=cols
 mse=float(cost[rows,cols].sum()/max(1,len(pos)))
 return cost,counts,(ap,mse)

def critic_score(net,cost,counts):
 # Reproduce Critic feature transform for a single arbitrary hypothesis (not one of the stored 128).
 den=np.maximum(counts[:,None],1.0); x=cost/den; scale=max(float(x.mean()),.02); x=x/scale
 cc=counts/max(float(counts.sum()),1.0); feat=np.concatenate([x.reshape(-1),cc]).astype(np.float32)
 with torch.no_grad(): return float(net.net(torch.tensor(feat)[None]).item())

def score_population(net,dq,pos,r,P):
 feats=[]; meta=[]
 for h in P:
  cost,counts,sol=candidate_cost(dq,pos,r,h)
  if sol is None: continue
  den=np.maximum(counts[:,None],1.0); x=cost/den; scale=max(float(x.mean()),.02); x=x/scale
  cc=counts/max(float(counts.sum()),1.0); feats.append(np.concatenate([x.reshape(-1),cc]).astype(np.float32)); meta.append((h,sol[0],sol[1]))
 if not feats:return []
 with torch.no_grad(): scores=net.net(torch.tensor(np.stack(feats))).squeeze(-1).numpy()
 return [(float(sc),h,ap,mse) for sc,(h,ap,mse) in zip(scores,meta)]

def evolve(net,dq,pos,r,rng,pop=32,generations=4,elite=8,inject=6):
 # Generates hypotheses compositionally. No OBS_TRANSFORMS list is consulted.
 P=[]; seen=set()
 while len(P)<pop:
  h=random_h(rng)
  if h not in seen: seen.add(h);P.append(h)
 for _ in range(generations):
  scored=score_population(net,dq,pos,r,P);scored.sort(key=lambda z:z[0]); E=[z[1] for z in scored[:elite]]
  if not E: E=[random_h(rng) for _ in range(elite)]
  new=list(E); seen2=set(E); tries=0
  while len(new)<pop-inject and tries<1000:
   tries+=1; h=mutate(E[int(rng.integers(len(E)))],rng)
   if h not in seen2: seen2.add(h);new.append(h)
  while len(new)<pop:
   h=random_h(rng)
   if h not in seen2: seen2.add(h);new.append(h)
  P=new
 scored=score_population(net,dq,pos,r,P);scored.sort(key=lambda z:z[0]); top=scored[:16]
 if not top:return None,[]
 best=min(top,key=lambda z:z[3])
 return (best[1],best[2],best[3]),top

def pred_all(dq,h,ap):
 sm=state_map_of(h); arr=np.full(256,np.nan,np.float32)
 if np.any(sm<0): return arr
 q=dq.reshape(64,4)
 for s in range(64):
  for a in range(4): arr[s*4+a]=q[sm[s],int(ap[a])]
 return arr

def true_h_from_tid(tid):
 oi=int(lc.MAP_OBS[tid]); return lc.OBS_TRANSFORMS[oi]

def true_ap_from_tid(tid): return np.array(lc.ACTION_PERMS[int(lc.MAP_ACT[tid])],dtype=int)

def h_equal(a,b): return a[0]==b[0] and a[1]==b[1]

def policy_acc(dq,tq,h,ap,tid):
 pred=pred_all(dq,h,ap).reshape(64,4); true=tq[lc.MAPS[tid]].reshape(64,4)
 return float(np.mean(pred.argmax(1)==true.argmax(1)))

def episode(net,dq,tq,tid,total=8,start=2,seed=0,active=True,pop=40,gens=5):
 rng=np.random.default_rng(seed);pos=[];rr=[]
 for _ in range(start):
  p=int(rng.integers(256));pos.append(p);rr.append(tq[lc.MAPS[tid][p]]+rng.normal(0,.08))
 while len(pos)<total:
  est,top=evolve(net,dq,np.asarray(pos),np.asarray(rr),rng,pop,gens)
  if active and top:
   preds=[];weights=[]
   for sc,h,ap,mse in top:
    pr=pred_all(dq,h,ap)
    if np.isfinite(pr).all(): preds.append(pr);weights.append(sc)
   if len(preds)>=2:
    preds=np.stack(preds); hs=np.asarray(weights); temp=max(np.std(hs),.05);w=np.exp(-(hs-hs.min())/(temp+1e-8));w/=w.sum()
    mean=(preds*w[:,None]).sum(0);var=((preds-mean[None])**2*w[:,None]).sum(0);var[np.asarray(pos,dtype=int)]=-1;p=int(np.argmax(var))
   else:p=int(rng.integers(256))
  else:p=int(rng.integers(256))
  pos.append(p);rr.append(tq[lc.MAPS[tid][p]]+rng.normal(0,.08))
 est,top=evolve(net,dq,np.asarray(pos),np.asarray(rr),rng,pop,gens)
 return est

def run(total=8,tasks=150,seed=0,active=True,pop=40,gens=5):
 codec,net=load_models();sp=lc.make_split(123);rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+101)
 with torch.no_grad(): qs=lc.sample_q(tasks,torch.device('cpu'),g).flatten(1);dqs=codec.decode(codec.encode(qs,True)).numpy();qnp=qs.numpy()
 accs=[];hexact=[];aexact=[];valid=[];t0=time.time()
 for i in range(tasks):
  tid=int(rng.choice(sp.held_both));est=episode(net,dqs[i],qnp[i],tid,total,2,seed*10000+i,active,pop,gens)
  if est is None: accs.append(.25);hexact.append(0);aexact.append(0);valid.append(0);continue
  h,ap,mse=est; th=true_h_from_tid(tid); tap=true_ap_from_tid(tid)
  accs.append(policy_acc(dqs[i],qnp[i],h,ap,tid));hexact.append(float(h_equal(h,th)));aexact.append(float(np.array_equal(ap,tap)));valid.append(1)
 return {'total':total,'tasks':tasks,'seed':seed,'active':active,'population':pop,'generations':gens,'policy_acc':float(np.mean(accs)),'obs_semantic_exact':float(np.mean(hexact)),'action_exact':float(np.mean(aexact)),'valid_rate':float(np.mean(valid)),'seconds':time.time()-t0}

if __name__=='__main__':
 torch.set_num_threads(4); rows=[]
 for total in [8,12]:
  for active in [False,True]:
   for seed in [11,22,33]:
    r=run(total,80,seed,active,32,4);rows.append(r);print(json.dumps(r),flush=True)
 pd.DataFrame(rows).to_csv(os.path.join(HERE,'results','gate1d_generative.csv'),index=False)

def local_search(net,dq,pos,r,rng,restarts=12,steps=12):
 # Generative stochastic hill climb over the signed-permutation grammar. No transform table.
 best_global=None
 for _ in range(restarts):
  h=random_h(rng); cost,counts,sol=candidate_cost(dq,pos,r,h)
  if sol is None: cur=1e6
  else: cur=sol[1]
  best=(cur,h,sol[0] if sol else np.arange(4))
  T=.03
  for st in range(steps):
   candidates=[mutate(h,rng) for _ in range(6)]
   vals=[]
   for hh in candidates:
    cc,cn,ss=candidate_cost(dq,pos,r,hh)
    if ss is not None: vals.append((ss[1],hh,ss[0]))
   if not vals: continue
   vals.sort(key=lambda x:x[0]); nv,nh,nap=vals[0]
   if nv<cur or rng.random()<np.exp((cur-nv)/max(T,1e-5)):
    cur,h=nv,nh
   if nv<best[0]: best=(nv,nh,nap)
   T*=.82
  if best_global is None or best[0]<best_global[0]: best_global=best
 return (best_global[1],best_global[2],best_global[0])

def episode_local(net,dq,tq,tid,total=8,start=2,seed=0,active=True,restarts=12,steps=12):
 rng=np.random.default_rng(seed);pos=[];rr=[]
 for _ in range(start):
  p=int(rng.integers(256));pos.append(p);rr.append(tq[lc.MAPS[tid][p]]+rng.normal(0,.08))
 while len(pos)<total:
  # Generate an ensemble of independently discovered interpretations for disagreement querying.
  ens=[local_search(net,dq,np.asarray(pos),np.asarray(rr),rng,max(3,restarts//3),max(5,steps//2)) for _ in range(6)]
  if active:
   preds=np.stack([pred_all(dq,h,ap) for h,ap,_ in ens]); var=np.nanvar(preds,axis=0);var[np.asarray(pos,dtype=int)]=-1;p=int(np.nanargmax(var))
  else:p=int(rng.integers(256))
  pos.append(p);rr.append(tq[lc.MAPS[tid][p]]+rng.normal(0,.08))
 return local_search(net,dq,np.asarray(pos),np.asarray(rr),rng,restarts,steps)

def run_local(total=8,tasks=100,seed=0,active=True,restarts=12,steps=12):
 codec,net=load_models();sp=lc.make_split(123);rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+101)
 with torch.no_grad(): qs=lc.sample_q(tasks,torch.device('cpu'),g).flatten(1);dqs=codec.decode(codec.encode(qs,True)).numpy();qnp=qs.numpy()
 accs=[];hexact=[];aexact=[];t0=time.time()
 for i in range(tasks):
  tid=int(rng.choice(sp.held_both));h,ap,mse=episode_local(net,dqs[i],qnp[i],tid,total,2,seed*10000+i,active,restarts,steps);th=true_h_from_tid(tid);tap=true_ap_from_tid(tid)
  accs.append(policy_acc(dqs[i],qnp[i],h,ap,tid));hexact.append(float(h_equal(h,th)));aexact.append(float(np.array_equal(ap,tap)))
 return {'method':'generative_local_search','total':total,'tasks':tasks,'seed':seed,'active':active,'restarts':restarts,'steps':steps,'policy_acc':float(np.mean(accs)),'obs_semantic_exact':float(np.mean(hexact)),'action_exact':float(np.mean(aexact)),'seconds':time.time()-t0}
