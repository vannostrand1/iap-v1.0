import os,importlib.util,numpy as np,torch,json,time
from scipy.optimize import linear_sum_assignment
HERE=os.path.dirname(os.path.abspath(__file__)); BASE=HERE
spec=importlib.util.spec_from_file_location('lc',os.path.join(BASE,'learned_codec.py'));lc=importlib.util.module_from_spec(spec);spec.loader.exec_module(lc)
N_ACT=24
STATE_MAPS=[]
for oi in range(len(lc.OBS_TRANSFORMS)):
 m=lc.MAPS[oi*N_ACT].reshape(64,4);STATE_MAPS.append((m[:,0]//4).astype(np.int64))
STATE_MAPS=np.stack(STATE_MAPS)

def load_codec():
 ck=torch.load(os.path.join(BASE,'codec.pt'),map_location='cpu');m=lc.Codec(16);m.load_state_dict(ck['state_dict']);m.eval();return m

def fit_all(dq,pos,r):
 si=pos//4;ao=pos%4;out=[]
 for oi in range(128):
  ci=STATE_MAPS[oi,si];q=dq.reshape(64,4)[ci];cost=np.zeros((4,4))
  for aa in range(4):
   mask=ao==aa
   if np.any(mask):cost[aa]=((q[mask]-r[mask,None])**2).sum(0)
  rows,cols=linear_sum_assignment(cost);ap=np.zeros(4,dtype=int);ap[rows]=cols;mse=float(cost[rows,cols].sum()/max(1,len(pos)))
  out.append((mse,oi,ap))
 out.sort(key=lambda x:x[0]);return out

def tid_from(oi,ap):return oi*N_ACT+lc.ACTION_PERMS.index(tuple(int(x) for x in ap))
def predict_all_positions(dq,oi,ap):
 vals=np.zeros(256)
 for si in range(64):
  ci=STATE_MAPS[oi,si]
  for ao in range(4):vals[si*4+ao]=dq.reshape(64,4)[ci,int(ap[ao])]
 return vals

def active_episode(dq,trueq,true_tid,total=8,start=2,noise=.08,seed=0,top_h=16):
 rng=np.random.default_rng(seed);used=[];rewards=[]
 for _ in range(start):
  p=int(rng.integers(256));used.append(p);rewards.append(trueq[lc.MAPS[true_tid][p]]+rng.normal(0,noise))
 while len(used)<total:
  fit=fit_all(dq,np.array(used),np.array(rewards));top=fit[:min(top_h,len(fit))]
  preds=np.stack([predict_all_positions(dq,oi,ap) for _,oi,ap in top])
  # posterior weights from residuals; with very little evidence, use broad weighting
  ms=np.array([x[0] for x in top]);temp=max(np.std(ms),.01);w=np.exp(-(ms-ms.min())/(temp+1e-8));w/=w.sum()
  mean=(preds*w[:,None]).sum(0);var=((preds-mean[None,:])**2*w[:,None]).sum(0)
  # prefer high disagreement, but avoid extreme decoded values dominating solely by scale
  score=var/(np.var(preds,axis=0).mean()+1e-8)
  score[np.array(used,dtype=int)]=-1
  p=int(np.argmax(score));used.append(p);rewards.append(trueq[lc.MAPS[true_tid][p]]+rng.normal(0,noise))
 fit=fit_all(dq,np.array(used),np.array(rewards));mse,oi,ap=fit[0];est=tid_from(oi,ap)
 return est,mse,np.array(used)

def passive_episode(dq,trueq,true_tid,total=8,noise=.08,seed=0):
 rng=np.random.default_rng(seed);pos=rng.integers(0,256,size=total);r=trueq[lc.MAPS[true_tid][pos]]+rng.normal(0,noise,size=total);mse,oi,ap=fit_all(dq,pos,r)[0];return tid_from(oi,ap),mse,pos

def acc(dq,trueq,est,true):
 p=dq[lc.MAPS[est]].reshape(64,4);t=trueq[lc.MAPS[true]].reshape(64,4);return float(np.mean(p.argmax(1)==t.argmax(1)))
def run(total,start=2,tasks=300,seed=1):
 codec=load_codec();sp=lc.make_split(123);rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+10)
 with torch.no_grad():qs=lc.sample_q(tasks,torch.device('cpu'),g).flatten(1);dqs=codec.decode(codec.encode(qs,True)).numpy();qnp=qs.numpy()
 ar=[];pr=[];ae=[];pe=[];t0=time.time()
 for i in range(tasks):
  tid=int(rng.choice(sp.held_both));ea,_,_=active_episode(dqs[i],qnp[i],tid,total,start,.08,seed*10000+i);ep,_,_=passive_episode(dqs[i],qnp[i],tid,total,.08,seed*10000+i)
  ar.append(acc(dqs[i],qnp[i],ea,tid));pr.append(acc(dqs[i],qnp[i],ep,tid));ae.append(ea==tid);pe.append(ep==tid)
 return {'total':total,'start_random':start,'tasks':tasks,'active_policy':float(np.mean(ar)),'passive_policy':float(np.mean(pr)),'active_exact':float(np.mean(ae)),'passive_exact':float(np.mean(pe)),'seconds':time.time()-t0}
if __name__=='__main__':
 torch.set_num_threads(4)
 for n in [4,6,8,12,16]:print(json.dumps(run(n,min(2,n),250,100+n),indent=2),flush=True)
