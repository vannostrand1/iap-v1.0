# IAP Alien Brain Transplant — Gate 1C: Autonomous Grounding

Gate 1C tests whether a receiver can ground a learned 16-byte IAP packet into an alien representation **without being handed the hidden observation/action mapping**.

The source packet/codec is the successful Gate 1A learned protocol. Gate 1C changes only the grounding mechanism.

## Main result

The strongest hybrid receiver combines:

1. **Learned hypothesis critic** — a shared neural scorer learns how to rank candidate observation alignments from reward-consistency evidence. It is trained only from reward-derived profile likelihoods, not hidden transform labels.
2. **Top-K action verifier** — action alignment for only the critic's best K candidates is solved as a small 4x4 assignment problem.
3. **Active calibration** — after two random interactions, the receiver chooses the next alien state/action query by maximizing disagreement among its currently plausible grounded interpretations.

On the hardest test split, both observation and action transform components are held out from training.

### Multi-seed confirmation

| Grounding budget | K | Learned active policy transfer | Learned passive policy transfer | Exact hidden transform |
|---:|---:|---:|---:|---:|
| 8 interactions | 16 | **93.40%** | 89.87% | **84.0%** |
| 12 interactions | 16 | **96.05%** | 95.07% | **96.0%** |

The 8-interaction row is the mean of 3 seeds x 150 tasks. The 12-interaction row is the mean of 3 seeds x 100 tasks.

### Learned critic alone

With passive calibration on 400 held-out-both tasks:

| Calibration | Top-K verified obs hypotheses | Policy transfer |
|---:|---:|---:|
| 8 | 16 | 90.57% |
| 16 | 4 | 93.32% |
| 16 | 8 | **95.37%** |
| 16 | 16 | 95.68% |
| 32 | 8 | **95.66%** |

This is the first Gate 1 experiment where a learned grounding component succeeds after the one-shot set networks failed.

## Structural grounding baseline

The original 3,072 full transforms factorize. Conditional on an observation alignment, the optimal action remapping is a 4x4 linear assignment problem. Enumerating only the 128 observation hypotheses and solving actions with Hungarian assignment exactly reproduces the full exhaustive search at N>=16 in the benchmark while reducing the explicit hypothesis space by 24x.

Representative hardest-split results (400 tasks):

| N | 128-hypothesis factorized | 3,072 exhaustive | Same selected transform |
|---:|---:|---:|---:|
| 8 | 92.59% | 92.55% | 99.0% |
| 16 | **95.79%** | **95.79%** | 100% |
| 32 | **95.97%** | **95.97%** | 100% |

The learned critic is then used to rank those observation hypotheses so only its top-K candidates require exact action verification.

## Active grounding result

With the full structured 128-hypothesis solver used only as a diagnostic oracle, active evidence gathering improves sample efficiency substantially:

- 6 interactions: 90.43% active vs 84.94% passive.
- 8 interactions: 94.93% active vs 92.58% passive.

The learned-active receiver approaches that oracle: across three seeds at 8 interactions it reaches 93.40%.

## What failed

Several failures are retained because they materially narrow the design space:

- **One-shot differentiable SetGrounder:** near chance.
- **Mapping-supervised one-shot set network:** also failed to amortize the combinatorial alignment.
- **Direct structured proposal classifier:** failed even with an action-invariant reward signature.
- **Per-instance differentiable relaxation:** improved when factorized, but remained below the hypothesis-based solver (about 83% at N=16 and 89% at N=32 in the diagnostic run).
- **Coordinate/CEM non-exhaustive search:** useful but substantially below the 128-hypothesis factorized solution at the same evidence budget.

The recurring lesson is that grounding is not behaving like ordinary pattern classification. A network succeeds when asked to **judge explicit hypotheses**, not when asked to emit a complete mapping in one shot.

## Scientific boundary

Gate 1C is not yet an unconstrained universal interpreter.

The receiver still knows that the alien representation belongs to a family of signed/permuted coordinate systems and permuted actions. The learned critic evaluates 128 explicit observation hypotheses, although only top-K candidates are exactly action-grounded. The packet codec is shared infrastructure.

What Gate 1C demonstrates is narrower and useful:

> A learned, opaque 16-byte task packet can be autonomously grounded into previously unseen alien representations by a receiver that learns how to evaluate semantic hypotheses from reward evidence, then actively seeks disambiguating experience.

The next gate should remove the fixed 128-hypothesis vocabulary. A natural route is to let a proposal model **generate** candidate semantic correspondences, while the learned critic and active-query loop remain as the verifier.

## Files

- `learned_codec.py` / `codec.pt` — frozen Gate 1A 16-byte protocol codec.
- `factorized_grounder.py` — 128-observation-hypothesis + Hungarian action solver.
- `active_grounder.py` — information-gain active calibration using the structured solver.
- `learned_hypothesis_critic.py` / `critic.pt` — reward-derived learned hypothesis scorer.
- `learned_active_grounder.py` — learned critic + top-K verifier + active evidence gathering.
- `failed_attempts/` — representative failed direct/gradient approaches.
- `results/structured_baselines.csv` — factorized/exhaustive and structured-active baselines.
- `results/critic_eval.csv` — learned critic top-K results.
- `results/active_multiseed_n8_k16.csv` — three-seed 8-interaction learned-active confirmation.
- `results/active_multiseed_n12_k16.csv` — three-seed 12-interaction confirmation.

## Run

```bash
pip install -r requirements.txt
python factorized_grounder.py
python learned_active_grounder.py
```

`learned_hypothesis_critic.py` retrains the critic from scratch; the included `critic.pt` is the checkpoint used for the reported learned-active evaluations.
