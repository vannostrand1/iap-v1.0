import os, importlib.util, numpy as np, torch, time, json
from scipy.optimize import linear_sum_assignment
HERE=os.path.dirname(os.path.abspath(__file__)); BASE=HERE
spec=importlib.util.spec_from_file_location('lc',os.path.join(BASE,'learned_codec.py'));lc=importlib.util.module_from_spec(spec);spec.loader.exec_module(lc)
N_ACT=24
# derive state maps for each of 128 obs transforms from first action-perm identity entry
STATE_MAPS=[]
for oi in range(len(lc.OBS_TRANSFORMS)):
 tid=oi*N_ACT+0
 m=lc.MAPS[tid].reshape(64,4)
 # identity action perm at index 0
 STATE_MAPS.append((m[:,0]//4).astype(np.int64))
STATE_MAPS=np.stack(STATE_MAPS)

def load_codec():
 ck=torch.load(os.path.join(BASE,'codec.pt'),map_location='cpu');m=lc.Codec(16);m.load_state_dict(ck['state_dict']);m.eval();return m

def ground_factorized(dq,pos,r):
 si=pos//4; ao=pos%4
 best=(1e30,None,None)
 # 128 observation hypotheses; action map solved by Hungarian assignment, never enumerated.
 for oi in range(len(STATE_MAPS)):
  ci=STATE_MAPS[oi,si]
  q=dq.reshape(64,4)[ci] # [N,4 canonical action]
  cost=np.zeros((4,4),dtype=np.float64)
  for aobs in range(4):
   mask=(ao==aobs)
   if np.any(mask): cost[aobs]=((q[mask]-r[mask,None])**2).sum(0)
   else: cost[aobs]=0.0
  rows,cols=linear_sum_assignment(cost)
  ap=np.zeros(4,dtype=np.int64);ap[rows]=cols
  mse=float(cost[rows,cols].sum()/len(pos))
  if mse<best[0]:best=(mse,oi,tuple(int(x) for x in ap))
 mse,oi,ap=best
 ai=lc.ACTION_PERMS.index(ap);tid=oi*N_ACT+ai
 return tid,mse,128

def ground_exhaustive(dq,pos,r):
 mm=lc.MAPS[:,pos];pred=dq[mm];mse=((pred-r[None,:])**2).mean(1);tid=int(np.argmin(mse));return tid,float(mse[tid]),len(mse)

def policy_acc(dq,trueq,est,true):
 p=dq[lc.MAPS[est]].reshape(64,4);t=trueq[lc.MAPS[true]].reshape(64,4);return float(np.mean(p.argmax(1)==t.argmax(1)))

def run(N=16,tasks=1000,seed=1):
 torch.set_num_threads(4);codec=load_codec();split=lc.make_split(123);ids=split.held_both;rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+100)
 with torch.no_grad():
  qs=lc.sample_q(tasks,torch.device('cpu'),g).flatten(1);dqs=codec.decode(codec.encode(qs,True)).numpy();qnp=qs.numpy()
 rows=[];t0=time.time()
 for i in range(tasks):
  tid=int(rng.choice(ids));pos=rng.integers(0,256,size=N);r=qnp[i][lc.MAPS[tid][pos]]+rng.normal(0,.08,size=N)
  fg,fm,_=ground_factorized(dqs[i],pos,r);ex,em,_=ground_exhaustive(dqs[i],pos,r)
  rows.append((policy_acc(dqs[i],qnp[i],fg,tid),policy_acc(dqs[i],qnp[i],ex,tid),float(fg==tid),float(ex==tid),float(fg==ex),fm,em))
 a=np.array(rows);return {'N':N,'tasks':tasks,'factor_policy':float(a[:,0].mean()),'exhaustive_policy':float(a[:,1].mean()),'factor_exact':float(a[:,2].mean()),'exhaustive_exact':float(a[:,3].mean()),'same_tid':float(a[:,4].mean()),'mean_abs_mse_diff':float(np.abs(a[:,5]-a[:,6]).mean()),'speed_s':time.time()-t0,'hypotheses':128,'full_space':3072}
if __name__=='__main__':
 for N in [4,8,16,32]:print(json.dumps(run(N,400,700+N),indent=2),flush=True)
