import os, importlib.util, time, json, math, random
import numpy as np, pandas as pd, torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment
HERE=os.path.dirname(os.path.abspath(__file__)); BASE=os.path.dirname(HERE)
spec=importlib.util.spec_from_file_location('lc',os.path.join(BASE,'learned_codec.py'));lc=importlib.util.module_from_spec(spec);spec.loader.exec_module(lc)
N_ACT=24; N_PERM=len(lc.OBS_PERMS); N_FLIP=len(lc.FLIPS)
STATES=torch.tensor(lc.STATES,dtype=torch.float32)
STATE_MAPS=[]
for oi in range(len(lc.OBS_TRANSFORMS)):
 m=lc.MAPS[oi*N_ACT].reshape(64,4);STATE_MAPS.append((m[:,0]//4).astype(np.int64))
STATE_MAPS=np.stack(STATE_MAPS)

def load_codec():
 ck=torch.load(os.path.join(BASE,'codec.pt'),map_location='cpu');m=lc.Codec(16);m.load_state_dict(ck['state_dict']);m.eval();
 for p in m.parameters():p.requires_grad=False
 return m

def alienize(q,tids):return q.flatten(1).gather(1,torch.tensor(lc.MAPS[tids],dtype=torch.long)).view(-1,64,4)
def calib(target,N,noise,g):
 B=target.shape[0];pos=torch.randint(0,256,(B,N),generator=g);si=pos//4;a=pos%4;o=STATES[si];r=target.flatten(1).gather(1,pos)
 if noise:r=r+torch.randn(r.shape,generator=g)*noise
 return o,a,r,pos

def obs_labels(tids):
 p=[];s=[];oi=[]
 for tid in tids:
  o=int(lc.MAP_OBS[tid]); pp,ff=lc.OBS_TRANSFORMS[o];p.append(lc.OBS_PERMS.index(pp));s.append([1 if x>0 else 0 for x in ff]);oi.append(o)
 return torch.tensor(p),torch.tensor(s,dtype=torch.float32),np.array(oi)

class Proposal(nn.Module):
 def __init__(self,width=160):
  super().__init__();self.tok=nn.Sequential(nn.Linear(4+4+1+64,width),nn.GELU(),nn.Linear(width,width),nn.GELU())
  self.fuse=nn.Sequential(nn.Linear(width*2+16,width),nn.GELU(),nn.Linear(width,width),nn.GELU())
  self.hp=nn.Linear(width,N_PERM);self.hs=nn.Linear(width,4)
 def forward(self,z,dq,o,a,r):
  # state compatibility signature independent of action mapping
  # dq [B,64,4], r [B,N]
  d=(dq[:,None,:,:]-r[:,:,None,None])**2
  # softmin over canonical actions; lower is more compatible, turn into bounded similarity
  md=-torch.logsumexp(-d/0.08,dim=-1)*0.08 # [B,N,64]
  sim=torch.exp(-md.clamp_min(0)/0.18)
  ah=F.one_hot(a,4).float();h=self.tok(torch.cat([o,ah,r.unsqueeze(-1),sim],-1));c=torch.cat([h.mean(1),h.max(1).values,z],-1);c=self.fuse(c)
  return self.hp(c),self.hs(c)

def topk_ois(pl,sl,K):
 # produce top K obs transform indices from factorized distribution
 lp=F.log_softmax(pl,-1); ls=F.logsigmoid(sl); lsn=F.logsigmoid(-sl)
 B=pl.shape[0];scores=[]
 for pi in range(N_PERM):
  for fi,ff in enumerate(lc.FLIPS):
   sc=lp[:,pi].clone()
   for b,x in enumerate(ff):sc+=ls[:,b] if x>0 else lsn[:,b]
   scores.append(sc)
 score=torch.stack(scores,-1);return torch.topk(score,min(K,score.shape[1]),dim=-1).indices.cpu().numpy()

def solve_action_for_oi(dq,pos,r,oi):
 si=pos//4;ao=pos%4;ci=STATE_MAPS[oi,si];q=dq.reshape(64,4)[ci];cost=np.zeros((4,4))
 for aobs in range(4):
  m=ao==aobs
  if np.any(m):cost[aobs]=((q[m]-r[m,None])**2).sum(0)
 rows,cols=linear_sum_assignment(cost);ap=np.zeros(4,dtype=int);ap[rows]=cols;mse=float(cost[rows,cols].sum()/len(pos));ai=lc.ACTION_PERMS.index(tuple(int(x) for x in ap));return oi*N_ACT+ai,mse

def eval_topk(net,codec,ids,N,K,tasks,seed):
 rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+1);rows=[]
 with torch.no_grad():
  qs=lc.sample_q(tasks,torch.device('cpu'),g);tids=rng.choice(ids,size=tasks,replace=True);target=alienize(qs,tids);z=codec.encode(qs.flatten(1),True);dq=codec.decode(z).view(tasks,64,4);o,a,r,pos=calib(target,N,.08,g);pl,sl=net(z,dq,o,a,r);tops=topk_ois(pl,sl,K);_,_,trueoi=obs_labels(tids)
  qnp=qs.flatten(1).numpy();dnp=dq.flatten(1).numpy();pnp=pos.numpy();rnp=r.numpy()
 for i in range(tasks):
  best=(1e99,None)
  for oi in tops[i]:
   tid,mse=solve_action_for_oi(dnp[i],pnp[i],rnp[i],int(oi))
   if mse<best[0]:best=(mse,tid)
  est=best[1];pred=dnp[i][lc.MAPS[est]].reshape(64,4);tru=qnp[i][lc.MAPS[int(tids[i])]].reshape(64,4);acc=float(np.mean(pred.argmax(1)==tru.argmax(1)))
  rows.append((acc,float(int(trueoi[i]) in tops[i]),float(est==int(tids[i]))))
 a=np.array(rows);return {'policy_acc':float(a[:,0].mean()),'obs_topk_recall':float(a[:,1].mean()),'exact':float(a[:,2].mean())}

def main():
 torch.set_num_threads(4);seed=81;torch.manual_seed(seed);np.random.seed(seed);random.seed(seed);codec=load_codec();split=lc.make_split(123);net=Proposal(160);opt=torch.optim.AdamW(net.parameters(),lr=2e-3,weight_decay=1e-5);rng=np.random.default_rng(seed+2);g=torch.Generator();g.manual_seed(seed+3);hist=[];t0=time.time()
 for step in range(1,1801):
  B=128;q=lc.sample_q(B,torch.device('cpu'),g);tids=rng.choice(split.train,size=B,replace=True);target=alienize(q,tids)
  with torch.no_grad():z=codec.encode(q.flatten(1),True);dq=codec.decode(z).view(B,64,4)
  N=int(rng.choice([8,12,16,24,32]));o,a,r,_=calib(target,N,.08,g);pl,sl=net(z,dq,o,a,r);yp,ys,_=obs_labels(tids);loss=F.cross_entropy(pl,yp)+F.binary_cross_entropy_with_logits(sl,ys)
  opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(net.parameters(),5);opt.step()
  if step==1 or step%200==0:
   with torch.no_grad():pa=(pl.argmax(-1)==yp).float().mean().item();sa=((sl>0)==(ys>0.5)).float().mean().item();exact=((pl.argmax(-1)==yp)&(((sl>0)==(ys>0.5)).all(-1))).float().mean().item()
   hist.append((step,float(loss),pa,sa,exact,time.time()-t0));print('step',step,'loss',round(float(loss),3),'perm',round(pa,3),'sign',round(sa,3),'exact',round(exact,3),'sec',round(time.time()-t0,1),flush=True)
 pd.DataFrame(hist,columns=['step','loss','perm_acc','sign_acc','exact','seconds']).to_csv('/mnt/data/iap_autonomous_grounding_gate1c/proposal_train.csv',index=False)
 torch.save(net.state_dict(),'/mnt/data/iap_autonomous_grounding_gate1c/proposal.pt')
 out=[]
 for N in [8,16,32]:
  for K in [1,4,8,16,32]:
   rr=eval_topk(net,codec,split.held_both,N,K,400,9000+N*10+K);rr.update({'N':N,'K':K});out.append(rr);print('EVAL',N,K,rr,flush=True)
 pd.DataFrame(out).to_csv('/mnt/data/iap_autonomous_grounding_gate1c/proposal_eval.csv',index=False)
if __name__=='__main__':main()
