import os, importlib.util, math, time, json
import numpy as np
import torch
import torch.nn.functional as F

HERE=os.path.dirname(os.path.abspath(__file__)); BASE=os.path.dirname(HERE)
spec=importlib.util.spec_from_file_location('lc',os.path.join(BASE,'learned_codec.py'))
lc=importlib.util.module_from_spec(spec); spec.loader.exec_module(lc)


def load_codec():
    ck=torch.load(os.path.join(BASE,'codec.pt'),map_location='cpu')
    m=lc.Codec(16); m.load_state_dict(ck['state_dict']); m.eval()
    for p in m.parameters(): p.requires_grad=False
    return m

STATES=torch.tensor(lc.STATES,dtype=torch.float32)


def sinkhorn(logits,temp=.4,iters=8):
    x=torch.exp(torch.clamp(logits/temp,-12,12))
    for _ in range(iters):
        x=x/(x.sum(-1,keepdim=True)+1e-9)
        x=x/(x.sum(-2,keepdim=True)+1e-9)
    return x


def reward_predict(dq, obs, act, Plog, slog, Alog, state_temp=6.0, sink_temp=.4):
    # dq [M,64,4], obs [M,N,4], act [M,N]
    P=sinkhorn(Plog,sink_temp)
    A=sinkhorn(Alog,sink_temp)
    s=torch.tanh(slog)
    c=torch.einsum('mnk,mk,mkj->mnj',obs,s,P)
    dist=((c[:,:,None,:]-STATES[None,None,:,:])**2).sum(-1)
    sw=F.softmax(-state_temp*dist,-1)
    # A rows observed actions, cols canonical actions. for each sample observed action, use A[row]
    aw=A.gather(1,act[:,:,None].expand(-1,-1,4)) # [M,N,4]
    q_at_obs=torch.einsum('mns,msa->mna',sw,dq)
    pred=(q_at_obs*aw).sum(-1)
    return pred,P,s,A


def hard_mapping(P,s,A):
    return P.argmax(-1), torch.sign(s), A.argmax(-1)


def mapping_to_tid(p,s,a):
    # returns tid or -1 if not a valid permutation / zero signs
    p=tuple(int(x) for x in p); s=tuple(int(1 if x>=0 else -1) for x in s); a=tuple(int(x) for x in a)
    try:
        oi=lc.OBS_TRANSFORMS.index((p,s)); ai=lc.ACTION_PERMS.index(a)
    except ValueError: return -1
    # MAP ordering is oi major then ai
    return oi*len(lc.ACTION_PERMS)+ai


def policy_acc_from_tid(dq,trueq,est_tid,true_tid):
    if est_tid<0: return 0.0
    pred=dq[lc.MAPS[est_tid]].reshape(64,4)
    target=trueq[lc.MAPS[true_tid]].reshape(64,4)
    return float(np.mean(pred.argmax(1)==target.argmax(1)))


def optimize_one(codec,q,true_tid,N=16,noise=.08,restarts=16,steps=250,lr=.12,seed=0):
    g=torch.Generator(); g.manual_seed(seed)
    with torch.no_grad():
        z=codec.encode(q.flatten()[None,:],True); dq=codec.decode(z).view(64,4)
    qflat=q.flatten().numpy();
    pos=torch.randint(0,256,(N,),generator=g); si=pos//4; act=pos%4; obs=STATES[si]
    r=torch.tensor(qflat[lc.MAPS[true_tid][pos.numpy()]],dtype=torch.float32)
    r=r+torch.randn(r.shape,generator=g)*noise
    M=restarts
    dqM=dq[None,:,:].repeat(M,1,1); obsM=obs[None,:,:].repeat(M,1,1); actM=act[None,:].repeat(M,1); rM=r[None,:].repeat(M,1)
    # random symmetry-breaking starts
    gg=torch.Generator(); gg.manual_seed(seed+1000)
    Plog=(torch.randn(M,4,4,generator=gg)*.35).requires_grad_()
    Alog=(torch.randn(M,4,4,generator=gg)*.35).requires_grad_()
    slog=(torch.randn(M,4,generator=gg)*.35).requires_grad_()
    opt=torch.optim.Adam([Plog,Alog,slog],lr=lr)
    best=None
    for st in range(steps):
        frac=st/max(steps-1,1)
        sink_temp=max(.10,.65*(1-frac)+.10*frac)
        state_temp=3.0+15.0*frac
        pred,P,s,A=reward_predict(dqM,obsM,actM,Plog,slog,Alog,state_temp,sink_temp)
        err=((pred-rM)**2).mean(-1)
        # discreteness/assignment regularization, modest and annealed
        entP=-(P.clamp_min(1e-8)*P.clamp_min(1e-8).log()).sum((-1,-2))/4
        entA=-(A.clamp_min(1e-8)*A.clamp_min(1e-8).log()).sum((-1,-2))/4
        sreg=((s.abs()-1)**2).mean(-1)
        loss=(err + (0.005+0.03*frac)*(entP+entA) + .01*sreg).mean()
        opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_([Plog,Alog,slog],10); opt.step()
        if st in (steps-1,):
            with torch.no_grad():
                pred,P,s,A=reward_predict(dqM,obsM,actM,Plog,slog,Alog,25.0,.08)
                errs=((pred-rM)**2).mean(-1)
                order=torch.argsort(errs)
                cands=[]
                for idx in order.tolist():
                    pp,ss,aa=hard_mapping(P[idx],s[idx],A[idx])
                    tid=mapping_to_tid(pp.tolist(),ss.tolist(),aa.tolist())
                    if tid>=0:
                        cands.append((float(errs[idx]),tid,pp,ss,aa))
                best=cands[0] if cands else (float('inf'),-1,None,None,None)
    acc=policy_acc_from_tid(dq.detach().numpy().reshape(-1),qflat,best[1],true_tid)
    return {'acc':acc,'est_tid':best[1],'true_tid':true_tid,'mse':best[0],'exact':float(best[1]==true_tid)}


def main():
    torch.set_num_threads(4); codec=load_codec(); split=lc.make_split(123); ids=split.held_both
    rng=np.random.default_rng(2026); gg=torch.Generator(); gg.manual_seed(2027)
    for N in [8,16,32]:
        out=[]; t=time.time()
        for i in range(40):
            q=lc.sample_q(1,torch.device('cpu'),gg)[0]
            tid=int(rng.choice(ids))
            out.append(optimize_one(codec,q,tid,N=N,restarts=12,steps=180,lr=.10,seed=5000+N*100+i))
        print('N',N,'mean acc',np.mean([x['acc'] for x in out]),'exact',np.mean([x['exact'] for x in out]),'median mse',np.median([x['mse'] for x in out]),'sec',time.time()-t,flush=True)
        print('acc distribution',np.quantile([x['acc'] for x in out],[0,.25,.5,.75,1]),flush=True)

if __name__=='__main__': main()
