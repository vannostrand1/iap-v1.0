import os,importlib.util,numpy as np,torch,time
import torch.nn.functional as F
HERE=os.path.dirname(os.path.abspath(__file__)); BASE=os.path.dirname(HERE);spec=importlib.util.spec_from_file_location('lc',os.path.join(BASE,'learned_codec.py'));lc=importlib.util.module_from_spec(spec);spec.loader.exec_module(lc)
STATES=torch.tensor(lc.STATES,dtype=torch.float32); PMATS=[]
for p in lc.OBS_PERMS:
 M=np.zeros((4,4),np.float32)
 for k,j in enumerate(p):M[k,j]=1
 PMATS.append(M)
PMATS=torch.tensor(np.stack(PMATS));AP=torch.tensor(np.array(lc.ACTION_PERMS),dtype=torch.long)

def load_codec():
 ck=torch.load(os.path.join(BASE,'codec.pt'),map_location='cpu');m=lc.Codec(16);m.load_state_dict(ck['state_dict']);m.eval();return m

def optimize(codec,q,tid,N=16,restarts=12,steps=160,seed=0,noise=.08):
 g=torch.Generator();g.manual_seed(seed);rng=np.random.default_rng(seed)
 with torch.no_grad():dq=codec.decode(codec.encode(q.flatten()[None,:],True)).view(64,4);qf=q.flatten().numpy()
 pos=rng.integers(0,256,size=N);si=torch.tensor(pos//4);ao=torch.tensor(pos%4);obs=STATES[si];r=torch.tensor(qf[lc.MAPS[tid][pos]]+rng.normal(0,noise,size=N),dtype=torch.float32)
 M=restarts;pl=(torch.randn(M,8,generator=g)*.3).requires_grad_();sl=(torch.randn(M,4,generator=g)*.3).requires_grad_();opt=torch.optim.Adam([pl,sl],lr=.12)
 obsM=obs[None].expand(M,-1,-1);rM=r[None].expand(M,-1);aoM=ao[None].expand(M,-1);dqM=dq[None].expand(M,-1,-1)
 for st in range(steps):
  frac=st/max(1,steps-1);pt=max(.08,.8*(1-frac)+.08*frac);state_temp=3+17*frac;tau=max(.01,.15*(1-frac)+.01*frac)
  w=F.softmax(pl/pt,-1);P=torch.einsum('mp,pij->mij',w,PMATS);s=torch.tanh(sl*2)
  c=torch.einsum('mnk,mk,mkj->mnj',obsM,s,P);dist=((c[:,:,None,:]-STATES[None,None])**2).sum(-1);sw=F.softmax(-state_temp*dist,-1);qc=torch.einsum('mns,msa->mna',sw,dqM)
  # predictions for 24 action permutations
  # canonical action for each perm/sample from observed action
  ca=AP[:,ao] # [24,N]
  pred=torch.gather(qc[:,None,:,:].expand(-1,24,-1,-1),3,ca[None,:,:,None].expand(M,-1,-1,1)).squeeze(-1)
  mse=((pred-rM[:,None,:])**2).mean(-1);soft=-tau*torch.logsumexp(-mse/tau,-1)
  ent=-(w.clamp_min(1e-8)*w.clamp_min(1e-8).log()).sum(-1);sreg=((s.abs()-1)**2).mean(-1);loss=(soft+.01*ent+.01*sreg).mean();opt.zero_grad();loss.backward();opt.step()
 with torch.no_grad():
  pis=pl.argmax(-1).numpy();sg=np.where(torch.tanh(sl*2).numpy()>=0,1,-1);best=(1e99,None)
  for m in range(M):
   fi=lc.FLIPS.index(tuple(int(x) for x in sg[m]));oi=int(pis[m])*16+fi
   # best action exhaustive 24 only
   vals=[]
   for ai in range(24):
    tt=oi*24+ai;vals.append(np.mean((dq.flatten().numpy()[lc.MAPS[tt][pos]]-r.numpy())**2))
   ai=int(np.argmin(vals));tt=oi*24+ai
   if vals[ai]<best[0]:best=(vals[ai],tt)
 est=best[1];pred=dq.flatten().numpy()[lc.MAPS[est]].reshape(64,4);tru=qf[lc.MAPS[tid]].reshape(64,4);acc=float(np.mean(pred.argmax(1)==tru.argmax(1)))
 return acc,float(est==tid),best[0]

def main():
 torch.set_num_threads(4);codec=load_codec();sp=lc.make_split(123);rng=np.random.default_rng(99);g=torch.Generator();g.manual_seed(100)
 for N in [8,16,32]:
  rr=[];t=time.time()
  for i in range(30):
   q=lc.sample_q(1,torch.device('cpu'),g)[0];tid=int(rng.choice(sp.held_both));rr.append(optimize(codec,q,tid,N,10,140,10000+N*100+i))
  a=np.array(rr);print('N',N,'policy',a[:,0].mean(),'exact',a[:,1].mean(),'mse',np.median(a[:,2]),'sec',time.time()-t,flush=True)
if __name__=='__main__':main()
