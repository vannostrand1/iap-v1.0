import os,importlib.util,numpy as np,torch,time,json,pandas as pd
import torch.nn as nn
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment
HERE=os.path.dirname(os.path.abspath(__file__)); BASE=HERE;spec=importlib.util.spec_from_file_location('lc',os.path.join(BASE,'learned_codec.py'));lc=importlib.util.module_from_spec(spec);spec.loader.exec_module(lc)
N_ACT=24;STATE_MAPS=[]
for oi in range(128):
 m=lc.MAPS[oi*N_ACT].reshape(64,4);STATE_MAPS.append((m[:,0]//4).astype(np.int64))
STATE_MAPS=torch.tensor(np.stack(STATE_MAPS),dtype=torch.long); AP=torch.tensor(np.array(lc.ACTION_PERMS),dtype=torch.long)

def load_codec():
 ck=torch.load(os.path.join(BASE,'codec.pt'),map_location='cpu');m=lc.Codec(16);m.load_state_dict(ck['state_dict']);m.eval();
 for p in m.parameters():p.requires_grad=False
 return m
class Critic(nn.Module):
 def __init__(self,w=96):
  super().__init__();self.net=nn.Sequential(nn.Linear(20,w),nn.GELU(),nn.Linear(w,w),nn.GELU(),nn.Linear(w,1))
 def forward(self,cost,counts):
  # cost B,128,4,4; counts B,4. normalize each observed-action row, append coverage counts
  den=counts[:,None,:,None].clamp_min(1.0);x=cost/den;scale=x.mean((-1,-2),keepdim=True).clamp_min(.02);x=x/scale
  cc=(counts/counts.sum(-1,keepdim=True).clamp_min(1.0))[:,None,:].expand(-1,128,-1)
  return self.net(torch.cat([x.flatten(-2),cc],-1)).squeeze(-1)

def make_batch(codec,B,N,ids,rng,g,noise=.08):
 q=lc.sample_q(B,torch.device('cpu'),g);tids=rng.choice(ids,size=B,replace=True);target=q.flatten(1).gather(1,torch.tensor(lc.MAPS[tids],dtype=torch.long)).view(B,64,4)
 with torch.no_grad():dq=codec.decode(codec.encode(q.flatten(1),True)).view(B,64,4)
 pos=torch.randint(0,256,(B,N),generator=g);si=pos//4;ao=pos%4;r=target.flatten(1).gather(1,pos)+torch.randn((B,N),generator=g)*noise
 # candidate canonical state indices B,128,N
 ci=STATE_MAPS[:,si].permute(1,0,2) # fancy index -> B? verify
 # gather q vectors
 bi=torch.arange(B)[:,None,None].expand(B,128,N);qv=dq[bi,ci] # B,128,N,4
 cost=torch.zeros(B,128,4,4);counts=torch.zeros(B,4)
 for aobs in range(4):
  mask=(ao==aobs).float();counts[:,aobs]=mask.sum(-1)
  # squared B,128,N,4 weighted by mask
  cost[:,:,aobs,:]=(((qv-r[:,None,:,None])**2)*mask[:,None,:,None]).sum(2)
 # exact profile cost target via 24 action perms (training signal derives only from reward consistency)
 # total for each permutation = sum rows cost[aobs, AP[p,aobs]]
 vals=[]
 for p in range(24):
  tot=0
  for aobs in range(4):tot=tot+cost[:,:,aobs,int(AP[p,aobs])]
  vals.append(tot/max(1,N))
 prof=torch.stack(vals,-1).min(-1).values
 return q,tids,dq,pos,r,cost,counts,prof

def solve_action(cost_one,N):
 c=cost_one.cpu().numpy();rows,cols=linear_sum_assignment(c);ap=np.zeros(4,dtype=int);ap[rows]=cols;return tuple(int(x) for x in ap),float(c[rows,cols].sum()/N)
def eval_net(net,codec,ids,N,tasks,seed,K=1):
 rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+1);rows=[]
 with torch.no_grad():
  q,tids,dq,pos,r,cost,counts,prof=make_batch(codec,tasks,N,ids,rng,g);pred=net(cost,counts);tops=pred.topk(min(K,128),largest=False,dim=-1).indices.cpu().numpy();qnp=q.flatten(1).numpy();dnp=dq.flatten(1).numpy();pnp=pos.numpy();profnp=prof.numpy();trueoi=lc.MAP_OBS[tids]
 for b in range(tasks):
  best=(1e99,None)
  for oi in tops[b]:
   ap,m=solve_action(cost[b,int(oi)],N);ai=lc.ACTION_PERMS.index(ap);tt=int(oi)*24+ai
   if m<best[0]:best=(m,tt)
  est=best[1];predq=dnp[b][lc.MAPS[est]].reshape(64,4);trueq=qnp[b][lc.MAPS[int(tids[b])]].reshape(64,4);acc=float(np.mean(predq.argmax(1)==trueq.argmax(1)))
  rows.append((acc,float(est==int(tids[b])),float(int(trueoi[b]) in tops[b]),float(int(profnp[b].argmin()) in tops[b])))
 a=np.array(rows);return {'N':N,'K':K,'policy_acc':float(a[:,0].mean()),'exact':float(a[:,1].mean()),'true_obs_recall':float(a[:,2].mean()),'best_profile_recall':float(a[:,3].mean())}
def main():
 torch.set_num_threads(4);seed=222;torch.manual_seed(seed);rng=np.random.default_rng(seed+1);g=torch.Generator();g.manual_seed(seed+2);codec=load_codec();sp=lc.make_split(123);net=Critic();opt=torch.optim.AdamW(net.parameters(),lr=2e-3);hist=[];t=time.time()
 for step in range(1,901):
  N=int(rng.choice([2,4,6,8,12,16,24,32]));_,_,_,_,_,cost,counts,prof=make_batch(codec,64,N,sp.train,rng,g);score=net(cost,counts)
  # distill reward-derived profile likelihood. pairwise/soft ranking is scale robust.
  target=F.softmax(-prof/0.03,-1);loss=-(target*F.log_softmax(-score,-1)).sum(-1).mean()
  opt.zero_grad();loss.backward();opt.step()
  if step==1 or step%200==0:
   with torch.no_grad():rec=(score.argmin(-1)==prof.argmin(-1)).float().mean().item();top8=(score.topk(8,largest=False).indices==prof.argmin(-1)[:,None]).any(-1).float().mean().item()
   hist.append((step,float(loss),rec,top8,time.time()-t));print('step',step,'loss',round(float(loss),3),'top1',round(rec,3),'top8',round(top8,3),'sec',round(time.time()-t,1),flush=True)
 pd.DataFrame(hist,columns=['step','loss','profile_top1','profile_top8','seconds']).to_csv(os.path.join(HERE,'results','critic_retrain.csv'),index=False);torch.save(net.state_dict(),os.path.join(HERE,'critic_retrained.pt'))
 out=[]
 for N in [8,16,32]:
  for K in [1,2,4,8,16]:
   rr=eval_net(net,codec,sp.held_both,N,400,5000+N*20+K,K);out.append(rr);print('EVAL',rr,flush=True)
 pd.DataFrame(out).to_csv(os.path.join(HERE,'results','critic_retrain_eval.csv'),index=False)
if __name__=='__main__':main()
