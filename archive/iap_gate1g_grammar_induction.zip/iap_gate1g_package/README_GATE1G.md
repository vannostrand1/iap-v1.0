# IAP Gate 1G — Grammar Induction / Semantic Operator Discovery

## Goal
Remove Gate 1F's human-authored signed-coordinate semantic grammar. The receiver should discover a useful semantic operator family from the geometry of its own state space, before reward evidence is used to decide what the teacher's 16-byte IAP message means.

## What changed
Gate 1F was explicitly told that an observation meaning was a signed permutation of four coordinates. Gate 1G is **not** given that grammar or the 128 legal observation transforms.

Instead, Gate 1G starts from random continuous 4x4 orthogonal operators and uses a generic manifold-alignment loop:

1. Apply the current 4x4 operator to all 64 alien states.
2. Find the minimum-cost one-to-one assignment from transformed states back to the observed state manifold (Hungarian assignment).
3. Refit the best orthogonal operator by Procrustes alignment.
4. Repeat until the operator either becomes an exact manifold automorphism or is rejected.
5. Deduplicate surviving automorphisms by their induced permutation of the 64 states.

No hidden transform ID and no hand-written signed-permutation rule is used in this discovery loop.

## Grammar-induction result
Primary run: 10,000 random continuous starts.

- Valid convergences: 1,451
- Unique discovered manifold automorphisms: **128**
- Post-hoc intersection with the environment's 128 true observation symmetries: **128/128**
- Spurious discovered symmetries: **0**
- Missed true symmetries: **0**

The comparison to the environment's true transform set is an **audit performed after discovery**; it is not used by the discovery algorithm.

The learned matrices themselves converged to a highly discrete structure without that structure being specified: every recovered 4x4 operator has four rounded nonzero entries, exact orthogonality to numerical precision, and zero measured distance from its nearest integer matrix in the saved diagnostics. In other words, the continuous symmetry learner rediscovered the signed-permutation family on its own.

### Discovery curve

| Random starts | Unique operators |
|---:|---:|
| 100 | 16 |
| 250 | 32 |
| 500 | 57 |
| 1,000 | 91 |
| 2,000 | 120 |
| 5,000 | 127 |
| 10,000 | **128** |

Independent 5,000-start discovery seeds recovered **127, 126, and 127** unique operators respectively. This shows that the structure is stable, while full 128/128 coverage still requires sufficient exploration.

## A compact induced grammar emerged
Rather than retain the 128 operators as an unstructured dictionary, a greedy closure analysis searched for a small set of discovered operators whose compositions regenerate the learned symmetry family.

It required only **three** discovered primitives:

- 1 primitive -> closure size 8
- 2 primitives -> closure size 64
- **3 primitives -> closure size 128**

Thus the receiver can represent the full learned semantic family as a three-operator compositional language.

## End-to-end transfer
The three induced primitives were composed to reconstruct their 128-member closure. The existing 16-byte learned IAP codec was then grounded against this **induced** semantic language using empirical reward consistency and active disagreement queries.

Hardest evaluation split: both observation and action transform components held out. Six seeds x 20 tasks = **120 tasks per N**.

| Semantic language | Interactions | Tasks | Policy transfer | Exact full transform |
|---|---:|---:|---:|---:|
| **3 induced primitives -> 128 closure** | **8** | 120 | **95.90%** | **90.83%** |
| **3 induced primitives -> 128 closure** | **12** | 120 | **96.51%** | **95.83%** |
| Equal-size random-bijection control | 8 | 60 | 26.98% | 0% |
| Equal-size random-bijection control | 12 | 60 | 28.28% | 0% |

Bootstrap 95% intervals for policy transfer:

- N=8: **94.88%–96.78%**
- N=12: **95.81%–97.12%**

The random-bijection control is important: merely giving the receiver 128 candidate state mappings does not transfer knowledge. The candidates must preserve the structure learned from the state manifold.

## Relation to Gate 1F
Gate 1F used a human-authored observation grammar but a learned/self-bootstrapped proposal policy. Gate 1G removes the human-authored grammar and slightly improves end-to-end accuracy because this implementation exhaustively evaluates the **induced** 128-member closure during grounding:

- Gate 1F: 93.44% at N=8; 95.91% at N=12
- Gate 1G: **95.90% at N=8; 96.51% at N=12**

That comparison must be interpreted carefully. The accuracy gain is not evidence that grammar induction is inherently superior; Gate 1G spends more inference search by scoring the complete induced closure.

## What Gate 1G demonstrates
Within this toy world, the receiver can recover the semantic transformation language from environmental structure rather than being told what the legal meanings are.

A useful decomposition is now:

```
state experience
     |
     v
continuous operator search
     |
     v
manifold-preserving operators
     |
     v
3 induced semantic primitives
     |
  composition
     v
semantic hypothesis language
     |
     + 16-byte IAP packet + reward evidence
     v
grounded teacher meaning
```

This removes two pieces of previous scaffolding:

1. the hand-written signed-permutation grammar;
2. the hand-written list of 128 legal observation transformations.

## Important remaining scaffolding
Gate 1G is **not** a universal grammar-free interpreter yet.

1. The operator class is still restricted to **orthogonal linear 4x4 maps**. That is much more generic than a signed-permutation grammar, but it is still a human choice of hypothesis class.
2. Discovery uses algorithmic Hungarian assignment + orthogonal Procrustes alignment rather than a learned neural proposal policy.
3. Grounding in this version evaluates the complete 128-member induced closure at inference.
4. The action side still uses exact 4x4 action assignment.
5. Active disagreement querying and the 16-byte IAP codec are retained.

Therefore the strongest accurate claim is:

> **Gate 1G demonstrates unsupervised induction of the complete semantic observation grammar from state-manifold structure, followed by successful IAP grounding in that induced language.**

It does not yet demonstrate open-ended discovery of arbitrary nonlinear semantic languages.

## Natural next gate
**Gate 1H: joint grammar induction + efficient proposal generation.** Keep the grammar learned from environmental structure, but remove exhaustive scoring of its closure. Train the Gate 1F-style self-bootstrapping proposer over *compositions of induced primitives* and require it to match Gate 1G's ~96% transfer while evaluating only a small fraction of the induced language.

A harder extension after 1H is to expand the operator class beyond linear orthogonal maps (small neural operators, nonlinear symbolic primitives, or learned latent-state automorphisms) before moving into the sequential Fruit Fly environment.

## Files
- `gate1g.py` — full operator discovery, closure induction, active grounding, controls, and evaluation.
- `replicate_discovery.py` — independent discovery-seed replication.
- `induced_operators.npz` — all discovered continuous operators, their 64-state maps, the three primitive generators, and full closure.
- `discovery_curve.csv` — convergence / coverage curve.
- `discovery_replication.csv` — independent discovery-seed results.
- `generator_closure.csv` — three-step compositional closure result.
- `operator_matrix_diagnostics.csv` — post-hoc operator-structure diagnostics.
- `gate1g_raw.csv` — task-level evaluation results.
- `gate1g_aggregate_with_ci.csv` — aggregate transfer results and bootstrap intervals.
- `gate1f_vs_gate1g.csv` — direct progression comparison.
- `gate1g_audit.json` and `summary.json` — explicit methodology/scaffolding audit.
