import numpy as np,time,sys,pandas as pd
from scipy.optimize import linear_sum_assignment
import os
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,HERE)
import learned_codec as lc
S=lc.STATES.astype(float)
def run(seed,n=5000,iters=10):
 r=np.random.default_rng(seed);u={};v=0;t=time.time()
 for i in range(n):
  A=r.normal(size=(4,4));W,R=np.linalg.qr(A);sg=np.sign(np.diag(R));sg[sg==0]=1;W*=sg[None,:]
  for _ in range(iters):
   Y=S@W.T;C=((Y[:,None,:]-S[None,:,:])**2).sum(-1);_,cols=linear_sum_assignment(C);T=S[cols];U,_,Vt=np.linalg.svd(T.T@S);W=U@Vt
  Y=S@W.T;C=((Y[:,None,:]-S[None,:,:])**2).sum(-1);_,cols=linear_sum_assignment(C);ass=C[np.arange(64),cols]
  if ass.max()<1e-8 and len(np.unique(cols))==64:v+=1;u[tuple(map(int,cols))]=1
 return {'seed':seed,'starts':n,'valid_convergences':v,'unique_operators':len(u),'elapsed_s':time.time()-t}
rows=[]
for seed in [3,4,5]:
 x=run(seed);rows.append(x);print(x,flush=True)
pd.DataFrame(rows).to_csv('/mnt/data/iap_gate1g_grammar_induction/discovery_replication.csv',index=False)
