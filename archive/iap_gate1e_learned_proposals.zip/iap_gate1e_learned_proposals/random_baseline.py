import os,json,torch,numpy as np,pandas as pd
import gate1e as g

def random_episode(dq,z,trueq,tid,total=8,start=2,seed=0,K=64,active=True):
 rng=np.random.default_rng(seed);pos=[];rr=[]
 for _ in range(start):
  p=int(rng.integers(256));pos.append(p);rr.append(trueq[g.lc.MAPS[tid][p]]+rng.normal(0,.08))
 while len(pos)<total:
  ids=rng.choice(g.M,size=K,replace=False);leaves=[(0.0,int(li),tuple(map(int,g.TOKENS[int(li)]))) for li in ids];hy=g.verify_proposals(dq,np.asarray(pos),np.asarray(rr),leaves)
  if active and len(hy)>=2:
   preds=[];valids=[];scores=[];fill=float(np.mean(dq))
   for s,li,ap,nlp in hy:
    pr,va=g.prediction_for_leaf(dq,li,ap,fill);preds.append(pr);valids.append(va);scores.append(s)
   preds=np.stack(preds);valids=np.stack(valids);scores=np.asarray(scores);tt=max(float(np.std(scores)),.02);w=np.exp(-(scores-scores.min())/(tt+1e-8));w/=w.sum();mu=(preds*w[:,None]).sum(0);var=((preds-mu[None])**2*w[:,None]).sum(0);vf=(valids*w[:,None]).sum(0);var+=2*vf*(1-vf);var[np.asarray(pos,dtype=int)]=-1;p=int(np.argmax(var))
  else:p=int(rng.integers(256))
  pos.append(p);rr.append(trueq[g.lc.MAPS[tid][p]]+rng.normal(0,.08))
 ids=rng.choice(g.M,size=K,replace=False);leaves=[(0.0,int(li),tuple(map(int,g.TOKENS[int(li)]))) for li in ids];hy=g.verify_proposals(dq,np.asarray(pos),np.asarray(rr),leaves);return hy[0]

def eval(N=8,tasks=20,seed=0,K=64):
 codec=g.load_codec();sp=g.lc.make_split(123);rng=np.random.default_rng(seed);tg=torch.Generator();tg.manual_seed(seed+1)
 with torch.no_grad():q=g.lc.sample_q(tasks,torch.device('cpu'),tg).flatten(1);z=codec.encode(q,True);dq=codec.decode(z)
 qn=q.numpy();zn=z.numpy();dn=dq.numpy();rows=[]
 for i in range(tasks):
  tid=int(rng.choice(sp.held_both));mse,li,ap,_=random_episode(dn[i],zn[i],qn[i],tid,N,2,seed*100000+i,K,True);acc=g.policy_metrics(dn[i],qn[i],li,ap,tid);oe,ae,fe=g.exact_semantics(li,ap,tid);rows.append((acc,oe,ae,fe))
 a=np.asarray(rows,float);return {'seed':seed,'N':N,'tasks':tasks,'K':K,'policy_transfer':float(a[:,0].mean()),'obs_exact':float(a[:,1].mean()),'action_exact':float(a[:,2].mean()),'full_exact':float(a[:,3].mean())},a

if __name__=='__main__':
 all=[]
 for N in [8,12]:
  for s in [1101,2202,3303]:
   r,a=eval(N,20,s,64);all.append(r);print(json.dumps(r),flush=True)
 df=pd.DataFrame(all);df.to_csv(os.path.join(g.HERE,'random64_multiseed.csv'),index=False);print(df.groupby('N')[['policy_transfer','obs_exact','action_exact','full_exact']].mean().to_string(),flush=True)
