import os,json,torch
import gate1e as g
codec=g.load_codec();net=g.ProposalNet();net.load_state_dict(torch.load(os.path.join(g.HERE,os.environ.get('MODEL','proposal_net_dagger.pt')),map_location='cpu'));net.eval()
N=int(os.environ.get('N','12'));seed=int(os.environ.get('SEED','1101'));tasks=int(os.environ.get('TASKS','20'));beam=int(os.environ.get('BEAM','32'))
df,s=g.evaluate(net,codec,N,tasks,seed,beam=beam,active=True);print(json.dumps(s),flush=True);df.to_csv(os.path.join(g.HERE,f'single_N{N}_b{beam}_s{seed}.csv'),index=False)
