import os,time,json,torch,numpy as np,pandas as pd
import torch.nn.functional as F
import gate1e as g

def collect(codec,net,tasks_per_N=70,seed=4444,beam=8):
 rng=np.random.default_rng(seed);tg=torch.Generator();tg.manual_seed(seed+1);sp=g.lc.make_split(123);groups=[];t0=time.time()
 for N in [2,4,6,8,12,16]:
  B=tasks_per_N
  with torch.no_grad():
   q=g.lc.sample_q(B,torch.device('cpu'),tg).flatten(1);z=codec.encode(q,True);dq=codec.decode(z)
  qn=q.numpy();zn=z.numpy();dn=dq.numpy()
  for b in range(B):
   tid=int(rng.choice(sp.train));pos=rng.integers(0,256,size=N);r=qn[b][g.lc.MAPS[tid][pos]]+rng.normal(0,.08,size=N)
   leaf_scores,_,_=g.full_leaf_scores(dn[b],pos,r)
   # generator's own visited final hypotheses -> train all their parents
   leaves,_=g.propose_beam(net,dn[b],zn[b],pos,r,beam)
   parents={()}
   for _,li,p in leaves:
    for d in range(4):parents.add(tuple(p[:d]))
   # plus reward-teacher greedy path to prevent drift
   pp=()
   for d in range(4):
    parents.add(pp);grp=g.make_group(dn[b],zn[b],pos,r,pp,leaf_scores);vals,toks=grp[1],grp[2];pp=pp+(int(toks[int(vals.argmin())]),)
   for p in parents:groups.append(g.make_group(dn[b],zn[b],pos,r,p,leaf_scores))
  print('collect',N,'groups',len(groups),'sec',round(time.time()-t0,1),flush=True)
 return groups

def tune(net,groups,seed=5555,epochs=2):
 rng=np.random.default_rng(seed);idx=rng.permutation(len(groups));cut=int(.88*len(idx));tr=idx[:cut];va=idx[cut:];opt=torch.optim.AdamW(net.parameters(),lr=8e-4,weight_decay=1e-5);hist=[];t0=time.time()
 def group_loss(gi):
  f,v,_=groups[int(gi)];x=torch.tensor(f);vals=torch.tensor(v);logits=net(x);spread=max(float(np.std(v)),.02);target=F.softmax(-(vals-vals.min())/(0.3*spread+0.008),dim=0);loss=-(target*F.log_softmax(logits,dim=0)).sum();acc=float(int(logits.argmax())==int(vals.argmin()));return loss,acc
 for ep in range(1,epochs+1):
  rng.shuffle(tr);ls=[];aa=[];opt.zero_grad();n=0
  for gi in tr:
   loss,ac=group_loss(gi);(loss/32).backward();n+=1;ls.append(float(loss.detach()));aa.append(ac)
   if n==32:
    torch.nn.utils.clip_grad_norm_(net.parameters(),5);opt.step();opt.zero_grad();n=0
  if n:torch.nn.utils.clip_grad_norm_(net.parameters(),5);opt.step();opt.zero_grad()
  if ep==1 or ep%2==0:
   with torch.no_grad():vv=[group_loss(x) for x in va[:min(600,len(va))]]
   row={'epoch':ep,'train_loss':float(np.mean(ls)),'train_acc':float(np.mean(aa)),'val_loss':float(np.mean([float(x[0]) for x in vv])),'val_acc':float(np.mean([x[1] for x in vv])),'seconds':time.time()-t0};hist.append(row);print('dagger',row,flush=True)
 torch.save(net.state_dict(),os.path.join(g.HERE,'proposal_net_dagger.pt'));pd.DataFrame(hist).to_csv(os.path.join(g.HERE,'dagger_train.csv'),index=False)

if __name__=='__main__':
 torch.set_num_threads(4);codec=g.load_codec();net=g.ProposalNet();net.load_state_dict(torch.load(os.path.join(g.HERE,'proposal_net.pt'),map_location='cpu'));groups=collect(codec,net);tune(net,groups)
