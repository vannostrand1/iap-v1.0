import os,torch,numpy as np,pandas as pd
import gate1e as g
codec=g.load_codec();net=g.ProposalNet();net.load_state_dict(torch.load(os.path.join(g.HERE,'proposal_net_dagger.pt'),map_location='cpu'));net.eval();sp=g.lc.make_split(123)

def episode(dq,z,tq,tid,N,seed,beam=64):
 rng=np.random.default_rng(seed);pos=[];rr=[];seen=set();calls=0
 for _ in range(2):
  p=int(rng.integers(256));pos.append(p);rr.append(tq[g.lc.MAPS[tid][p]]+rng.normal(0,.08))
 while len(pos)<N:
  leaves,_=g.propose_beam(net,dq,z,np.asarray(pos),np.asarray(rr),beam);seen.update(int(x[1]) for x in leaves);calls+=1;hy=g.verify_proposals(dq,np.asarray(pos),np.asarray(rr),leaves)
  preds=[];valids=[];scores=[];fill=float(np.mean(dq))
  for s,li,ap,nlp in hy:
   pr,va=g.prediction_for_leaf(dq,li,ap,fill);preds.append(pr);valids.append(va);scores.append(s)
  if len(hy)>=2:
   preds=np.stack(preds);valids=np.stack(valids);scores=np.asarray(scores);tt=max(float(np.std(scores)),.02);w=np.exp(-(scores-scores.min())/(tt+1e-8));w/=w.sum();mu=(preds*w[:,None]).sum(0);var=((preds-mu[None])**2*w[:,None]).sum(0);vf=(valids*w[:,None]).sum(0);var+=2*vf*(1-vf);var[np.asarray(pos,dtype=int)]=-1;p=int(np.argmax(var))
  else:p=int(rng.integers(256))
  pos.append(p);rr.append(tq[g.lc.MAPS[tid][p]]+rng.normal(0,.08))
 leaves,_=g.propose_beam(net,dq,z,np.asarray(pos),np.asarray(rr),beam);seen.update(int(x[1]) for x in leaves);calls+=1
 return len(seen),calls
rows=[]
for N in [8,12]:
 rng=np.random.default_rng(7000+N);tg=torch.Generator();tg.manual_seed(8000+N)
 with torch.no_grad():q=g.lc.sample_q(10,torch.device('cpu'),tg).flatten(1);z=codec.encode(q,True);dq=codec.decode(z)
 qn=q.numpy();zn=z.numpy();dn=dq.numpy()
 for i in range(10):
  tid=int(rng.choice(sp.held_both));u,c=episode(dn[i],zn[i],qn[i],tid,N,900000+N*1000+i);rows.append({'N':N,'task':i,'unique_complete_programs_across_episode':u,'grounding_calls':c})
df=pd.DataFrame(rows);df.to_csv(os.path.join(g.HERE,'coverage_audit.csv'),index=False);print(df.groupby('N').agg(mean_unique=('unique_complete_programs_across_episode','mean'),median_unique=('unique_complete_programs_across_episode','median'),max_unique=('unique_complete_programs_across_episode','max'),mean_calls=('grounding_calls','mean')).to_string())
