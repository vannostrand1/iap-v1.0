import os,json,torch,pandas as pd
import gate1e as g
codec=g.load_codec();net=g.ProposalNet();net.load_state_dict(torch.load(os.path.join(g.HERE,os.environ.get('MODEL','proposal_net.pt')),map_location='cpu'));net.eval()
N=int(os.environ.get('N','8'));tasks=int(os.environ.get('TASKS','20'));beam=int(os.environ.get('BEAM','16'));raw=[];ss=[]
for seed in [1101,2202,3303]:
 df,s=g.evaluate(net,codec,N,tasks,seed,beam=beam,active=True);raw.append(df);ss.append(s);print(json.dumps(s),flush=True)
a=pd.concat(raw);print('AGG',N,beam,a[['policy_transfer','obs_exact','action_exact','full_exact']].mean().to_dict(),flush=True)
a.to_csv(os.path.join(g.HERE,f'gate1e_N{N}_beam{beam}.csv'),index=False)
