import os,json,torch,pandas as pd
import gate1e as g
codec=g.load_codec();net=g.ProposalNet();net.load_state_dict(torch.load(os.path.join(g.HERE,'proposal_net.pt'),map_location='cpu'));net.eval()
rows=[];raw=[]
for N in [8,12]:
  for seed in [1101,2202,3303]:
    df,s=g.evaluate(net,codec,N,int(os.environ.get('TASKS','20')),seed,beam=int(os.environ.get('BEAM','8')),active=True)
    raw.append(df);rows.append(s);print(json.dumps(s),flush=True)
pd.concat(raw,ignore_index=True).to_csv(os.path.join(g.HERE,'gate1e_raw.csv'),index=False)
pd.DataFrame(rows).to_csv(os.path.join(g.HERE,'gate1e_multiseed.csv'),index=False)
allr=pd.concat(raw,ignore_index=True)
agg=allr.groupby('N').agg(policy_transfer=('policy_transfer','mean'),obs_exact=('obs_exact','mean'),action_exact=('action_exact','mean'),full_exact=('full_exact','mean'),ground_mse=('ground_mse','mean'),mean_expansions=('mean_expansions','mean')).reset_index()
agg.to_csv(os.path.join(g.HERE,'gate1e_aggregate.csv'),index=False);print(agg.to_string(index=False),flush=True)
