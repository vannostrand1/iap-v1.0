import os, itertools, time, json, math
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment
import importlib.util

HERE=os.path.dirname(os.path.abspath(__file__))
spec=importlib.util.spec_from_file_location('lc',os.path.join(HERE,'learned_codec.py'))
lc=importlib.util.module_from_spec(spec); spec.loader.exec_module(lc)

STATES=lc.STATES.astype(np.int8)
STI={tuple(map(int,s)):i for i,s in enumerate(STATES)}
ACTION_PERMS=np.asarray(lc.ACTION_PERMS,dtype=np.int64)

# 384-program unrestricted semantic grammar: for observed coordinate k=0..3,
# choose an unused canonical coordinate and a sign. 24 permutations * 16 signs.
PROGRAMS=[]; TOKENS=[]; STATE_MAPS=[]
for p in itertools.permutations(range(4)):
    for f in itertools.product([-1,1],repeat=4):
        tok=tuple(int(p[k])*2 + (1 if f[k]>0 else 0) for k in range(4))
        sm=[]
        for o in STATES:
            c=np.empty(4,dtype=np.int8)
            for k in range(4): c[p[k]]=int(o[k])*int(f[k])
            sm.append(STI.get(tuple(map(int,c)),-1))
        PROGRAMS.append((tuple(p),tuple(f))); TOKENS.append(tok); STATE_MAPS.append(sm)
TOKENS=np.asarray(TOKENS,dtype=np.int8)
STATE_MAPS=np.asarray(STATE_MAPS,dtype=np.int16)
M=len(PROGRAMS)
assert M==384

# Prefix -> full-program indices. Used ONLY by reward-derived training teacher, never inference.
PREFIX_LEAVES={():np.arange(M,dtype=np.int64)}
for d in range(1,5):
    groups={}
    for i,t in enumerate(TOKENS): groups.setdefault(tuple(map(int,t[:d])),[]).append(i)
    for k,v in groups.items(): PREFIX_LEAVES[k]=np.asarray(v,dtype=np.int64)

# Prefix-consistent canonical-state masks, constructed symbolically from coordinate assignments.
_POSS={}
def token_parts(tok): return int(tok)//2, (1 if int(tok)%2 else -1)
def possible_mask(prefix):
    prefix=tuple(int(x) for x in prefix)
    if prefix in _POSS:return _POSS[prefix]
    # mask[observed_state, canonical_state]
    mask=np.ones((64,64),dtype=bool)
    for oi,tok in enumerate(prefix):
        cj,sg=token_parts(tok)
        # c[cj] must equal o[oi]*sg
        mask &= (STATES[:,cj][None,:] == (STATES[:,oi]*sg)[:,None])
    _POSS[prefix]=mask
    return mask

def load_codec():
    ck=torch.load(os.path.join(HERE,'codec.pt'),map_location='cpu')
    m=lc.Codec(16); m.load_state_dict(ck['state_dict']); m.eval()
    for p in m.parameters():p.requires_grad=False
    return m

def full_leaf_scores(dq,pos,r,invalid_penalty=9.0):
    """Reward-derived teacher score for all 384 complete semantic programs.
    This is allowed during training only. No hidden transform labels are used."""
    pos=np.asarray(pos,dtype=np.int64); r=np.asarray(r,dtype=np.float32)
    si=pos//4; ao=pos%4; q=dq.reshape(64,4)
    ci=STATE_MAPS[:,si].astype(np.int64) # M,N
    valid=ci>=0; safe=np.maximum(ci,0)
    qv=q[safe] # M,N,4
    err=(qv-r[None,:,None])**2
    err=np.where(valid[:,:,None],err,invalid_penalty)
    cost=np.zeros((M,4,4),dtype=np.float32)
    for aobs in range(4):
        mask=(ao==aobs)
        if np.any(mask): cost[:,aobs,:]=err[:,mask,:].sum(1)
    # exact 4x4 action assignment by vectorized 24 action permutations
    vals=np.zeros((M,24),dtype=np.float32)
    for pi,ap in enumerate(ACTION_PERMS):
        v=np.zeros(M,dtype=np.float32)
        for aobs in range(4): v+=cost[:,aobs,ap[aobs]]
        vals[:,pi]=v
    bi=vals.argmin(1); score=vals[np.arange(M),bi]/max(1,len(pos))
    return score,bi,cost

def exact_leaf(dq,pos,r,leaf_idx,invalid_penalty=9.0):
    score,bi,_=full_leaf_scores_subset(dq,pos,r,[leaf_idx],invalid_penalty)
    return float(score[0]), ACTION_PERMS[int(bi[0])]

def full_leaf_scores_subset(dq,pos,r,idxs,invalid_penalty=9.0):
    idxs=np.asarray(idxs,dtype=np.int64);pos=np.asarray(pos,dtype=np.int64);r=np.asarray(r,dtype=np.float32)
    si=pos//4;ao=pos%4;q=dq.reshape(64,4);ci=STATE_MAPS[idxs][:,si].astype(np.int64);valid=ci>=0;safe=np.maximum(ci,0);qv=q[safe]
    err=(qv-r[None,:,None])**2;err=np.where(valid[:,:,None],err,invalid_penalty)
    cost=np.zeros((len(idxs),4,4),dtype=np.float32)
    for aobs in range(4):
        mm=(ao==aobs)
        if np.any(mm):cost[:,aobs,:]=err[:,mm,:].sum(1)
    vals=np.zeros((len(idxs),24),dtype=np.float32)
    for pi,ap in enumerate(ACTION_PERMS):
        for aobs in range(4):vals[:,pi]+=cost[:,aobs,ap[aobs]]
    bi=vals.argmin(1);score=vals[np.arange(len(idxs)),bi]/max(1,len(pos))
    return score,bi,cost

def candidate_tokens(prefix):
    used={token_parts(t)[0] for t in prefix}; out=[]
    for cj in range(4):
        if cj in used:continue
        out.extend([cj*2,cj*2+1])
    return out

def partial_feature(dq,z,pos,r,prefix):
    """Inference-time feature for one proposed semantic prefix. No full-map enumeration."""
    pos=np.asarray(pos,dtype=np.int64);r=np.asarray(r,dtype=np.float32);si=pos//4;ao=pos%4;q=dq.reshape(64,4)
    pm=possible_mask(prefix)
    per=np.full((len(pos),4),9.0,dtype=np.float32); impossible=0
    for i,s in enumerate(si):
        ids=np.flatnonzero(pm[int(s)])
        if len(ids)==0:
            impossible+=1; continue
        err=(q[ids]-float(r[i]))**2
        per[i]=err.min(0)
    cost=np.zeros((4,4),dtype=np.float32);counts=np.zeros(4,dtype=np.float32)
    for aobs in range(4):
        mm=(ao==aobs);counts[aobs]=mm.sum()
        if np.any(mm):cost[aobs]=per[mm].sum(0)
    den=np.maximum(counts[:,None],1.0);cn=cost/den;scale=max(float(cn.mean()),0.02);cn=cn/scale
    rows,cols=linear_sum_assignment(cost);lb=float(cost[rows,cols].sum()/max(1,len(pos)))
    A=np.zeros((4,4),dtype=np.float32)
    for oi,tok in enumerate(prefix):
        cj,sg=token_parts(tok);A[oi,cj]=float(sg)
    cov=counts/max(float(counts.sum()),1.0)
    zz=np.asarray(z,dtype=np.float32).reshape(-1)
    return np.concatenate([cn.reshape(-1),cov,A.reshape(-1),np.array([len(prefix)/4.0,math.log1p(lb),impossible/max(1,len(pos))],np.float32),zz]).astype(np.float32)

FD=16+4+16+3+16
class ProposalNet(nn.Module):
    def __init__(self,w=128):
        super().__init__();self.net=nn.Sequential(nn.Linear(FD,w),nn.GELU(),nn.Linear(w,w),nn.GELU(),nn.Linear(w,1))
    def forward(self,x): return self.net(x).squeeze(-1)

def make_group(dq,z,pos,r,parent,leaf_scores):
    toks=candidate_tokens(parent); feats=[]; vals=[]
    for tok in toks:
        ch=tuple(parent)+(int(tok),);feats.append(partial_feature(dq,z,pos,r,ch));vals.append(float(leaf_scores[PREFIX_LEAVES[ch]].min()))
    return np.stack(feats),np.asarray(vals,np.float32),np.asarray(toks,np.int64)

def teacher_path_groups(dq,z,pos,r,leaf_scores,rng,extra=2):
    groups=[];p=()
    for d in range(4):
        g=make_group(dq,z,pos,r,p,leaf_scores);groups.append(g);vals,toks=g[1],g[2];p=p+(int(toks[int(vals.argmin())]),)
    # Off-policy prefixes: sample arbitrary grammar programs and expose their parents.
    for _ in range(extra):
        li=int(rng.integers(M));d=int(rng.integers(0,4));parent=tuple(map(int,TOKENS[li,:d]));groups.append(make_group(dq,z,pos,r,parent,leaf_scores))
    return groups

def build_dataset(codec,tasks_per_N=120,seed=1001):
    rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+1);sp=lc.make_split(123);groups=[];t0=time.time()
    for N in [2,4,6,8,12,16]:
        B=tasks_per_N
        with torch.no_grad():
            q=lc.sample_q(B,torch.device('cpu'),g).flatten(1);z=codec.encode(q,True);dq=codec.decode(z)
        qn=q.numpy();zn=z.numpy();dn=dq.numpy()
        for b in range(B):
            tid=int(rng.choice(sp.train));pos=rng.integers(0,256,size=N);r=qn[b][lc.MAPS[tid][pos]]+rng.normal(0,.08,size=N)
            leaf,_,_=full_leaf_scores(dn[b],pos,r)
            groups.extend(teacher_path_groups(dn[b],zn[b],pos,r,leaf,rng,extra=2))
        print('dataset N',N,'groups',len(groups),'sec',round(time.time()-t0,1),flush=True)
    return groups

def train(codec,seed=2026,tasks_per_N=120,epochs=8):
    torch.set_num_threads(4);torch.manual_seed(seed);rng=np.random.default_rng(seed+1);groups=build_dataset(codec,tasks_per_N,seed+2);idx=rng.permutation(len(groups));cut=int(.85*len(idx));tr=idx[:cut];va=idx[cut:]
    net=ProposalNet();opt=torch.optim.AdamW(net.parameters(),lr=2e-3,weight_decay=1e-5);hist=[];t0=time.time()
    def one_group(gi,grad=True):
        f,v,_=groups[int(gi)];x=torch.tensor(f);vals=torch.tensor(v);logits=net(x)
        # Reward-derived soft teacher; scale to sibling difficulty.
        spread=max(float(np.std(v)),0.02);target=F.softmax(-(vals-vals.min())/(0.35*spread+0.01),dim=0)
        loss=-(target*F.log_softmax(logits,dim=0)).sum()
        acc=float(int(logits.argmax())==int(vals.argmin()))
        return loss,acc
    for ep in range(1,epochs+1):
        rng.shuffle(tr);losses=[];accs=[];opt.zero_grad();accum=0
        for gi in tr:
            loss,ac=one_group(gi);(loss/32).backward();accum+=1;losses.append(float(loss.detach()));accs.append(ac)
            if accum==32:
                nn.utils.clip_grad_norm_(net.parameters(),5);opt.step();opt.zero_grad();accum=0
        if accum:nn.utils.clip_grad_norm_(net.parameters(),5);opt.step();opt.zero_grad()
        if ep==1 or ep%4==0:
            with torch.no_grad():
                vv=[one_group(gi,False) for gi in va[:min(700,len(va))]];vl=np.mean([float(x[0]) for x in vv]);vaacc=np.mean([x[1] for x in vv])
            row={'epoch':ep,'train_loss':float(np.mean(losses)),'train_choice_acc':float(np.mean(accs)),'val_loss':float(vl),'val_choice_acc':float(vaacc),'seconds':time.time()-t0};hist.append(row);print('train',row,flush=True)
    torch.save(net.state_dict(),os.path.join(HERE,'proposal_net.pt'));pd.DataFrame(hist).to_csv(os.path.join(HERE,'proposal_train.csv'),index=False)
    return net,hist

def leaf_index_from_prefix(prefix):
    ids=PREFIX_LEAVES.get(tuple(prefix));
    if ids is None or len(ids)!=1:return None
    return int(ids[0])

def propose_beam(net,dq,z,pos,r,beam=8):
    beams=[(0.0,())];expanded=0
    for d in range(4):
        nxt=[]
        for nlp,p in beams:
            toks=candidate_tokens(p);feats=np.stack([partial_feature(dq,z,pos,r,p+(int(t),)) for t in toks]);
            with torch.no_grad():log=net(torch.tensor(feats)).numpy()
            # sibling policy probabilities
            mx=float(log.max());prob=np.exp(log-mx);prob/=prob.sum()
            for tok,pr in zip(toks,prob):
                nxt.append((nlp-math.log(max(float(pr),1e-9)),p+(int(tok),)))
            expanded += len(toks)
        nxt.sort(key=lambda x:x[0]);beams=nxt[:beam]
    leaves=[]
    for nlp,p in beams:
        li=leaf_index_from_prefix(p)
        if li is not None:leaves.append((nlp,li,p))
    return leaves,expanded

def verify_proposals(dq,pos,r,leaves):
    if not leaves:return []
    ids=[x[1] for x in leaves];scores,bi,_=full_leaf_scores_subset(dq,pos,r,ids);out=[]
    for x,s,aix in zip(leaves,scores,bi):out.append((float(s),int(x[1]),ACTION_PERMS[int(aix)],float(x[0])))
    out.sort(key=lambda y:y[0]);return out

def prediction_for_leaf(dq,leaf_idx,ap,invalid_fill=0.0):
    q=dq.reshape(64,4);sm=STATE_MAPS[int(leaf_idx)].astype(np.int64);arr=np.empty((64,4),dtype=np.float32);valid=sm>=0
    arr[valid]=q[sm[valid]][:,ap]
    if np.any(~valid):arr[~valid]=invalid_fill
    return arr.reshape(-1),np.repeat(valid,4)

def active_episode(net,dq,z,trueq,tid,total=8,start=2,seed=0,beam=8,active=True):
    rng=np.random.default_rng(seed);pos=[];rr=[];expanded=[]
    for _ in range(start):
        p=int(rng.integers(256));pos.append(p);rr.append(trueq[lc.MAPS[tid][p]]+rng.normal(0,.08))
    while len(pos)<total:
        leaves,n=propose_beam(net,dq,z,np.asarray(pos),np.asarray(rr),beam);expanded.append(n);hy=verify_proposals(dq,np.asarray(pos),np.asarray(rr),leaves)
        if active and len(hy)>=2:
            preds=[];valids=[];scores=[]
            fill=float(np.mean(dq))
            for s,li,ap,nlp in hy:
                pr,va=prediction_for_leaf(dq,li,ap,fill);preds.append(pr);valids.append(va);scores.append(s)
            preds=np.stack(preds);valids=np.stack(valids);scores=np.asarray(scores)
            tt=max(float(np.std(scores)),.02);w=np.exp(-(scores-scores.min())/(tt+1e-8));w/=w.sum();mu=(preds*w[:,None]).sum(0);var=((preds-mu[None])**2*w[:,None]).sum(0)
            # semantic invalidity disagreement is maximally informative.
            vf=(valids*w[:,None]).sum(0);var += 2.0*vf*(1-vf)
            if pos:var[np.asarray(pos,dtype=np.int64)]=-1
            p=int(np.argmax(var))
        else:p=int(rng.integers(256))
        pos.append(p);rr.append(trueq[lc.MAPS[tid][p]]+rng.normal(0,.08))
    leaves,n=propose_beam(net,dq,z,np.asarray(pos),np.asarray(rr),beam);expanded.append(n);hy=verify_proposals(dq,np.asarray(pos),np.asarray(rr),leaves)
    return hy[0] if hy else None,float(np.mean(expanded))

def policy_metrics(dq,trueq,leaf_idx,ap,tid):
    pred,valid=prediction_for_leaf(dq,leaf_idx,ap,float(np.mean(dq)));pred=pred.reshape(64,4);true=trueq[lc.MAPS[tid]].reshape(64,4);return float(np.mean(pred.argmax(1)==true.argmax(1)))

def exact_semantics(leaf_idx,ap,tid):
    sm=STATE_MAPS[int(leaf_idx)];true_map=lc.MAPS[int(tid)].reshape(64,4);true_sm=(true_map[:,0]//4).astype(np.int64);true_ap=(true_map[0]%4 + np.arange(4)*0) # unused
    obs_exact=bool(np.array_equal(sm,true_sm))
    full=np.full(256,-1,dtype=np.int64)
    if np.all(sm>=0):
        full=np.asarray([int(sm[s])*4+int(ap[a]) for s in range(64) for a in range(4)],dtype=np.int64)
    full_exact=bool(np.array_equal(full,lc.MAPS[int(tid)]))
    # action mapping exact conditional on canonical action identities
    true_actions=lc.MAPS[int(tid)].reshape(64,4)[0]%4
    act_exact=bool(np.array_equal(np.asarray(ap),true_actions))
    return obs_exact,act_exact,full_exact

def evaluate(net,codec,total=8,tasks=100,seed=0,beam=8,active=True):
    sp=lc.make_split(123);rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+1)
    with torch.no_grad():
        q=lc.sample_q(tasks,torch.device('cpu'),g).flatten(1);z=codec.encode(q,True);dq=codec.decode(z)
    qn=q.numpy();zn=z.numpy();dn=dq.numpy();rows=[];t0=time.time()
    for i in range(tasks):
        tid=int(rng.choice(sp.held_both));best,ne=active_episode(net,dn[i],zn[i],qn[i],tid,total,2,seed*100000+i,beam,active)
        if best is None: acc=0;oe=ae=fe=False;mse=99;li=-1
        else:
            mse,li,ap,nlp=best;acc=policy_metrics(dn[i],qn[i],li,ap,tid);oe,ae,fe=exact_semantics(li,ap,tid)
        rows.append({'seed':seed,'task':i,'N':total,'beam':beam,'active':active,'policy_transfer':acc,'obs_exact':float(oe),'action_exact':float(ae),'full_exact':float(fe),'ground_mse':float(mse),'mean_expansions':ne})
    df=pd.DataFrame(rows);summ={k:float(df[k].mean()) for k in ['policy_transfer','obs_exact','action_exact','full_exact','ground_mse','mean_expansions']};summ.update({'seed':seed,'N':total,'tasks':tasks,'beam':beam,'active':active,'seconds':time.time()-t0});return df,summ

def main():
    codec=load_codec();net,_=train(codec)
    if os.environ.get('GATE1E_TRAIN_ONLY')=='1': return
    raw=[];summ=[]
    for N in [8,12]:
        for seed in [1101,2202,3303]:
            df,s=evaluate(net,codec,N,20,seed,beam=8,active=True);raw.append(df);summ.append(s);print('EVAL',json.dumps(s,indent=2),flush=True)
    raw=pd.concat(raw,ignore_index=True);pd.DataFrame(summ).to_csv(os.path.join(HERE,'gate1e_multiseed.csv'),index=False);raw.to_csv(os.path.join(HERE,'gate1e_raw.csv'),index=False)
    agg=raw.groupby('N').agg(policy_transfer=('policy_transfer','mean'),obs_exact=('obs_exact','mean'),action_exact=('action_exact','mean'),full_exact=('full_exact','mean'),ground_mse=('ground_mse','mean'),mean_expansions=('mean_expansions','mean')).reset_index();agg.to_csv(os.path.join(HERE,'gate1e_aggregate.csv'),index=False);print('AGG\n',agg.to_string(index=False),flush=True)

if __name__=='__main__':main()
