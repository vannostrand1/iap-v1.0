# IAP Gate 1E — Learned Semantic Proposal Policy

## Goal
Remove Gate 1C's fixed 128-transform inference vocabulary and Gate 1D's inefficient stochastic proposal mechanism. Train a proposal policy to construct semantic mappings one token at a time, using reward-derived search scores rather than hidden transform labels.

## What is learned
`ProposalNet` scores partial semantic programs. A program assigns each observed coordinate to an unused canonical coordinate plus sign. The full grammar contains 384 signed coordinate permutations (24 coordinate permutations × 16 sign assignments), including invalid/non-world-symmetry meanings.

The proposal network is trained from reward-derived sibling preferences. For training only, an expensive oracle scores all 384 complete programs against observed reward residuals and exact 4×4 action assignment. The hidden transform ID is never used as the target. A DAgger-style pass adds prefixes visited by the proposal policy itself.

## Inference
Inference does **not** enumerate the old 128 legal transform dictionary. The proposal policy constructs candidate meanings autoregressively with beam search. Candidate leaves are verified against reward evidence, and active querying chooses observations/actions that maximize disagreement among surviving hypotheses.

Important limitation: training still uses exhaustive scoring over the 384-program grammar to produce reward-derived supervision. Gate 1E therefore demonstrates learned amortized proposal generation, not fully search-free learning.

## Final held-out results
Hardest split: both observation and action transform components held out.

| Interactions | Tasks | Policy transfer | Exact full transform |
|---:|---:|---:|---:|
| 8 | 120 | 93.58% | 83.33% |
| 12 | 120 | 96.20% | 90.83% |

Six seeds were used: 1101, 2202, 3303, 4404, 5505, 6606; 20 tasks per seed per interaction count.

Comparison from the preserved experiments:

- Gate 1C fixed-vocabulary learned-active: 93.40% at N=8; 96.05% at N=12.
- Gate 1D unrestricted stochastic generator: 82.92% at N=8; 85.96% at N=12.
- Gate 1E learned proposer + self-correction beam64: 93.58% at N=8; 96.20% at N=12.
- Random 64-leaf proposer: 67.37% at N=8; 71.67% at N=12.

## Interpretation
Gate 1E closes essentially all of the performance loss caused by removing the fixed inference dictionary. The useful decomposition is now:

1. Learned 16-byte knowledge codec.
2. Learned semantic proposal policy.
3. Reward-consistency verifier / action assignment.
4. Active evidence gathering.

The remaining scaffolding is the hand-defined semantic grammar and exhaustive reward-scoring teacher used during proposal training. The natural next gate is to remove one or both: learn the grammar/operators themselves, or train the proposer from online self-play / preference feedback without exhaustive leaf scoring.

## Key files
- `gate1e.py` — grammar, proposal model, training, inference, active grounding.
- `dagger.py` — self-correction / on-policy prefix training.
- `proposal_net.pt` and `proposal_net_dagger.pt` — learned proposal models.
- `gate1e_final_raw_120_each.csv` — final 240-task held-out sweep.
- `gate1e_final_aggregate.csv` — aggregate metrics and bootstrap CIs.
- `gate1e_comparison.csv` — comparison to Gates 1C/1D and random proposal baseline.
- `random64_multiseed.csv` — random-proposal control.
- `coverage_audit.csv` — audit of generated semantic-program coverage.
