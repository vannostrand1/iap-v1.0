import os,math,json,time,argparse,random
import numpy as np,pandas as pd,torch
import torch.nn.functional as F
import importlib.util
HERE=os.path.dirname(os.path.abspath(__file__))
spec=importlib.util.spec_from_file_location('g',os.path.join(HERE,'gate1e_base.py'));g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)

def softmax_np(x,t):
 x=np.asarray(x,np.float64)/max(t,1e-5);x-=x.max();p=np.exp(x);return p/p.sum()

def sample_cached(net,dq,z,pos,r,rng,temp,eps,cache):
 p=()
 for _ in range(4):
  if p not in cache:
   toks=g.candidate_tokens(p);fe=np.stack([g.partial_feature(dq,z,pos,r,p+(int(t),)) for t in toks]);
   with torch.no_grad():lo=net(torch.tensor(fe)).numpy()
   cache[p]=(toks,softmax_np(lo,temp))
  toks,pp=cache[p];pr=(1-eps)*pp+eps/len(pp);j=int(rng.choice(len(toks),p=pr));p=p+(int(toks[j]),)
 return int(g.leaf_index_from_prefix(p)),p

def mutate(p,rng):
 p=list(p);d=int(rng.integers(4))
 if rng.random()<.55:
  j=int(rng.integers(4));j=j if j!=d else (j+1)%4;c1,s1=g.token_parts(p[d]);c2,s2=g.token_parts(p[j]);p[d]=c2*2+(1 if s1>0 else 0);p[j]=c1*2+(1 if s2>0 else 0)
 else:
  c,s=g.token_parts(p[d]);p[d]=c*2+(0 if s>0 else 1)
 q=tuple(p);li=g.leaf_index_from_prefix(q);return int(li),q

def population(net,dq,z,pos,r,rng,K,temp,eps):
 cache={};c={};n0=max(16,int(K*.72))
 for _ in range(n0):li,p=sample_cached(net,dq,z,pos,r,rng,temp,eps,cache);c[li]=p
 seeds=list(c.values());tries=0
 while len(c)<K and tries<K*5:
  tries+=1
  if seeds and rng.random()<.82:li,p=mutate(seeds[int(rng.integers(len(seeds)))],rng)
  else:li,p=sample_cached(net,dq,z,pos,r,rng,temp,1.0,cache)
  c[li]=p
 ids=np.fromiter(c.keys(),dtype=np.int64);assert len(ids)<g.M
 sc,_,_=g.full_leaf_scores_subset(dq,pos,r,ids)
 pop=sorted([(float(s),int(i),c[int(i)]) for s,i in zip(sc,ids)],key=lambda x:x[0])
 return pop,len(ids)

def task_groups(pop,dq,z,pos,r,max_parents=24):
 # Use only reward scores of sampled leaves to build sibling preferences.
 score_by_prog={tuple(p):float(s) for s,_,p in pop}
 parents={()}
 for s,li,p in pop[:min(14,len(pop))]:
  for d in range(4):parents.add(tuple(p[:d]))
 # also expose some parents from non-elites to keep ranking broad
 for s,li,p in pop[14:min(30,len(pop)):3]:
  d=min(3,len(p)-1);parents.add(tuple(p[:d]))
 out=[]
 for parent in list(parents)[:max_parents]:
  child_best={}
  d=len(parent)
  for prog,s in score_by_prog.items():
   if prog[:d]==parent and d<4:
    tok=prog[d]; child_best[tok]=min(child_best.get(tok,1e9),s)
  if len(child_best)<2:continue
  toks=sorted(child_best);fe=np.stack([g.partial_feature(dq,z,pos,r,parent+(int(t),)) for t in toks]);vals=np.asarray([child_best[t] for t in toks],np.float32)
  spread=max(float(np.std(vals)),.02);target=softmax_np(-(vals-vals.min()),.35*spread+.01).astype(np.float32)
  out.append((fe,target,vals))
 return out

def train_groups(net,groups,rng,epochs=3,lr=1e-3):
 opt=torch.optim.AdamW(net.parameters(),lr=lr,weight_decay=1e-5);last=0;acc_last=0
 for ep in range(epochs):
  order=rng.permutation(len(groups));opt.zero_grad();acc=0;ls=[];aa=[]
  for ii in order:
   fe,ta,vals=groups[int(ii)];log=net(torch.tensor(fe));target=torch.tensor(ta);loss=-(target*F.log_softmax(log,dim=0)).sum();(loss/48).backward();ls.append(float(loss.detach()));aa.append(float(int(log.argmax())==int(np.argmin(vals))));acc+=1
   if acc==48:torch.nn.utils.clip_grad_norm_(net.parameters(),5);opt.step();opt.zero_grad();acc=0
  if acc:torch.nn.utils.clip_grad_norm_(net.parameters(),5);opt.step();opt.zero_grad()
  last=float(np.mean(ls));acc_last=float(np.mean(aa))
 return last,acc_last

def run_round(net,codec,rd,rng,tg,sp,B,K,Ns):
 with torch.no_grad():q=g.lc.sample_q(B,torch.device('cpu'),tg).flatten(1);z=codec.encode(q,True);dq=codec.decode(z)
 qn=q.numpy();zn=z.numpy();dn=dq.numpy();eps=max(.10,.62-.075*rd);temp=max(.68,1.55-.1*rd);groups=[];bests=[];sizes=[]
 for b in range(B):
  N=int(Ns[b%len(Ns)]);tid=int(rng.choice(sp.train));pos=rng.integers(0,256,size=N);rr=qn[b][g.lc.MAPS[tid][pos]]+rng.normal(0,.08,size=N)
  pop,sz=population(net,dn[b],zn[b],pos,rr,rng,K,temp,eps);groups.extend(task_groups(pop,dn[b],zn[b],pos,rr));bests.append(pop[0][0]);sizes.append(sz)
 loss,ac=train_groups(net,groups,rng,epochs=3,lr=1.5e-3 if rd<3 else 8e-4)
 return {'round':rd+1,'tasks':B,'K_cap':K,'groups':len(groups),'epsilon':eps,'temperature':temp,'mean_unique_scored':float(np.mean(sizes)),'max_unique_scored':int(np.max(sizes)),'mean_best_sampled_mse':float(np.mean(bests)),'train_loss':loss,'sampled_choice_acc':ac}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=0);ap.add_argument('--end',type=int,default=2);ap.add_argument('--B',type=int,default=90);ap.add_argument('--K',type=int,default=56);args=ap.parse_args()
 torch.set_num_threads(4);seed=9417;torch.manual_seed(seed);np.random.seed(seed);random.seed(seed);rng=np.random.default_rng(seed+args.start*10003);tg=torch.Generator();tg.manual_seed(seed+1+args.start*10003);sp=g.lc.make_split(123);codec=g.load_codec();net=g.ProposalNet();modelp=os.path.join(HERE,'proposal_net_gate1f_bandit.pt')
 if args.start>0 and os.path.exists(modelp):net.load_state_dict(torch.load(modelp,map_location='cpu'))
 rows=[];csvp=os.path.join(HERE,'bandit_training_rounds.csv')
 if os.path.exists(csvp):rows=pd.read_csv(csvp).to_dict('records')
 curricula=[(12,16),(8,12,16),(6,8,12,16),(4,6,8,12),(2,4,6,8,12),(2,4,6,8,12,16),(2,4,6,8,12,16),(2,4,6,8,12,16)]
 t0=time.time()
 for rd in range(args.start,args.end):
  row=run_round(net,codec,rd,rng,tg,sp,args.B,args.K,curricula[min(rd,len(curricula)-1)]);row['elapsed_chunk_s']=time.time()-t0;rows=[x for x in rows if int(x['round'])!=rd+1]+[row];rows=sorted(rows,key=lambda x:int(x['round']));pd.DataFrame(rows).to_csv(csvp,index=False);torch.save(net.state_dict(),modelp);print('ROUND',json.dumps(row),flush=True)
 audit={'rule':'training scores only self-proposed hypotheses','hidden_transform_labels_as_targets':False,'exhaustive_384_scoring':False,'grammar_size':g.M,'K_cap':args.K,'max_fraction_scored_per_task':args.K/g.M,'subset_scorer_only':True}
 open(os.path.join(HERE,'bandit_oracle_audit.json'),'w').write(json.dumps(audit,indent=2))
if __name__=='__main__':main()
