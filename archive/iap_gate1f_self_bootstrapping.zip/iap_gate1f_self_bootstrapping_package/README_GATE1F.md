# IAP Gate 1F — Self-Bootstrapping Semantic Proposal Generation

## Goal
Remove Gate 1E's exhaustive 384-program **training** oracle. The semantic proposer must improve using only meanings it actually proposes and the empirical reward consistency of those proposals.

Gate 1F intentionally retains the 16-byte learned IAP codec, the signed-coordinate semantic grammar, exact 4x4 action assignment within a proposed observation hypothesis, and active evidence gathering. Those are explicit remaining scaffolds rather than hidden in the headline claim.

## Training rule
For each training task:

1. The randomly initialized proposer constructs candidate semantic programs autoregressively.
2. Exploration mixes policy sampling with grammar-preserving mutations.
3. **At most 56 of the 384 complete semantic programs are reward-scored for that task.**
4. Only those sampled programs are used to form reward-derived sibling preferences.
5. The proposer is updated to favor sampled semantic branches whose descendants better explain the observed rewards.
6. No hidden transform ID is used as a supervised target.
7. No exhaustive `full_leaf_scores()` call is used by the Gate 1F trainer.

This is closer to reward-weighted population learning / cross-entropy-method self-bootstrapping than a literal GAN: the generator proposes meanings and empirical consistency supplies the selection pressure.

## Training budget
Main run:

- 6 curriculum rounds
- 570 training tasks total
- 56 scored semantic leaves per task
- Grammar size: 384 leaves
- Mean fraction of the complete grammar scored per task: **14.58%**
- Sampled leaf evaluations: **31,920**
- Exhaustive 384-leaf equivalent: **218,880**
- Reduction in complete-leaf reward evaluations: **85.42% (6.86x fewer)**

The training curriculum gradually reduces ambiguity: it begins with 12–16 reward observations and introduces 8, 6, 4, and 2-observation cases over later rounds.

## Main held-out evaluation
Hardest split: both observation and action transform components are held out from proposal training. Six evaluation seeds × 20 fresh tasks = 120 tasks per interaction count.

| Method | Interactions | Tasks | Policy transfer | Exact full transform |
|---|---:|---:|---:|---:|
| Gate 1F self-bootstrapped proposer | 8 | 120 | **93.44%** | **85.00%** |
| Gate 1E exhaustive-reward-trained proposer | 8 | 120 | 93.58% | 83.33% |
| Random 64-leaf proposer | 8 | 60 | 67.37% | 15.00% |
| Untrained proposer | 8 | 40 | 65.94% | 15.00% |
| Gate 1F self-bootstrapped proposer | 12 | 120 | **95.91%** | **94.17%** |
| Gate 1E exhaustive-reward-trained proposer | 12 | 120 | 96.20% | 90.83% |
| Random 64-leaf proposer | 12 | 60 | 71.67% | 11.67% |
| Untrained proposer | 12 | 40 | 66.29% | 10.00% |

Bootstrap 95% CIs for Gate 1F policy transfer:

- N=8: **91.15%–95.47%**
- N=12: **94.70%–96.89%**

Gate 1F therefore recovers essentially all of Gate 1E's policy-transfer performance without exhaustive semantic-program reward scoring during training.

## Learning curve
The mean best reward-consistency error among the 56 self-proposed candidates fell across the six main training rounds:

`0.2053 -> 0.1898 -> 0.1172 -> 0.0745 -> 0.0600 -> 0.0591`

Sampled sibling-choice accuracy rose from 55.7% in round 1 to 66.9% in round 6.

## Independent training-seed check
A second proposer was trained from a new random initialization using the same no-oracle procedure. Its best sampled error again fell from about 0.205 to 0.050. On a smaller fresh held-out check (30 tasks each):

- N=8: **95.94%** policy transfer
- N=12: **93.59%** policy transfer

This is not a full second 120-task replication, but it confirms that self-bootstrapping is reproducible rather than unique to the primary initialization.

## What Gate 1F demonstrates
The proposer no longer needs an exhaustive search teacher to learn which semantic constructions are useful. It can bootstrap a strong proposal distribution from its own sampled hypotheses and empirical survival:

```
16-byte IAP packet + alien experience
              |
              v
      semantic proposal policy
              |
       sampled hypotheses only
              |
              v
    empirical reward consistency
              |
              v
   reward-derived preferences
              |
              +---------> proposer update
              |
              v
      active evidence gathering
```

## What Gate 1F does *not* demonstrate
Three important structural priors remain:

1. **Hand-defined semantic grammar.** The receiver knows that meanings are signed permutations of four observed coordinates.
2. **Exact within-hypothesis action assignment.** For each proposed observation meaning, a 4x4 assignment solver evaluates the 24 action correspondences exactly.
3. **Hand-engineered partial-consistency features.** The proposal network receives structured features measuring how a partial semantic program agrees with observed rewards.

Therefore the precise claim is:

> Gate 1F removes the exhaustive semantic-program training oracle while preserving near-Gate-1E transfer performance.

It is not yet a grammar-free universal grounding system.

## Natural next gate
**Gate 1G: learned semantic operators / grammar induction.** Replace the predefined signed-permutation grammar and hand-engineered partial features with a learned set of semantic operators or a continuous program representation, while retaining empirical verification and active experimentation.

That would leave the environment itself—not a human-authored semantic vocabulary—as the primary source of meaning before moving the architecture into the sequential Fruit Fly world.

## Key files
- `source/gate1f_bandit.py` — primary no-exhaustive-oracle trainer.
- `source/gate1f_bandit_seed2.py` — independent training-seed replication.
- `source/gate1e_base.py` — preserved codec/grammar/inference substrate used by Gate 1F.
- `models/proposal_net_gate1f_bandit.pt` — primary trained proposer.
- `models/proposal_net_gate1f_bandit_seed2.pt` — independent trained proposer.
- `results/gate1f_final_raw_120_each.csv` — 240 held-out task evaluations.
- `results/gate1f_final_aggregate.csv` — final aggregates and bootstrap CIs.
- `results/gate1f_comparison.csv` — direct Gate 1E / Gate 1F / control comparison.
- `results/bandit_training_rounds.csv` — primary self-bootstrapping training curve.
- `audits/gate1f_static_audit.json` — explicit oracle/scaffolding audit.
