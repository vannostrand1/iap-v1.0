exec(open('/mnt/data/cross_arch_relay_pilot.py').read().split('def main():')[0])

def main2():
    teachers={}
    mlp=MLP(); print('train mlp',train_reward(mlp,6101,4096,.01),flush=True);teachers['mlp']=mlp
    tr=FeatureTransformer(); print('train transformer',train_reward(tr,6201,8192,.003),flush=True);teachers['transformer']=tr
    rows=[]
    for ti,(tk,m) in enumerate(teachers.items()):
        raw,pq,qa,fa=train_packet(normalized_q(m),seed=7300+ti)
        print('packet',tk,len(raw),qa,flush=True)
        for flyseed in [7102,7103]:
            sd=810000+flyseed+ti*100
            st=make_student('fly',sd,flyseed)
            cp=absorb(st,pq,sd+9,512,False)
            wrong=make_student('fly',sd,flyseed)
            cpw=absorb(wrong,pq,sd+9,512,True)
            row={'teacher':tk,'student':f'fly{flyseed}','cp':cp,'wrong':cpw}
            rows.append(row)
            print(tk,'->',flyseed,'good',cp[512],'wrong',cpw[512],flush=True)
    Path('/mnt/data/cross_arch_reverse.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__': main2()
