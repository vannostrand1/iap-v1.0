import sys, copy, struct, time, json
from pathlib import Path
from collections import deque
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

torch.set_num_threads(1)
BASE='/mnt/data/fly_gate3_source/unzip/fly_doom_gate3'
sys.path.insert(0,BASE)
from internal_model import InternalFly

INPUTS=6; ACTIONS=2
GRAPH_TEACH=f'{BASE}/data/graph_211.npz'
GRAPHS={7102:f'{BASE}/data/graph_223.npz',7103:f'{BASE}/data/graph_239.npz'}
FLY_CKPT='/mnt/data/iap_gate2b_convention_relay/teacher_fly_state.pt'


def target(ctx,stage):
    b=np.array([(ctx>>2)&1,(ctx>>1)&1,ctx&1],dtype=np.int64)
    if stage==0:return int(b[0]^b[1]^b[2])
    if stage==1:return int(b[0]^b[2])
    return int(b.sum()>=2)

def state(ctx,stage):
    b=np.array([(ctx>>2)&1,(ctx>>1)&1,ctx&1],np.float32)*2-1
    s=np.zeros(3,np.float32); s[stage]=1
    return np.r_[b,s].astype(np.float32)
ST=np.stack([state(c,s) for c in range(8) for s in range(3)])
TY=np.array([target(c,s) for c in range(8) for s in range(3)])
X=torch.tensor(ST); Y=torch.tensor(TY)

def metrics(model):
    model.eval()
    with torch.no_grad(): p=model(X).argmax(1).cpu().numpy()
    seq=[np.all(p[c*3:c*3+3]==TY[c*3:c*3+3]) for c in range(8)]
    return float(np.mean(p==TY)), float(np.mean(seq))

class MLP(nn.Module):
    def __init__(self,width=32):
        super().__init__(); self.net=nn.Sequential(nn.Linear(6,width),nn.Tanh(),nn.Linear(width,width),nn.Tanh(),nn.Linear(width,2))
    def forward(self,x):
        if x.ndim==1:x=x[None,:]
        return self.net(x)
    def project(self): pass

class FeatureTransformer(nn.Module):
    def __init__(self,d=24,heads=4):
        super().__init__()
        self.feature=nn.Parameter(torch.randn(6,d)*.05)
        self.val=nn.Linear(1,d,bias=False)
        self.cls=nn.Parameter(torch.randn(1,1,d)*.05)
        layer=nn.TransformerEncoderLayer(d_model=d,nhead=heads,dim_feedforward=48,dropout=0.0,activation='gelu',batch_first=True,norm_first=True)
        self.enc=nn.TransformerEncoder(layer,num_layers=1)
        self.out=nn.Linear(d,2)
    def forward(self,x):
        if x.ndim==1:x=x[None,:]
        B=x.shape[0]
        toks=self.feature[None,:,:]+self.val(x[:,:,None])
        cls=self.cls.expand(B,-1,-1)
        z=self.enc(torch.cat([cls,toks],1))[:,0]
        return self.out(z)
    def project(self): pass

class TinyPacket(nn.Module):
    def __init__(self):
        super().__init__(); self.l1=nn.Linear(6,8); self.l2=nn.Linear(8,2)
    def forward(self,x): return self.l2(torch.tanh(self.l1(x)))

def train_reward(model, seed, trials=4096, lr=.01):
    torch.manual_seed(seed); rng=np.random.default_rng(seed); rr=np.random.default_rng(seed+1)
    opt=torch.optim.Adam(model.parameters(),lr=lr)
    replay=deque(maxlen=256); pending=deque()
    for t in range(trials):
        idx=int(rng.integers(24)); st=ST[idx]; c=idx//3; s=idx%3
        with torch.no_grad(): q=model(torch.tensor(st)).flatten(); a=int(rng.integers(2)) if rng.random()<.25 else int(q.argmax())
        r=1. if a==target(c,s) else -1.
        # delayed bookkeeping exactly 3 subsequent decisions
        pending.append((st.copy(),a,r))
        if len(pending)>3:
            replay.append(pending.popleft())
            batch=[replay[j] for j in rr.integers(len(replay),size=min(32,len(replay)))]
            ss=torch.tensor(np.stack([b[0] for b in batch])); aa=torch.tensor([b[1] for b in batch]); rw=torch.tensor([b[2] for b in batch])
            pred=model(ss).gather(1,aa[:,None]).flatten(); loss=F.mse_loss(pred,rw)
            opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
            if hasattr(model,'project'): model.project()
    while pending:
        replay.append(pending.popleft())
        batch=[replay[j] for j in rr.integers(len(replay),size=min(32,len(replay)))]
        ss=torch.tensor(np.stack([b[0] for b in batch])); aa=torch.tensor([b[1] for b in batch]); rw=torch.tensor([b[2] for b in batch])
        pred=model(ss).gather(1,aa[:,None]).flatten(); loss=F.mse_loss(pred,rw)
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
    return metrics(model)

def normalized_q(model):
    model.eval()
    with torch.no_grad(): q=model(X).cpu().numpy().astype(np.float32)
    q=q-q.mean(1,keepdims=True)
    sc=max(float(np.max(np.abs(q))),1e-6); q=q/sc
    return q

def train_packet(q,seed=44):
    torch.manual_seed(seed); net=TinyPacket(); opt=torch.optim.Adam(net.parameters(),lr=.03)
    y=torch.tensor(q)
    for _ in range(2500):
        p=net(X); loss=F.mse_loss(p,y); opt.zero_grad();loss.backward();opt.step()
    with torch.no_grad(): f=net(X).cpu().numpy()
    arrays=[];scales=[]
    for p in [net.l1.weight,net.l1.bias,net.l2.weight,net.l2.bias]:
        a=p.detach().numpy(); s=max(float(np.max(np.abs(a)))/127,1e-8); z=np.clip(np.round(a/s),-127,127).astype(np.int8); arrays.append(z);scales.append(s)
    raw=b'IAPCV2\0'+struct.pack('<4f',*scales)+b''.join(a.tobytes() for a in arrays)
    w1=arrays[0].astype(np.float32)*scales[0];b1=arrays[1].astype(np.float32)*scales[1];w2=arrays[2].astype(np.float32)*scales[2];b2=arrays[3].astype(np.float32)*scales[3]
    pq=np.tanh(ST@w1.T+b1)@w2.T+b2
    return raw,pq,float(np.mean(pq.argmax(1)==TY)),float(np.mean(f.argmax(1)==TY))

def make_student(kind,seed,flyseed=None):
    torch.manual_seed(seed)
    if kind=='mlp': return MLP()
    if kind=='transformer': return FeatureTransformer()
    if kind=='fly': return InternalFly(GRAPHS[flyseed],flyseed,inputs=6,actions=2)
    raise ValueError(kind)

def absorb(model,pq,seed,budget=512,wrong=False,lr=None):
    if lr is None: lr=.03 if isinstance(model,InternalFly) else .01
    opt=torch.optim.Adam(model.parameters(),lr=lr); rng=np.random.default_rng(seed); buf=[]
    checkpoints={0:metrics(model)}
    for i in range(1,budget+1):
        idx=int(rng.integers(24)); t=pq[idx].copy(); t=t[::-1].copy() if wrong else t
        buf.append((ST[idx].copy(),t.copy()))
        ids=rng.integers(len(buf),size=min(32,len(buf)))
        xs=torch.tensor(np.stack([buf[j][0] for j in ids])); ts=torch.tensor(np.stack([buf[j][1] for j in ids]))
        loss=F.mse_loss(model(xs),ts);opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
        if hasattr(model,'project'):model.project()
        if i in [32,64,128,256,512]: checkpoints[i]=metrics(model)
    return checkpoints

def main():
    # teacher models
    fly=InternalFly(GRAPH_TEACH,7101,inputs=6,actions=2);fly.load_state_dict(torch.load(FLY_CKPT,weights_only=True));
    teachers={'fly':fly}
    print('teacher fly',metrics(fly),flush=True)
    mlp=MLP(); print('train mlp',train_reward(mlp,6101,4096,.01),flush=True);teachers['mlp']=mlp
    tr=FeatureTransformer(); print('train transformer',train_reward(tr,6201,8192,.003),flush=True);teachers['transformer']=tr
    packets={}
    for k,m in teachers.items():
        raw,pq,qa,fa=train_packet(normalized_q(m),seed=7000+len(k));packets[k]=(raw,pq)
        print('packet',k,len(raw),qa,fa,flush=True)
    rows=[]
    # focus cross architecture, two fly graphs and 3 conventional seeds
    for tk,(raw,pq) in packets.items():
        for flyseed in [7102,7103]:
            for rep in [1,2]:
                sd=800000+flyseed*10+rep
                m=make_student('fly',sd,flyseed)
                cp=absorb(m,pq,sd+9,512,False)
                rows.append({'teacher':tk,'student':f'fly{flyseed}','rep':rep,'cp':cp})
                print(tk,'->fly',flyseed,rep,cp[512],flush=True)
        if tk=='fly':
            for sk in ['mlp','transformer']:
                for rep in [1,2,3,4]:
                    sd=900000+rep+(0 if sk=='mlp' else 100)
                    m=make_student(sk,sd)
                    cp=absorb(m,pq,sd+7,512,False)
                    rows.append({'teacher':tk,'student':sk,'rep':rep,'cp':cp})
                    print(tk,'->',sk,rep,cp[512],flush=True)
    Path('/mnt/data/cross_arch_pilot.json').write_text(json.dumps({'rows':rows},indent=2))

if __name__=='__main__':main()
