exec(open('/mnt/data/cross_arch_relay_pilot.py').read().split('def main():')[0])
tr=FeatureTransformer();train_reward(tr,6201,8192,.003);raw,pq,qa,fa=train_packet(normalized_q(tr),seed=7501)
rows=[]
for flyseed,rep in [(7102,1),(7102,3),(7103,3)]:
    ti=1;sd=830000+flyseed+ti*1000+rep*17
    m=make_student('fly',sd,flyseed);cp=absorb(m,pq,sd+9,768,False)
    rows.append({'fly':flyseed,'rep':rep,'cp':cp});print(flyseed,rep,cp.get(512),metrics(m),flush=True)
Path('/mnt/data/transformer_to_fly_768.json').write_text(json.dumps(rows,indent=2))
