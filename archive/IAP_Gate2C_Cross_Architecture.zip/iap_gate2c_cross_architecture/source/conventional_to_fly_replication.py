exec(open('/mnt/data/cross_arch_relay_pilot.py').read().split('def main():')[0])

def build_teachers():
    mlp=MLP();train_reward(mlp,6101,4096,.01)
    tr=FeatureTransformer();train_reward(tr,6201,8192,.003)
    return {'mlp':mlp,'transformer':tr}

def main2():
    rows=[];out=Path('/mnt/data/cross_arch_reverse_repl.json')
    for ti,(tk,m) in enumerate(build_teachers().items()):
        raw,pq,qa,fa=train_packet(normalized_q(m),seed=7500+ti)
        for flyseed in [7102,7103]:
            for rep in [2,3]:
                sd=830000+flyseed+ti*1000+rep*17
                st=make_student('fly',sd,flyseed);cp=absorb(st,pq,sd+9,512,False)
                row={'teacher':tk,'student':f'fly{flyseed}','rep':rep,'cp':cp};rows.append(row);out.write_text(json.dumps(rows,indent=2));print(tk,flyseed,rep,cp[512],flush=True)
if __name__=='__main__':main2()
