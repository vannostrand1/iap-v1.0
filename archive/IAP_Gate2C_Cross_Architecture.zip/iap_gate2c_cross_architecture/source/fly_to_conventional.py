exec(open('/mnt/data/cross_arch_relay_pilot.py').read().split('def main():')[0])

def main2():
    fly=InternalFly(GRAPH_TEACH,7101,inputs=6,actions=2);fly.load_state_dict(torch.load(FLY_CKPT,weights_only=True));print('fly teacher',metrics(fly),flush=True)
    raw,pq,qa,fa=train_packet(normalized_q(fly),seed=7401);print('packet',len(raw),qa,flush=True)
    rows=[]; out=Path('/mnt/data/cross_arch_forward.json')
    for sk in ['mlp','transformer']:
      for rep in [1,2,3]:
        sd=920000+(100 if sk=='transformer' else 0)+rep
        m=make_student(sk,sd);cp=absorb(m,pq,sd+5,256,False)
        w=make_student(sk,sd);cpw=absorb(w,pq,sd+5,256,True)
        row={'teacher':'fly','student':sk,'rep':rep,'cp':cp,'wrong':cpw};rows.append(row);out.write_text(json.dumps(rows,indent=2));print('fly->',sk,rep,cp[256],'wrong',cpw[256],flush=True)
if __name__=='__main__': main2()
