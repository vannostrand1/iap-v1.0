from __future__ import annotations
import argparse, csv, json, struct, sys
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

torch.set_num_threads(1)
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from internal_model import InternalFly

# ---------- canonical teacher-side task support ----------
def target(ctx:int, stage:int)->int:
    b=[(ctx>>2)&1,(ctx>>1)&1,ctx&1]
    if stage==0: return b[0]^b[1]^b[2]
    if stage==1: return b[0]^b[2]
    return int(sum(b)>=2)

def build_states():
    st=[];ty=[]
    for c in range(8):
        bits=np.array([(c>>2)&1,(c>>1)&1,c&1],np.float32)*2-1
        for s in range(3):
            stage=np.zeros(3,np.float32); stage[s]=1
            st.append(np.r_[bits,stage]); ty.append(target(c,s))
    return np.stack(st).astype(np.float32),np.array(ty,np.int64)
ST,TY=build_states()

# ---------- 97-byte architecture-neutral packet ----------
def load_packet(path:Path):
    raw=path.read_bytes(); assert raw[:7]==b'IAPCV2\0' and len(raw)==97
    scales=struct.unpack('<4f',raw[7:23]); off=23
    w1=np.frombuffer(raw[off:off+48],dtype=np.int8).astype(np.float32).reshape(8,6)*scales[0]; off+=48
    b1=np.frombuffer(raw[off:off+8],dtype=np.int8).astype(np.float32)*scales[1]; off+=8
    w2=np.frombuffer(raw[off:off+16],dtype=np.int8).astype(np.float32).reshape(2,8)*scales[2]; off+=16
    b2=np.frombuffer(raw[off:off+2],dtype=np.int8).astype(np.float32)*scales[3]
    def f(x):
        x=np.asarray(x,dtype=np.float32)
        return np.tanh(x@w1.T+b1)@w2.T+b2
    return raw,f

PACKETS={}
for name in ['transformer','fly']:
    raw,fn=load_packet(ROOT/f'packets/{name}_teacher_97b.iap')
    PACKETS[name]=(raw,fn)

# ---------- unknown alien sensor physics ----------
def make_alien(seed:int,outdim:int=8):
    r=np.random.default_rng(seed)
    # local chain i is an anonymous permutation of source context identities.
    ctx_perm=r.permutation(8)
    action_swap=int(r.integers(2))
    source_idx=np.array([ctx_perm[i]*3+s for i in range(8) for s in range(3)],dtype=int)
    X=ST[source_idx]
    # No source coordinate is preserved directly: every alien channel is a dense nonlinear mixture.
    A=r.normal(size=(outdim,6)).astype(np.float32)/np.sqrt(6)
    B=r.normal(size=(outdim,6)).astype(np.float32)/np.sqrt(6)
    bias=r.uniform(-.4,.4,outdim).astype(np.float32)
    Z=X@A.T+bias; W=X@B.T
    Y=(np.tanh(1.15*Z)+.12*W**3/(1+W**2)).astype(np.float32)
    # local normalization only; no teacher coordinate statistics are used.
    Y=(Y-Y.mean(0,keepdims=True))/(Y.std(0,keepdims=True)+1e-4)
    tgt=TY[source_idx]^action_swap
    return {'Y':Y,'tgt':tgt,'ctx_perm':ctx_perm,'swap':action_swap,'source_idx':source_idx}

# ---------- relational semantic grounding ----------
def feasible(comp:np.ndarray,fixed=None)->bool:
    """Does this 8x8 compatibility graph admit a perfect matching?"""
    c=comp.copy(); n=8
    if fixed is not None:
        i,j=fixed
        if not c[i,j]: return False
        c[i,:]=False; c[i,j]=True
        for ii in range(n):
            if ii!=i: c[ii,j]=False
    match=[-1]*n
    def dfs(i,seen):
        for j in range(n):
            if c[i,j] and not seen[j]:
                seen[j]=True
                if match[j]<0 or dfs(match[j],seen):
                    match[j]=i; return True
        return False
    for i in range(n):
        if not dfs(i,[False]*n): return False
    return True

def semantic_ground(packet_fn,true,budget:int=18):
    """
    Ground by relation, not by coordinate inversion.
    Source atlas rows are ordered as eight anonymous three-node temporal chains.
    Recipient observes the same chain structure locally but not the context correspondence or action labels.
    """
    srcq=packet_fn(ST).astype(np.float32)
    srcpred=srcq.argmax(1).reshape(8,3)
    comps=[np.ones((8,8),bool),np.ones((8,8),bool)] # one compatibility matrix per possible action-label swap
    alive=[True,True]; queried=[]
    for _ in range(budget):
        probs=np.zeros((8,3),float); counts=np.zeros((8,3),float)
        for sw in [0,1]:
            if not alive[sw] or not feasible(comps[sw]): continue
            for i in range(8):
                js=[j for j in range(8) if comps[sw][i,j] and feasible(comps[sw],(i,j))]
                for s in range(3):
                    for j in js:
                        probs[i,s]+=int(srcpred[j,s])^sw; counts[i,s]+=1
        frac=np.divide(probs,counts,out=np.full_like(probs,.5),where=counts>0)
        disagreement=.5-np.abs(frac-.5)
        for q in queried: disagreement[q//3,q%3]=-1
        qidx=int(np.argmax(disagreement)); i,s=divmod(qidx,3); queried.append(qidx)
        observed_pref=int(true['tgt'][qidx]) # one reward-bearing calibration query
        for sw in [0,1]:
            if not alive[sw]: continue
            for j in range(8):
                if comps[sw][i,j] and ((int(srcpred[j,s])^sw)!=observed_pref): comps[sw][i,j]=False
            if not feasible(comps[sw]): alive[sw]=False
    # Average Q-values over all still-feasible relational interpretations.
    qout=np.zeros((24,2),np.float32); nout=np.zeros(24,np.float32)
    for sw in [0,1]:
        if not alive[sw] or not feasible(comps[sw]): continue
        for i in range(8):
            js=[j for j in range(8) if comps[sw][i,j] and feasible(comps[sw],(i,j))]
            for s in range(3):
                idx=i*3+s
                for j in js:
                    q=srcq[j*3+s].copy()
                    if sw: q=q[::-1]
                    qout[idx]+=q; nout[idx]+=1
    qout/=np.maximum(nout[:,None],1)
    pred=qout.argmax(1)
    seq=np.mean([np.all(pred[c*3:c*3+3]==true['tgt'][c*3:c*3+3]) for c in range(8)])
    return {'q':qout,'policy_acc':float(np.mean(pred==true['tgt'])),'sequence_acc':float(seq),'queries':queried,
            'alive_swaps':int(sum(alive)),'candidate_edges':int(sum(c.sum() for c,a in zip(comps,alive) if a))}

# ---------- recipient architectures ----------
class FeatureTransformerN(nn.Module):
    def __init__(self,nin,d=24,heads=4):
        super().__init__(); self.nin=nin
        self.feature=nn.Parameter(torch.randn(nin,d)*.05)
        self.val=nn.Linear(1,d,bias=False)
        self.cls=nn.Parameter(torch.randn(1,1,d)*.05)
        layer=nn.TransformerEncoderLayer(d_model=d,nhead=heads,dim_feedforward=48,dropout=0.0,activation='gelu',batch_first=True,norm_first=True)
        self.enc=nn.TransformerEncoder(layer,num_layers=1); self.out=nn.Linear(d,2)
    def forward(self,x):
        if x.ndim==1: x=x[None,:]
        B=x.shape[0]
        toks=self.feature[None,:,:]+self.val(x[:,:,None])
        z=self.enc(torch.cat([self.cls.expand(B,-1,-1),toks],1))[:,0]
        return self.out(z)
    def project(self): pass

def make_student(kind,seed,nin=8,flyseed=None):
    torch.manual_seed(seed)
    if kind=='transformer': return FeatureTransformerN(nin)
    if kind=='fly':
        graph=ROOT/f'data/graph_{223 if flyseed==7102 else 239}.npz'
        return InternalFly(str(graph),flyseed,inputs=nin,actions=2)
    raise ValueError(kind)

def metrics(model,Y,tgt):
    model.eval()
    with torch.no_grad(): p=model(torch.tensor(Y)).argmax(1).cpu().numpy()
    seq=np.mean([np.all(p[c*3:c*3+3]==tgt[c*3:c*3+3]) for c in range(8)])
    return float(np.mean(p==tgt)),float(seq)

def absorb(model,Y,target_q,tgt,seed,budget=512,lr=None):
    if lr is None: lr=.03 if isinstance(model,InternalFly) else .01
    opt=torch.optim.Adam(model.parameters(),lr=lr); rng=np.random.default_rng(seed); buf=[]
    cps={0:metrics(model,Y,tgt)}
    for i in range(1,budget+1):
        k=int(rng.integers(24)); buf.append((Y[k].copy(),target_q[k].copy()))
        ids=rng.integers(len(buf),size=min(32,len(buf)))
        xs=torch.tensor(np.stack([buf[j][0] for j in ids])); ts=torch.tensor(np.stack([buf[j][1] for j in ids]))
        loss=F.mse_loss(model(xs),ts); opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.); opt.step()
        if hasattr(model,'project'): model.project()
        if i in [64,128,256,512] or i==budget: cps[i]=metrics(model,Y,tgt)
    return cps

def direct_query_only(model,Y,tgt,idxs,seed,steps=512,lr=None):
    if lr is None: lr=.03 if isinstance(model,InternalFly) else .01
    opt=torch.optim.Adam(model.parameters(),lr=lr); rng=np.random.default_rng(seed)
    qtar=np.stack([np.where(np.arange(2)==a,1.,-1.) for a in tgt]).astype(np.float32)
    for _ in range(steps):
        ids=rng.choice(idxs,size=min(32,len(idxs)),replace=True)
        x=torch.tensor(Y[ids]); t=torch.tensor(qtar[ids]); loss=F.mse_loss(model(x),t)
        opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.); opt.step()
        if hasattr(model,'project'): model.project()
    return metrics(model,Y,tgt)

# ---------- experiment modes ----------
def run_grounding(reps=100,outdim=8):
    rows=[]
    for teacher in ['transformer','fly']:
        p=PACKETS[teacher][1]
        for b in [4,6,8,10,12,14,16,18]:
            for rep in range(reps):
                true=make_alien(300000+(0 if teacher=='transformer' else 100000)+b*1000+rep,outdim)
                g=semantic_ground(p,true,b)
                rows.append({'teacher':teacher,'budget':b,'rep':rep,'policy_acc':g['policy_acc'],'sequence_acc':g['sequence_acc']})
    return rows

def run_transfer(reps=12,outdim=8,budget=512,queries=18):
    rows=[]
    for direction in ['t2f','f2t']:
        teacher='transformer' if direction=='t2f' else 'fly'; p=PACKETS[teacher][1]
        for rep in range(reps):
            seed=200000+(0 if direction=='t2f' else 50000)+rep
            true=make_alien(seed,outdim); g=semantic_ground(p,true,queries)
            def mk(offset):
                if direction=='t2f': return make_student('fly',seed+10+offset,outdim,7102 if rep%2==0 else 7103)
                return make_student('transformer',seed+10+offset,outdim)
            m=mk(0); cp=absorb(m,true['Y'],g['q'],true['tgt'],seed+99,budget); fin=cp[budget]
            rows.append({'direction':direction,'rep':rep,'condition':'grounded_culture','ground_action':g['policy_acc'],'ground_sequence':g['sequence_acc'],'queries':queries,'final_action':fin[0],'final_sequence':fin[1]})
            # Same packet but no grounding: assume anonymous local chain ids already equal source chain ids and actions are unswapped.
            iq=p(ST).astype(np.float32)
            m=mk(1000); cp=absorb(m,true['Y'],iq,true['tgt'],seed+199,budget); fin=cp[budget]
            ip=iq.argmax(1)
            rows.append({'direction':direction,'rep':rep,'condition':'ungrounded_identity','ground_action':float(np.mean(ip==true['tgt'])),'ground_sequence':float(np.mean([np.all(ip[c*3:c*3+3]==true['tgt'][c*3:c*3+3]) for c in range(8)])),'queries':0,'final_action':fin[0],'final_sequence':fin[1]})
            # Same reward-query budget, no packet.
            m=mk(2000); fin=direct_query_only(m,true['Y'],true['tgt'],g['queries'],seed+299,budget)
            rows.append({'direction':direction,'rep':rep,'condition':'query_only_no_packet','ground_action':'','ground_sequence':'','queries':queries,'final_action':fin[0],'final_sequence':fin[1]})
    return rows

def write_csv(path,rows):
    if not rows:return
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--mode',choices=['grounding','transfer','stress5'],default='transfer'); ap.add_argument('--out',default='gate2e_rerun.csv')
    a=ap.parse_args()
    rows=run_grounding(100,8) if a.mode=='grounding' else run_transfer(12,5 if a.mode=='stress5' else 8)
    write_csv(a.out,rows); print(json.dumps({'mode':a.mode,'rows':len(rows),'out':a.out},indent=2))
if __name__=='__main__': main()
