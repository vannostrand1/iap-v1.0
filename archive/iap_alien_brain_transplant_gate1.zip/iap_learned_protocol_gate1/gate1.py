import argparse, json, math, os, random, time
from dataclasses import dataclass
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

# ---------- World ----------
DIRS = [(dx, dy) for dx in (-1,0,1) for dy in (-1,0,1) if not (dx==0 and dy==0)]
STATES = np.array([(fx,fy,tx,ty) for fx,fy in DIRS for tx,ty in DIRS], dtype=np.float32)
MOVES = np.array([[-1,0],[1,0],[0,1],[0,-1]], dtype=np.float32)

import itertools
OBS_PERMS = [p for p in itertools.permutations(range(4)) if (set(p[:2]) in ({0,1},{2,3}) and set(p[2:]) in ({0,1},{2,3}) and set(p[:2]) != set(p[2:]))]
FLIPS = list(itertools.product([-1,1], repeat=4))
OBS_TRANSFORMS = [(p,f) for p in OBS_PERMS for f in FLIPS]
ACTION_PERMS = list(itertools.permutations(range(4)))

# Query features are intentionally only the alien observation values + alien action one-hot.
QUERY_X = []
for s in STATES:
    for a in range(4):
        QUERY_X.append(np.concatenate([s, np.eye(4,dtype=np.float32)[a]]))
QUERY_X = np.stack(QUERY_X).astype(np.float32)  # [256,8]

# Canonical task family: a moderately rich causal feature basis.
def build_basis():
    feats=[]
    for s in STATES:
        f=s[:2]; t=s[2:]
        ft=float(np.dot(f,t))
        row=[]
        for m in MOVES:
            pf=float(np.dot(m,f)); pt=float(np.dot(m,t))
            cross=float(m[0]*f[1]-m[1]*f[0])
            tcross=float(m[0]*t[1]-m[1]*t[0])
            vals=[
                pf, pt, abs(pf), abs(pt),
                float(pf>0), float(pt>0), float(pf<0), float(pt<0),
                pf*pt, pf*pf, pt*pt, ft,
                cross, tcross, abs(cross), abs(tcross),
                float((pf>0) and (pt<=0)),
                float((pf<=0) and (pt>0)),
                float((pf>0) and (pt>0)),
                m[0], m[1], f[0]*t[1]-f[1]*t[0],
                pf*ft, pt*ft,
            ]
            row.append(vals)
        feats.extend(row)
    B=np.asarray(feats,dtype=np.float32) # [256,24]
    B=(B-B.mean(0,keepdims=True))/(B.std(0,keepdims=True)+1e-5)
    return B
BASIS=build_basis()
D_TASK=BASIS.shape[1]
BASE_THETA=np.array([
    0.8,-1.0,0.05,-0.05, 0.4,-0.65,-0.1,-0.15,
    -0.15,0.03,-0.03,0.0, 0.04,-0.04,0.0,0.0,
    0.35,-0.2,-0.3, 0.0,0.0,0.0, 0.05,-0.05
],dtype=np.float32)

def sample_canonical_q(batch, device, generator=None):
    # Task identity is a 24-D coefficient vector. Variation is large enough that the packet matters.
    theta=torch.randn(batch,D_TASK,device=device,generator=generator)*0.55 + torch.tensor(BASE_THETA,device=device)
    B=torch.tensor(BASIS,device=device)
    q=(theta @ B.T) / math.sqrt(D_TASK/2.0)
    q=q.view(batch,64,4)
    # Small action-specific task biases increase policy diversity.
    ab=torch.randn(batch,1,4,device=device,generator=generator)*0.12
    q=q+ab
    return q

# Precompute alien flat -> canonical flat maps for every representation transform.
def build_maps():
    state_to_idx={tuple(map(int,s)):i for i,s in enumerate(STATES)}
    maps=[]
    obs_ids=[]; act_ids=[]
    for oi,(p,f) in enumerate(OBS_TRANSFORMS):
        inv=[]
        for o in STATES.astype(np.int8):
            c=np.empty(4,dtype=np.int8)
            for k in range(4): c[p[k]]=int(o[k])*int(f[k])
            inv.append(state_to_idx[tuple(map(int,c))])
        inv=np.asarray(inv)
        for ai,ap in enumerate(ACTION_PERMS):
            idx=[]
            for osidx in range(64):
                ci=int(inv[osidx])
                for aobs in range(4): idx.append(ci*4+int(ap[aobs]))
            maps.append(idx); obs_ids.append(oi); act_ids.append(ai)
    return np.asarray(maps,dtype=np.int64), np.asarray(obs_ids), np.asarray(act_ids)
MAPS, MAP_OBS, MAP_ACT = build_maps()

@dataclass
class Split:
    train_ids: np.ndarray
    combo_ids: np.ndarray
    held_obs_ids: np.ndarray
    held_act_ids: np.ndarray
    held_both_ids: np.ndarray
    train_obs: np.ndarray
    test_obs: np.ndarray
    train_act: np.ndarray
    test_act: np.ndarray

def make_split(seed=123):
    rng=np.random.default_rng(seed)
    obs=np.arange(len(OBS_TRANSFORMS)); act=np.arange(len(ACTION_PERMS))
    rng.shuffle(obs); rng.shuffle(act)
    nobs=int(.80*len(obs)); nact=int(.80*len(act))
    tr_obs=np.sort(obs[:nobs]); te_obs=np.sort(obs[nobs:])
    tr_act=np.sort(act[:nact]); te_act=np.sort(act[nact:])
    train_component=np.flatnonzero(np.isin(MAP_OBS,tr_obs)&np.isin(MAP_ACT,tr_act))
    # Hold out 15% exact combinations even though their individual components are seen.
    perm=rng.permutation(train_component)
    ncombo=max(1,int(.15*len(perm)))
    combo=np.sort(perm[:ncombo]); train=np.sort(perm[ncombo:])
    held_obs=np.flatnonzero(np.isin(MAP_OBS,te_obs)&np.isin(MAP_ACT,tr_act))
    held_act=np.flatnonzero(np.isin(MAP_OBS,tr_obs)&np.isin(MAP_ACT,te_act))
    held_both=np.flatnonzero(np.isin(MAP_OBS,te_obs)&np.isin(MAP_ACT,te_act))
    return Split(train,combo,held_obs,held_act,held_both,tr_obs,te_obs,tr_act,te_act)

# ---------- Learned protocol ----------
class Encoder(nn.Module):
    def __init__(self, latent=24):
        super().__init__()
        self.net=nn.Sequential(nn.Linear(256,192),nn.GELU(),nn.Linear(192,96),nn.GELU(),nn.Linear(96,latent),nn.Tanh())
    def forward(self,qflat, quantize=True):
        z=self.net(qflat)
        if quantize:
            zhard=torch.round(z*127.0)/127.0
            z=z+(zhard-z).detach() # straight-through int8 protocol during training
        return z

class Decoder(nn.Module):
    def __init__(self, latent=24, use_packet=True, width=160):
        super().__init__(); self.use_packet=use_packet; self.latent=latent
        zin=latent if use_packet else 0
        self.token=nn.Sequential(nn.Linear(9+zin,width),nn.GELU(),nn.Linear(width,width),nn.GELU())
        self.ctx=nn.Sequential(nn.Linear(width*2+zin,width),nn.GELU(),nn.Linear(width,width),nn.GELU())
        self.query=nn.Sequential(nn.Linear(8+width+zin,width),nn.GELU(),nn.Linear(width,width),nn.GELU(),nn.Linear(width,1))
    def forward(self,z, calib_x, calib_r, query_x):
        # calib_x [B,N,8], calib_r [B,N,1], query_x [256,8]
        Bn,N,_=calib_x.shape
        if self.use_packet:
            zz=z[:,None,:].expand(-1,N,-1)
            tin=torch.cat([calib_x,calib_r,zz],-1)
        else:
            tin=torch.cat([calib_x,calib_r],-1)
        h=self.token(tin)
        pooled=torch.cat([h.mean(1),h.max(1).values],-1)
        if self.use_packet: pooled=torch.cat([pooled,z],-1)
        c=self.ctx(pooled)
        qx=query_x[None,:,:].expand(Bn,-1,-1)
        cc=c[:,None,:].expand(-1,qx.shape[1],-1)
        if self.use_packet:
            zz=z[:,None,:].expand(-1,qx.shape[1],-1)
            qi=torch.cat([qx,cc,zz],-1)
        else:
            qi=torch.cat([qx,cc],-1)
        return self.query(qi).squeeze(-1)

class Protocol(nn.Module):
    def __init__(self,latent=24):
        super().__init__(); self.encoder=Encoder(latent); self.decoder=Decoder(latent,True)
    def forward(self,canonical_q,calib_x,calib_r,query_x):
        z=self.encoder(canonical_q.flatten(1),True)
        return self.decoder(z,calib_x,calib_r,query_x), z

# ---------- Batch helpers ----------
def alienize(canon_q, transform_ids, device):
    B=canon_q.shape[0]
    maps=torch.tensor(MAPS[transform_ids],device=device,dtype=torch.long)
    return canon_q.flatten(1).gather(1,maps)

def make_calib(target_flat,N,noise,device,generator=None):
    B=target_flat.shape[0]
    pos=torch.randint(0,256,(B,N),device=device,generator=generator)
    qx=torch.tensor(QUERY_X,device=device)
    x=qx[pos]
    r=target_flat.gather(1,pos).unsqueeze(-1)
    if noise>0: r=r+torch.randn(r.shape,device=device,generator=generator)*noise
    return x,r,pos

def losses(pred,target):
    mse=F.mse_loss(pred,target)
    # policy loss: each contiguous group of 4 is one observed state
    logits=pred.view(-1,64,4)
    ta=target.view(-1,64,4).argmax(-1)
    ce=F.cross_entropy(logits.reshape(-1,4),ta.reshape(-1))
    return mse + 0.25*ce, mse.detach(), ce.detach()

def policy_metrics(pred,target):
    p=pred.view(-1,64,4); t=target.view(-1,64,4)
    pa=p.argmax(-1); ta=t.argmax(-1)
    opt=(pa==ta).float().mean().item()
    chosen=t.gather(-1,pa.unsqueeze(-1)).squeeze(-1)
    best=t.max(-1).values
    regret=(best-chosen).mean().item()
    # normalized value capture: 1 means optimal; 0 roughly worst-action baseline.
    worst=t.min(-1).values
    denom=(best-worst).mean().item()+1e-8
    capture=1.0-regret/denom
    return opt,regret,capture

def evaluate(protocol,nopacket,split_ids,device,n_tasks=128,N=16,noise=.08,seed=999,negatives=True):
    g=torch.Generator(device=device); g.manual_seed(seed)
    rng=np.random.default_rng(seed)
    protocol.eval(); nopacket.eval()
    rows=[]
    with torch.no_grad():
        for start in range(0,n_tasks,64):
            B=min(64,n_tasks-start)
            cq=sample_canonical_q(B,device,g)
            tids=rng.choice(split_ids,size=B,replace=True)
            target=alienize(cq,tids,device)
            cx,cr,_=make_calib(target,N,noise,device,g)
            z=protocol.encoder(cq.flatten(1),True)
            pred=protocol.decoder(z,cx,cr,torch.tensor(QUERY_X,device=device))
            pred0=nopacket(None,cx,cr,torch.tensor(QUERY_X,device=device))
            conds={'IAP-learned':pred,'Meta-no-packet':pred0}
            if negatives:
                # packet from a different task; cyclic shift guarantees mismatch if B>1
                zs=z.roll(1,0) if B>1 else -z
                condr=protocol.decoder(zs,cx,cr,torch.tensor(QUERY_X,device=device))
                zr=torch.randint(-127,128,z.shape,device=device,generator=g).float()/127.0
                condrand=protocol.decoder(zr,cx,cr,torch.tensor(QUERY_X,device=device))
                conds['Wrong-task packet']=condr; conds['Random packet']=condrand
            for name,pp in conds.items():
                opt,reg,cap=policy_metrics(pp,target)
                rows.append((name,B,opt,reg,cap))
    out=[]
    for name in sorted(set(r[0] for r in rows)):
        rr=[r for r in rows if r[0]==name]; total=sum(r[1] for r in rr)
        out.append({'condition':name,'optimal_action_rate':sum(r[2]*r[1] for r in rr)/total,'mean_regret':sum(r[3]*r[1] for r in rr)/total,'value_capture':sum(r[4]*r[1] for r in rr)/total})
    return out

def train(args):
    torch.manual_seed(args.seed); np.random.seed(args.seed); random.seed(args.seed)
    torch.set_num_threads(max(1,args.threads))
    device=torch.device('cpu')
    split=make_split(args.split_seed)
    model=Protocol(args.latent).to(device)
    nop=Decoder(args.latent,False).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=2e-5)
    opt0=torch.optim.AdamW(nop.parameters(),lr=args.lr,weight_decay=2e-5)
    qx=torch.tensor(QUERY_X,device=device)
    rng=np.random.default_rng(args.seed+111)
    g=torch.Generator(device=device); g.manual_seed(args.seed+222)
    t0=time.time(); hist=[]
    for step in range(1,args.steps+1):
        B=args.batch
        cq=sample_canonical_q(B,device,g)
        tids=rng.choice(split.train_ids,size=B,replace=True)
        target=alienize(cq,tids,device)
        N=int(rng.choice([8,12,16,24,32]))
        cx,cr,_=make_calib(target,N,args.noise,device,g)
        pred,z=model(cq,cx,cr,qx)
        loss,mse,ce=losses(pred,target)
        opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),5.0); opt.step()
        pred0=nop(None,cx,cr,qx)
        loss0,mse0,ce0=losses(pred0,target)
        opt0.zero_grad(); loss0.backward(); nn.utils.clip_grad_norm_(nop.parameters(),5.0); opt0.step()
        if step==1 or step%args.log_every==0:
            with torch.no_grad():
                om=policy_metrics(pred,target)[0]; om0=policy_metrics(pred0,target)[0]
            hist.append({'step':step,'loss':float(loss),'mse':float(mse),'ce':float(ce),'train_opt':om,'nop_loss':float(loss0),'nop_train_opt':om0,'N':N,'elapsed_s':time.time()-t0})
            print(f"step {step:5d} N={N:2d} loss={loss.item():.4f} opt={om:.3f} | noPkt={om0:.3f} elapsed={time.time()-t0:.1f}s",flush=True)
    return model,nop,split,hist

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--steps',type=int,default=5000); ap.add_argument('--batch',type=int,default=96)
    ap.add_argument('--latent',type=int,default=24); ap.add_argument('--lr',type=float,default=1.5e-3)
    ap.add_argument('--noise',type=float,default=.08); ap.add_argument('--seed',type=int,default=7); ap.add_argument('--split-seed',type=int,default=123)
    ap.add_argument('--threads',type=int,default=4); ap.add_argument('--log-every',type=int,default=250)
    ap.add_argument('--eval-tasks',type=int,default=192); ap.add_argument('--out',default='results_gate1')
    args=ap.parse_args(); os.makedirs(args.out,exist_ok=True)
    model,nop,split,hist=train(args)
    torch.save({'protocol':model.state_dict(),'nopacket':nop.state_dict(),'args':vars(args)},os.path.join(args.out,'model.pt'))
    pd.DataFrame(hist).to_csv(os.path.join(args.out,'train_history.csv'),index=False)
    split_sets={
        'heldout_combo':split.combo_ids,
        'heldout_observation_component':split.held_obs_ids,
        'heldout_action_component':split.held_act_ids,
        'heldout_both_components':split.held_both_ids,
    }
    rows=[]
    for N in [8,16,32]:
        for si,(sname,ids) in enumerate(split_sets.items()):
            ev=evaluate(model,nop,ids,torch.device('cpu'),args.eval_tasks,N,args.noise,seed=9000+N*31+si)
            for r in ev: rows.append({'split':sname,'N':N,**r})
            print('EVAL',sname,'N',N,ev,flush=True)
    df=pd.DataFrame(rows); df.to_csv(os.path.join(args.out,'evaluation.csv'),index=False)

    # Serialize one genuinely learned test packet. No per-packet schema/scale: fixed int8 latent code.
    g=torch.Generator(); g.manual_seed(424242)
    with torch.no_grad():
        cq=sample_canonical_q(1,torch.device('cpu'),g)
        z=model.encoder(cq.flatten(1),False).squeeze(0)
        b=torch.clamp(torch.round(z*127),-127,127).to(torch.int8).numpy().tobytes()
    open(os.path.join(args.out,'sample_packet.iap1'),'wb').write(b)

    summary={
        'gate':'IAP Gate 1 learned protocol',
        'packet_payload_bytes':args.latent,
        'packet_bits':args.latent*8,
        'quantization':'fixed signed int8, globally shared [-1,1] code range',
        'shared_codec_note':'Encoder/decoder weights are shared learned protocol infrastructure and are not counted in the per-task packet payload.',
        'train_steps':args.steps,'batch':args.batch,'calibration_noise_sd':args.noise,
        'transform_counts':{
            'all':int(len(MAPS)),'train_exact_combos':int(len(split.train_ids)),'heldout_exact_combos_seen_components':int(len(split.combo_ids)),
            'heldout_obs_component':int(len(split.held_obs_ids)),'heldout_action_component':int(len(split.held_act_ids)),'heldout_both_components':int(len(split.held_both_ids)),
            'train_obs_components':int(len(split.train_obs)),'heldout_obs_components':int(len(split.test_obs)),'train_action_components':int(len(split.train_act)),'heldout_action_components':int(len(split.test_act))},
        'evaluation':rows,
    }
    with open(os.path.join(args.out,'summary.json'),'w') as f: json.dump(summary,f,indent=2)
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
