import os, json, types, importlib.util
import numpy as np, pandas as pd, torch
HERE=os.path.dirname(os.path.abspath(__file__))
spec=importlib.util.spec_from_file_location('lc',os.path.join(HERE,'learned_codec.py')); lc=importlib.util.module_from_spec(spec);spec.loader.exec_module(lc)

def args_for(latent,seed,steps):
    return types.SimpleNamespace(seed=seed,threads=4,latent=latent,lr=0.002,steps=steps,batch=256,log_every=steps)

def main():
    split=lc.make_split(123); rows=[]; models={}
    # fixed prior estimate for evaluation
    g=torch.Generator();g.manual_seed(555)
    with torch.no_grad(): mean_q=lc.sample_q(4096,torch.device('cpu'),g).flatten(1).mean(0).numpy()
    for latent in [4,8,12,16,24,32]:
        print('\n=== LATENT',latent,'BYTES ===',flush=True)
        model,h=lc.train_codec(args_for(latent,100+latent,1800),torch.device('cpu'));models[latent]=model
        g2=torch.Generator();g2.manual_seed(700+latent)
        with torch.no_grad():
            q=lc.sample_q(512,torch.device('cpu'),g2).flatten(1);z=model.encode(q,True);rec=model.decode(z)
            canon=(rec.view(-1,64,4).argmax(-1)==q.view(-1,64,4).argmax(-1)).float().mean().item();mse=torch.nn.functional.mse_loss(rec,q).item()
        for N in [4,8,16,32]:
            df=lc.evaluate(model,split.held_both,N,96,.08,12000+latent*100+N,torch.device('cpu'),mean_q)
            ag=df.groupby('condition')[['optimal_action_rate','value_capture','transform_exact']].mean()
            for cond in ['Learned-IAP','Oracle-full-Q','Wrong-task-packet','Random-packet','No-packet-mean-Q']:
                x=ag.loc[cond]; rows.append({'packet_bytes':latent,'N':N,'condition':cond,'canonical_policy_acc':canon,'canonical_mse':mse,'optimal_action_rate':x.optimal_action_rate,'value_capture':x.value_capture,'transform_exact':x.transform_exact})
            print('N',N,'canon',round(canon,4),'IAP',round(ag.loc['Learned-IAP','optimal_action_rate'],4),'oracle',round(ag.loc['Oracle-full-Q','optimal_action_rate'],4),flush=True)
    out=pd.DataFrame(rows);out.to_csv(os.path.join(HERE,'bandwidth_sweep.csv'),index=False)
    summ=out[out.condition=='Learned-IAP'].to_dict(orient='records');json.dump({'sweep':summ},open(os.path.join(HERE,'bandwidth_sweep.json'),'w'),indent=2)
    print('\nFINAL\n',out[out.condition=='Learned-IAP'].pivot(index='packet_bytes',columns='N',values='optimal_action_rate').round(4).to_string())
if __name__=='__main__':main()
