# IAP Alien Brain Transplant — Gate 1

Gate 1 asks whether the hand-authored Gate 0 packet can be replaced by a **learned, quantized communication protocol** while retaining transfer across incompatible representations.

## Gate 1A — learned packet protocol

A neural encoder receives a teacher's 256-value canonical Q function and must compress it through a fixed signed-int8 bottleneck. A neural decoder reconstructs the teacher knowledge from that packet. Neither network is given labels such as `food`, `predator`, `x`, `y`, or action names.

The default packet is **16 bytes / 128 bits**. Training uses straight-through quantization, so the codec is optimized with the same discrete bottleneck used at test time.

The alien student sees independently permuted/signed observation coordinates and permuted action IDs. A few noisy reward samples ground the decoded knowledge. Gate 1A deliberately retains an explicit representation-search grounder so packet learning and grounding learning can be tested separately.

### Strongest result

With the 16-byte codec trained for 3,000 steps:

- Canonical unseen-task policy reconstruction: **96.09%**.
- Held-out exact transform combinations, 16 calibration samples: **95.83%** optimal actions.
- Entire observation transform components held out, 16 samples: **95.88%**.
- Entire action permutation components held out, 16 samples: **95.59%**.
- Both observation and action components held out, 16 samples: **95.22%**.
- Full-Q oracle is approximately 100% at 16 samples.
- Wrong-task and random packets perform far below the learned packet.

At 8 calibration interactions the learned packet is already about **90–93%** across the four out-of-distribution transform splits.

## Bandwidth sweep

A matched 1,800-step sweep on the hardest split (both observation and action components held out) shows a smooth rate–transfer curve:

| Packet | N=4 | N=8 | N=16 | N=32 |
|---:|---:|---:|---:|---:|
| 4 B | 38.4% | 55.7% | 70.9% | 75.9% |
| 8 B | 41.8% | 67.7% | 83.1% | 86.8% |
| 12 B | 50.4% | 81.0% | 90.1% | 90.4% |
| 16 B | 61.5% | 90.6% | 93.8% | 93.8% |

This demonstrates that transfer quality scales with communication bandwidth and that useful task knowledge survives in packets as small as 4–8 bytes.

## Gate 1B — learned grounding attempts

Two additional diagnostics were run rather than hidden:

1. A differentiable set-network grounder trained only through downstream Q/policy reconstruction stayed near chance.
2. A mapping-supervised set-network diagnostic also failed to reliably amortize the combinatorial alignment.

This is useful evidence: the packet contains sufficient information (the search grounder recovers it), but a plain set MLP is a poor algorithm for representation alignment. The next grounder should be algorithmic/content-addressed (e.g. iterative matching, attention over hypotheses, Sinkhorn/EM, or a learned search policy), rather than simply larger.

## Files

- `learned_codec.py` — Gate 1A learned int8 codec + OOD grounding evaluation.
- `results/` — full 3,000-step 16-byte run.
- `bandwidth_sweep.csv` — 4/8/12/16-byte rate–transfer curve.
- `gate1.py` — first fully generic amortized-decoder prototype.
- `learned_grounder.py` — reward-only differentiable grounding attempt.
- `supervised_grounder.py` — mapping-supervision diagnostic.
- `grounder_smoke/`, `supervised_smoke/`, `supervised_match_smoke/` — failed-grounder diagnostics.

## Interpretation boundary

Gate 1A supports a narrow but important claim: **a learned 128-bit protocol can preserve behaviorally useful task knowledge and transfer it across previously unseen representational remappings, provided the receiver has a shared learned codec and a grounding mechanism.**

It does not yet establish an unconstrained universal machine language. The shared codec is protocol infrastructure, and Gate 1A's grounding search knows the allowed remapping family. Removing that structural knowledge is a later gate.
