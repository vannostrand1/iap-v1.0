import argparse, json, os, random, time, importlib.util
import numpy as np, pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
HERE=os.path.dirname(os.path.abspath(__file__))
spec=importlib.util.spec_from_file_location('lc',os.path.join(HERE,'learned_codec.py')); lc=importlib.util.module_from_spec(spec); spec.loader.exec_module(lc)

class Grounder(nn.Module):
    def __init__(self,latent=16,width=192,match_sigma=.12):
        super().__init__(); self.match_sigma=match_sigma
        # Content-addressed comparison: each calibration reward is compared to every decoded canonical Q entry.
        # This is generic value matching; no transform IDs or coordinate semantics are supplied as input.
        self.token=nn.Sequential(nn.Linear(4+4+1+256,width),nn.GELU(),nn.Linear(width,width),nn.GELU())
        self.fuse=nn.Sequential(nn.Linear(width*2+latent,width),nn.GELU(),nn.Linear(width,width),nn.GELU())
        self.hp=nn.Linear(width,16); self.hs=nn.Linear(width,4); self.ha=nn.Linear(width,16)
    def forward(self,z,dq,obs,a,r):
        ah=F.one_hot(a,4).float(); flat=dq.flatten(1)
        diff=(flat[:,None,:]-r[:,:,None])/self.match_sigma
        sim=torch.exp(-0.5*diff*diff)
        h=self.token(torch.cat([obs,ah,r.unsqueeze(-1),sim],-1))
        c=torch.cat([h.mean(1),h.max(1).values,z],-1); c=self.fuse(c)
        return self.hp(c).view(-1,4,4),self.hs(c),self.ha(c).view(-1,4,4)

def labels(tids):
    P=[]; S=[]; A=[]
    for tid in tids:
        oi=int(lc.MAP_OBS[tid]); ai=int(lc.MAP_ACT[tid]); p,f=lc.OBS_TRANSFORMS[oi]; ap=lc.ACTION_PERMS[ai]
        P.append(p); S.append([(1 if x>0 else 0) for x in f]); A.append(ap)
    return torch.tensor(P),torch.tensor(S,dtype=torch.float32),torch.tensor(A)

def calib(target,N,noise,g):
    B=target.shape[0]; pos=torch.randint(0,256,(B,N),generator=g); si=pos//4; a=pos%4; obs=torch.tensor(lc.STATES)[si].float(); r=target.flatten(1).gather(1,pos)
    if noise:r=r+torch.randn(r.shape,generator=g)*noise
    return obs,a,r

def alienize(q,tids): return q.flatten(1).gather(1,torch.tensor(lc.MAPS[tids],dtype=torch.long)).view(-1,64,4)

def map_metrics(pl,sl,al,tids):
    yp,ys,ya=labels(tids); pp=pl.argmax(-1); ss=(sl>0).float(); aa=al.argmax(-1)
    return (pp==yp).float().mean().item(),(ss==ys).float().mean().item(),(aa==ya).float().mean().item(),((pp==yp).all(-1)&(ss==ys).all(-1)&(aa==ya).all(-1)).float().mean().item()

def maps_to_pred(pl,sl,al,dq,state_temp=12.0):
    # Hard maps at inference; no exhaustive search.
    B=dq.shape[0]; p=pl.argmax(-1); s=torch.where(sl>0,torch.ones_like(sl),-torch.ones_like(sl)); a=al.argmax(-1)
    O=torch.tensor(lc.STATES); C=torch.zeros(B,64,4)
    for k in range(4):
        # observed dim k maps to canonical dim p[k]
        C.scatter_add_(2,p[:,k,None,None].expand(-1,64,1), (O[None,:,k,None]*s[:,k,None,None]))
    dist=((C[:,:,None,:]-O[None,None,:,:])**2).sum(-1); sw=F.softmax(-state_temp*dist,-1)
    # hard observed-action -> canonical-action mapping
    A=F.one_hot(a,4).float(); qa=torch.einsum('bsc,bac->bsa',dq,A); return torch.einsum('bos,bsa->boa',sw,qa)

def policy(pred,target):
    pa=pred.argmax(-1); ta=target.argmax(-1); opt=(pa==ta).float().mean().item(); ch=target.gather(-1,pa.unsqueeze(-1)).squeeze(-1); best=target.max(-1).values; worst=target.min(-1).values; reg=(best-ch).mean().item(); return opt,1-reg/((best-worst).mean().item()+1e-8)

def load_codec(path,latent):
    ck=torch.load(path,map_location='cpu'); m=lc.Codec(latent); m.load_state_dict(ck['state_dict']); m.eval();
    for p in m.parameters():p.requires_grad=False
    return m

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--codec',default=os.path.join(HERE,'results','codec.pt'));ap.add_argument('--latent',type=int,default=16);ap.add_argument('--steps',type=int,default=4000);ap.add_argument('--batch',type=int,default=128);ap.add_argument('--width',type=int,default=192);ap.add_argument('--lr',type=float,default=1.5e-3);ap.add_argument('--noise',type=float,default=.08);ap.add_argument('--seed',type=int,default=44);ap.add_argument('--split-seed',type=int,default=123);ap.add_argument('--threads',type=int,default=4);ap.add_argument('--log-every',type=int,default=250);ap.add_argument('--eval-tasks',type=int,default=160);ap.add_argument('--out',default=os.path.join(HERE,'supervised_grounder_results'))
    args=ap.parse_args(); os.makedirs(args.out,exist_ok=True); torch.set_num_threads(args.threads);torch.manual_seed(args.seed);np.random.seed(args.seed);random.seed(args.seed)
    codec=load_codec(args.codec,args.latent); split=lc.make_split(args.split_seed); net=Grounder(args.latent,args.width); opt=torch.optim.AdamW(net.parameters(),lr=args.lr,weight_decay=2e-5);g=torch.Generator();g.manual_seed(args.seed+1);rng=np.random.default_rng(args.seed+2);hist=[];t0=time.time()
    for step in range(1,args.steps+1):
        q=lc.sample_q(args.batch,torch.device('cpu'),g); tids=rng.choice(split.train,size=args.batch,replace=True); target=alienize(q,tids)
        with torch.no_grad():z=codec.encode(q.flatten(1),True);dq=codec.decode(z).view(-1,64,4)
        N=int(rng.choice([8,12,16,24,32]));o,a,r=calib(target,N,args.noise,g);pl,sl,al=net(z,dq,o,a,r);yp,ys,ya=labels(tids)
        lp=F.cross_entropy(pl.reshape(-1,4),yp.reshape(-1));ls=F.binary_cross_entropy_with_logits(sl,ys);la=F.cross_entropy(al.reshape(-1,4),ya.reshape(-1));loss=lp+ls+la
        opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(net.parameters(),5);opt.step()
        if step==1 or step%args.log_every==0:
            mm=map_metrics(pl,sl,al,tids); pred=maps_to_pred(pl,sl,al,dq); pm=policy(pred,target)
            hist.append({'step':step,'loss':float(loss.detach()),'obs_perm_acc':mm[0],'sign_acc':mm[1],'action_map_acc':mm[2],'exact_map':mm[3],'policy_acc':pm[0],'value_capture':pm[1],'N':N,'elapsed_s':time.time()-t0})
            print(f'sup {step:5d} N={N:2d} loss={loss.item():.3f} map={mm[0]:.2f}/{mm[1]:.2f}/{mm[2]:.2f} exact={mm[3]:.2f} pol={pm[0]:.3f} t={time.time()-t0:.1f}s',flush=True)
    pd.DataFrame(hist).to_csv(os.path.join(args.out,'train_history.csv'),index=False);torch.save({'state_dict':net.state_dict(),'args':vars(args)},os.path.join(args.out,'grounder.pt'))
    splits={'heldout_combo':split.combo,'heldout_observation_component':split.held_obs,'heldout_action_component':split.held_act,'heldout_both_components':split.held_both};rows=[]
    net.eval()
    with torch.no_grad():
      for N in [8,16,32]:
       for j,(sn,ids) in enumerate(splits.items()):
        rg=np.random.default_rng(9000+N*17+j);gg=torch.Generator();gg.manual_seed(9100+N*17+j)
        for st in range(0,args.eval_tasks,64):
            B=min(64,args.eval_tasks-st);q=lc.sample_q(B,torch.device('cpu'),gg);tids=rg.choice(ids,size=B,replace=True);target=alienize(q,tids);z=codec.encode(q.flatten(1),True);dq=codec.decode(z).view(B,64,4);o,a,r=calib(target,N,args.noise,gg);pl,sl,al=net(z,dq,o,a,r);pred=maps_to_pred(pl,sl,al,dq)
            for b in range(B):
                mm=map_metrics(pl[b:b+1],sl[b:b+1],al[b:b+1],[tids[b]]);pm=policy(pred[b:b+1],target[b:b+1]);rows.append({'split':sn,'N':N,'policy_acc':pm[0],'value_capture':pm[1],'obs_perm_acc':mm[0],'sign_acc':mm[1],'action_map_acc':mm[2],'exact_map':mm[3]})
        dd=pd.DataFrame([x for x in rows if x['split']==sn and x['N']==N]);print('\nEVAL',sn,N,dd[['policy_acc','value_capture','obs_perm_acc','sign_acc','action_map_acc','exact_map']].mean().round(4).to_dict(),flush=True)
    raw=pd.DataFrame(rows);raw.to_csv(os.path.join(args.out,'evaluation_raw.csv'),index=False);agg=raw.groupby(['split','N']).mean(numeric_only=True).reset_index();agg.to_csv(os.path.join(args.out,'evaluation_summary.csv'),index=False)
    summary={'gate':'Gate 1B diagnostic: supervised amortized grounder','packet_bytes':args.latent,'evaluation':agg.to_dict(orient='records'),'interpretation':'This diagnostic uses true mapping labels during training only. It tests whether the packet+calibration contain enough information for a neural grounder to infer unseen representation mappings without exhaustive search at inference. It is not yet a fully self-supervised protocol result.'};json.dump(summary,open(os.path.join(args.out,'summary.json'),'w'),indent=2)
if __name__=='__main__':main()
