import argparse, json, os, time, random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import importlib.util

HERE=os.path.dirname(os.path.abspath(__file__))
spec=importlib.util.spec_from_file_location('lc',os.path.join(HERE,'learned_codec.py')); lc=importlib.util.module_from_spec(spec); spec.loader.exec_module(lc)

class SetGrounder(nn.Module):
    def __init__(self,latent=16,width=192,sink_temp=.22,state_temp=8.0):
        super().__init__(); self.latent=latent; self.sink_temp=sink_temp; self.state_temp=state_temp
        self.token=nn.Sequential(nn.Linear(4+4+1+latent,width),nn.GELU(),nn.Linear(width,width),nn.GELU())
        self.fuse=nn.Sequential(nn.Linear(width*2+latent,width),nn.GELU(),nn.Linear(width,width),nn.GELU())
        self.head=nn.Linear(width,16+4+16)
        self.register_buffer('states',torch.tensor(lc.STATES,dtype=torch.float32))
    def sinkhorn(self,logits,iters=6):
        x=torch.exp(torch.clamp(logits/self.sink_temp,-12,12))
        for _ in range(iters):
            x=x/(x.sum(-1,keepdim=True)+1e-8); x=x/(x.sum(-2,keepdim=True)+1e-8)
        return x
    def infer_maps(self,z,calib_obs,calib_a,calib_r):
        B,N,_=calib_obs.shape
        ah=F.one_hot(calib_a,4).float()
        zz=z[:,None,:].expand(-1,N,-1)
        h=self.token(torch.cat([calib_obs,ah,calib_r.unsqueeze(-1),zz],-1))
        pool=torch.cat([h.mean(1),h.max(1).values,z],-1)
        y=self.head(self.fuse(pool))
        P=self.sinkhorn(y[:,:16].view(B,4,4))
        sign=torch.tanh(y[:,16:20]*1.7)
        A=self.sinkhorn(y[:,20:].view(B,4,4))
        return P,sign,A
    def predict(self,z,canonical_q,calib_obs,calib_a,calib_r):
        # canonical_q [B,64,4]. Produce Q over standard alien coordinate enumeration [B,64,4].
        P,sgn,A=self.infer_maps(z,calib_obs,calib_a,calib_r)
        O=self.states # [64,4] alien coords
        # inverse signed coordinate mapping: c_j = sum_k o_k * sign_k * P[k,j]
        c=torch.einsum('ok,bk,bkj->boj',O,sgn,P)
        dist=((c[:,:,None,:]-self.states[None,None,:,:])**2).sum(-1)
        SW=F.softmax(-self.state_temp*dist,-1) # observed state -> canonical state
        # action map observed -> canonical
        qa=torch.einsum('bsc,bac->bsa',canonical_q,A)
        pred=torch.einsum('bos,bsa->boa',SW,qa)
        return pred,P,sgn,A

def calib_from_target(target,N,noise,g):
    B=target.shape[0]; pos=torch.randint(0,256,(B,N),generator=g)
    si=pos//4; a=pos%4; obs=torch.tensor(lc.STATES)[si]
    r=target.flatten(1).gather(1,pos)
    if noise: r=r+torch.randn(r.shape,generator=g)*noise
    return obs.float(),a.long(),r,pos

def alienize(q,tids):
    maps=torch.tensor(lc.MAPS[tids],dtype=torch.long); return q.flatten(1).gather(1,maps).view(-1,64,4)

def metrics(pred,target):
    pa=pred.argmax(-1); ta=target.argmax(-1); opt=(pa==ta).float().mean().item()
    ch=target.gather(-1,pa.unsqueeze(-1)).squeeze(-1); best=target.max(-1).values; worst=target.min(-1).values
    reg=(best-ch).mean().item(); cap=1-reg/((best-worst).mean().item()+1e-8)
    return opt,reg,cap

def losses(pred,target,P,sgn,A):
    mse=F.mse_loss(pred,target); ce=F.cross_entropy(pred.reshape(-1,4),target.argmax(-1).reshape(-1))
    # Encourage discrete maps without supervising which map is correct.
    entP=-(P.clamp_min(1e-8)*P.clamp_min(1e-8).log()).sum(-1).mean()
    entA=-(A.clamp_min(1e-8)*A.clamp_min(1e-8).log()).sum(-1).mean()
    signreg=((sgn.abs()-1)**2).mean()
    loss=mse+.35*ce+.01*(entP+entA)+.01*signreg
    return loss,mse.detach(),ce.detach(),entP.detach(),entA.detach(),signreg.detach()

def true_factor_accuracy(P,sgn,A,tids):
    # Diagnostic only, never used as training signal.
    pc=P.argmax(-1).cpu().numpy(); sc=np.sign(sgn.cpu().numpy()); ac=A.argmax(-1).cpu().numpy()
    po=[]; ps=[]; paa=[]; exact=[]
    for b,tid in enumerate(tids):
        oi=int(lc.MAP_OBS[tid]); ai=int(lc.MAP_ACT[tid]); p,f=lc.OBS_TRANSFORMS[oi]; ap=lc.ACTION_PERMS[ai]
        po.append(np.mean(pc[b]==np.asarray(p))); ps.append(np.mean(sc[b]==np.asarray(f))); paa.append(np.mean(ac[b]==np.asarray(ap)))
        exact.append(float(np.all(pc[b]==p) and np.all(sc[b]==f) and np.all(ac[b]==ap)))
    return float(np.mean(po)),float(np.mean(ps)),float(np.mean(paa)),float(np.mean(exact))

def load_codec(path,latent):
    ck=torch.load(path,map_location='cpu'); model=lc.Codec(latent); model.load_state_dict(ck['state_dict']); model.eval()
    for p in model.parameters(): p.requires_grad=False
    return model

def train(args,codec,split):
    torch.manual_seed(args.seed); np.random.seed(args.seed); random.seed(args.seed); torch.set_num_threads(args.threads)
    g=torch.Generator(); g.manual_seed(args.seed+1); rng=np.random.default_rng(args.seed+2)
    net=SetGrounder(args.latent,args.width,args.sink_temp,args.state_temp)
    opt=torch.optim.AdamW(net.parameters(),lr=args.lr,weight_decay=2e-5); hist=[]; t0=time.time()
    for step in range(1,args.steps+1):
        q=lc.sample_q(args.batch,torch.device('cpu'),g)
        with torch.no_grad(): z=codec.encode(q.flatten(1),True); dq=codec.decode(z).view(-1,64,4)
        tids=rng.choice(split.train,size=args.batch,replace=True); target=alienize(q,tids)
        N=int(rng.choice([8,12,16,24,32])); co,ca,cr,_=calib_from_target(target,N,args.noise,g)
        pred,P,s,A=net.predict(z,dq,co,ca,cr); loss,mse,ce,eP,eA,sr=losses(pred,target,P,s,A)
        opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(),5); opt.step()
        if step==1 or step%args.log_every==0:
            with torch.no_grad():
                m=metrics(pred,target); fa=true_factor_accuracy(P,s,A,tids)
            hist.append({'step':step,'loss':float(loss.detach()),'mse':float(mse),'ce':float(ce),'policy_acc':m[0],'value_capture':m[2],
                         'perm_entropy':float(eP),'action_entropy':float(eA),'signreg':float(sr),'obs_perm_acc':fa[0],'sign_acc':fa[1],'action_map_acc':fa[2],'exact_map':fa[3],'N':N,'elapsed_s':time.time()-t0})
            print(f'gnd {step:5d} N={N:2d} loss={loss.item():.3f} pol={m[0]:.3f} cap={m[2]:.3f} map(P/S/A)={fa[0]:.2f}/{fa[1]:.2f}/{fa[2]:.2f} exact={fa[3]:.2f} t={time.time()-t0:.1f}s',flush=True)
    return net,hist

def evaluate(net,codec,ids,N,n_tasks,noise,seed):
    rng=np.random.default_rng(seed); g=torch.Generator(); g.manual_seed(seed+77); rows=[]
    net.eval()
    with torch.no_grad():
        for st in range(0,n_tasks,64):
            B=min(64,n_tasks-st); q=lc.sample_q(B,torch.device('cpu'),g); tids=rng.choice(ids,size=B,replace=True); target=alienize(q,tids)
            z=codec.encode(q.flatten(1),True); dq=codec.decode(z).view(B,64,4); co,ca,cr,_=calib_from_target(target,N,noise,g)
            conds={}
            pred,P,s,A=net.predict(z,dq,co,ca,cr); conds['Learned-grounder']=(pred,P,s,A,z,dq)
            zw=z.roll(1,0) if B>1 else -z; dqw=codec.decode(zw).view(B,64,4); pw,Pw,sw,Aw=net.predict(zw,dqw,co,ca,cr); conds['Wrong-task-packet']=(pw,Pw,sw,Aw,zw,dqw)
            zr=torch.randint(-127,128,z.shape,generator=g).float()/127.; dqr=codec.decode(zr).view(B,64,4); pr,Pr,sr,Ar=net.predict(zr,dqr,co,ca,cr); conds['Random-packet']=(pr,Pr,sr,Ar,zr,dqr)
            for name,(pp,PP,ss,AA,_,__) in conds.items():
                for b in range(B):
                    m=metrics(pp[b:b+1],target[b:b+1]); fa=true_factor_accuracy(PP[b:b+1],ss[b:b+1],AA[b:b+1],[tids[b]])
                    rows.append({'condition':name,'optimal_action_rate':m[0],'mean_regret':m[1],'value_capture':m[2],'obs_perm_acc':fa[0],'sign_acc':fa[1],'action_map_acc':fa[2],'exact_map':fa[3]})
    return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--codec',default=os.path.join(HERE,'results','codec.pt')); ap.add_argument('--latent',type=int,default=16)
    ap.add_argument('--steps',type=int,default=6000); ap.add_argument('--batch',type=int,default=96); ap.add_argument('--width',type=int,default=192); ap.add_argument('--lr',type=float,default=1.5e-3)
    ap.add_argument('--sink-temp',type=float,default=.22); ap.add_argument('--state-temp',type=float,default=8.0); ap.add_argument('--noise',type=float,default=.08)
    ap.add_argument('--seed',type=int,default=33); ap.add_argument('--split-seed',type=int,default=123); ap.add_argument('--threads',type=int,default=4); ap.add_argument('--log-every',type=int,default=250)
    ap.add_argument('--eval-tasks',type=int,default=160); ap.add_argument('--out',default=os.path.join(HERE,'grounder_results'))
    args=ap.parse_args(); os.makedirs(args.out,exist_ok=True); split=lc.make_split(args.split_seed); codec=load_codec(args.codec,args.latent)
    net,h=train(args,codec,split); pd.DataFrame(h).to_csv(os.path.join(args.out,'train_history.csv'),index=False); torch.save({'state_dict':net.state_dict(),'args':vars(args)},os.path.join(args.out,'grounder.pt'))
    splits={'heldout_combo':split.combo,'heldout_observation_component':split.held_obs,'heldout_action_component':split.held_act,'heldout_both_components':split.held_both}
    rr=[]
    for N in [8,16,32]:
        for j,(sn,ids) in enumerate(splits.items()):
            df=evaluate(net,codec,ids,N,args.eval_tasks,args.noise,10000+N*29+j); df.insert(0,'N',N); df.insert(0,'split',sn); rr.append(df)
            print('\nEVAL',sn,'N',N,'\n',df.groupby('condition')[['optimal_action_rate','value_capture','obs_perm_acc','sign_acc','action_map_acc','exact_map']].mean().round(4),flush=True)
    raw=pd.concat(rr,ignore_index=True); raw.to_csv(os.path.join(args.out,'evaluation_raw.csv'),index=False)
    agg=raw.groupby(['split','N','condition']).agg(optimal_action_rate=('optimal_action_rate','mean'),optimal_action_sd=('optimal_action_rate','std'),mean_regret=('mean_regret','mean'),value_capture=('value_capture','mean'),obs_perm_acc=('obs_perm_acc','mean'),sign_acc=('sign_acc','mean'),action_map_acc=('action_map_acc','mean'),exact_map=('exact_map','mean')).reset_index()
    agg.to_csv(os.path.join(args.out,'evaluation_summary.csv'),index=False)
    summary={'gate':'IAP Gate 1B: learned differentiable grounding','packet_bytes':args.latent,'training':{'steps':args.steps,'batch':args.batch},'evaluation':agg.to_dict(orient='records'),
             'grounder_prior':'Set network infers a signed 4x4 coordinate assignment and a 4x4 action assignment. It receives no transform labels and uses no exhaustive transform search; maps are learned only through downstream Q/policy reconstruction loss.',
             'limitation':'The aligner is structurally biased to signed coordinate permutations and action permutations. It is not yet an unconstrained universal protocol interpreter.'}
    json.dump(summary,open(os.path.join(args.out,'summary.json'),'w'),indent=2); print('\nSUMMARY\n'+json.dumps(summary,indent=2),flush=True)

if __name__=='__main__': main()
