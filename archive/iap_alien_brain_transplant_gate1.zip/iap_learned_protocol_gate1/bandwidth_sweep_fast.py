import os, json, types, importlib.util
import numpy as np, pandas as pd, torch
HERE=os.path.dirname(os.path.abspath(__file__))
spec=importlib.util.spec_from_file_location('lc',os.path.join(HERE,'learned_codec.py')); lc=importlib.util.module_from_spec(spec);spec.loader.exec_module(lc)

def af(latent): return types.SimpleNamespace(seed=100+latent,threads=4,latent=latent,lr=.002,steps=1800,batch=256,log_every=1800)

def eval_fast(model, ids, N, B, seed):
    rng=np.random.default_rng(seed);g=torch.Generator();g.manual_seed(seed+1)
    with torch.no_grad():
        q=lc.sample_q(B,torch.device('cpu'),g).flatten(1);z=model.encode(q,True);dec=model.decode(z).numpy();qn=q.numpy()
    tids=rng.choice(ids,size=B,replace=True); pos=rng.integers(0,256,size=(B,N))
    true_maps=lc.MAPS[tids]
    true_idx=np.take_along_axis(true_maps,pos,axis=1); r=np.take_along_axis(qn,true_idx,axis=1)+rng.normal(0,.08,size=(B,N))
    # Candidate decoded rewards [B,T,N]
    mm=lc.MAPS[:,pos].transpose(1,0,2)  # [B,T,N]
    pred=np.take_along_axis(dec[:,None,:],mm,axis=2)
    mse=((pred-r[:,None,:])**2).mean(2); est=mse.argmin(1)
    # policy acc
    pm=lc.MAPS[est]; tm=true_maps
    pa=np.take_along_axis(dec,pm,axis=1).reshape(B,64,4).argmax(2)
    tq=np.take_along_axis(qn,tm,axis=1).reshape(B,64,4); ta=tq.argmax(2)
    acc=(pa==ta).mean(1)
    exact=(est==tids).astype(float)
    return float(acc.mean()),float(acc.std(ddof=1)),float(exact.mean())

def main():
    split=lc.make_split(123);rows=[]
    for L in [4,8,12,16]:
        print('TRAIN',L,flush=True);m,h=lc.train_codec(af(L),torch.device('cpu'))
        g=torch.Generator();g.manual_seed(700+L)
        with torch.no_grad():
            q=lc.sample_q(512,torch.device('cpu'),g).flatten(1);z=m.encode(q,True);rec=m.decode(z);canon=(rec.view(-1,64,4).argmax(-1)==q.view(-1,64,4).argmax(-1)).float().mean().item();mse=torch.nn.functional.mse_loss(rec,q).item()
        for N in [4,8,16,32]:
            a,sd,e=eval_fast(m,split.held_both,N,192,20000+L*100+N);rows.append({'packet_bytes':L,'N':N,'canonical_policy_acc':canon,'canonical_mse':mse,'alien_policy_acc':a,'alien_policy_sd':sd,'transform_exact':e});print(' ',N,round(a,4),round(e,4),flush=True)
    df=pd.DataFrame(rows);df.to_csv(os.path.join(HERE,'bandwidth_sweep.csv'),index=False);json.dump({'results':rows},open(os.path.join(HERE,'bandwidth_sweep.json'),'w'),indent=2);print(df.pivot(index='packet_bytes',columns='N',values='alien_policy_acc').round(4).to_string())
if __name__=='__main__':main()
