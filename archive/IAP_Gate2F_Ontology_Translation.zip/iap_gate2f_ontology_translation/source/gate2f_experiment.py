from __future__ import annotations
import argparse, csv, itertools, math, struct, sys
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

torch.set_num_threads(1)
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from internal_model import InternalFly

# ---------------------------------------------------------------------------
# Teacher culture capsule: 97-byte quantized policy + 144-byte source atlas.
# ---------------------------------------------------------------------------
ST=np.frombuffer((ROOT/'packets/source_relational_atlas_144b.bin').read_bytes(),dtype=np.int8).reshape(24,6).astype(np.float32)

def load_packet(path:Path):
    raw=path.read_bytes(); assert raw[:7]==b'IAPCV2\0' and len(raw)==97
    scales=struct.unpack('<4f',raw[7:23]); off=23
    w1=np.frombuffer(raw[off:off+48],dtype=np.int8).astype(np.float32).reshape(8,6)*scales[0]; off+=48
    b1=np.frombuffer(raw[off:off+8],dtype=np.int8).astype(np.float32)*scales[1]; off+=8
    w2=np.frombuffer(raw[off:off+16],dtype=np.int8).astype(np.float32).reshape(2,8)*scales[2]; off+=16
    b2=np.frombuffer(raw[off:off+2],dtype=np.int8).astype(np.float32)*scales[3]
    def f(x):
        x=np.asarray(x,dtype=np.float32)
        return np.tanh(x@w1.T+b1)@w2.T+b2
    return raw,f

PACKETS={}
for name in ['transformer','fly']:
    PACKETS[name]=load_packet(ROOT/f'packets/{name}_teacher_97b.iap')
SRC_ACTIONS=PACKETS['transformer'][1](ST).argmax(1).astype(int)
assert np.array_equal(SRC_ACTIONS,PACKETS['fly'][1](ST).argmax(1))

# Each abstract binary teacher action becomes an ordered pair over four recipient
# primitive actions. A world-specific permutation defines both macro codewords.
CODEBOOKS=[(tuple(p[:2]),tuple(p[2:])) for p in itertools.permutations(range(4))]
_PATTERN_CACHE={}

def candidate_patterns(cb_idx:int, source_ctx:int, L:int, srcpred:np.ndarray):
    """All ontology expansions consistent with one source context.

    The recipient chain contains three source concepts, each expanded to either
    two decision microstates or to two decision microstates plus one nuisance
    microstate. Optional prefix/suffix nuisance states have no teacher concept.
    """
    key=(cb_idx,source_ctx,L,tuple(srcpred[source_ctx].tolist()))
    if key in _PATTERN_CACHE: return _PATTERN_CACHE[key]
    cb=CODEBOOKS[cb_idx]; out=[]
    for pre in (0,1):
        for suf in (0,1):
            for lens in itertools.product((2,3),repeat=3):
                if pre+suf+sum(lens)!=L: continue
                stage_variants=[]
                for s,ln in enumerate(lens):
                    m=cb[int(srcpred[source_ctx,s])]
                    if ln==2:
                        stage_variants.append([[m[0],m[1]]])
                    else:
                        stage_variants.append([
                            [-1,m[0],m[1]], [m[0],-1,m[1]], [m[0],m[1],-1]
                        ])
                for v in itertools.product(*stage_variants):
                    out.append(([-1]*pre)+list(v[0])+list(v[1])+list(v[2])+([-1]*suf))
    arr=np.unique(np.asarray(out,dtype=np.int8),axis=0) if out else np.empty((0,L),np.int8)
    _PATTERN_CACHE[key]=arr
    return arr

# ---------------------------------------------------------------------------
# Alien recipient ontology.
# ---------------------------------------------------------------------------
def make_world(seed:int,outdim:int=8):
    r=np.random.default_rng(seed)
    ctx_perm=r.permutation(8)                       # local chain -> source context
    cb_idx=int(r.integers(len(CODEBOOKS))); cb=CODEBOOKS[cb_idx]
    chains=[]; outcomes=[]; raw_latent=[]
    A=r.normal(size=(outdim,14)).astype(np.float32)/np.sqrt(14)
    B=r.normal(size=(outdim,14)).astype(np.float32)/np.sqrt(14)
    bias=r.uniform(-.4,.4,outdim).astype(np.float32)
    for local_ctx,source_ctx in enumerate(ctx_perm):
        seq=[]; desc=[]
        pre=int(r.integers(2)); suf=int(r.integers(2))
        seq += [-1]*pre; desc += [(None,'nuisance')]*pre
        for stage in range(3):
            abstract_action=int(SRC_ACTIONS[source_ctx*3+stage]); macro=cb[abstract_action]
            ln=int(r.integers(2,4))
            if ln==2:
                vals=[macro[0],macro[1]]; roles=[(stage,'macro0'),(stage,'macro1')]
            else:
                nuisance=int(r.integers(3)); vals=[]; roles=[]; k=0
                for p in range(3):
                    if p==nuisance:
                        vals.append(-1); roles.append((None,'nuisance'))
                    else:
                        vals.append(macro[k]); roles.append((stage,f'macro{k}')); k+=1
            seq += vals; desc += roles
        seq += [-1]*suf; desc += [(None,'nuisance')]*suf
        ids=[]; L=len(seq)
        for pos,(outcome,(stage,role)) in enumerate(zip(seq,desc)):
            if stage is None:
                src=np.zeros(6,np.float32); rolevec=np.array([0,0,0,1],np.float32)
            else:
                src=ST[source_ctx*3+stage]
                rolevec=np.array([float(role=='macro0'),float(role=='macro1'),stage/2,0],np.float32)
            posfeat=np.array([2*pos/max(1,L-1)-1, math.sin((pos+1)*.7)],np.float32)
            nuisance=np.array([1 if outcome<0 else -1,r.normal(0,.25)],np.float32)
            z=np.r_[src,rolevec,posfeat,nuisance].astype(np.float32)
            raw_latent.append(np.tanh(1.1*(z@A.T+bias))+.13*(z@B.T)**3/(1+(z@B.T)**2))
            outcomes.append(outcome); ids.append(len(outcomes)-1)
        chains.append(ids)
    Y=np.stack(raw_latent).astype(np.float32)
    Y=(Y-Y.mean(0,keepdims=True))/(Y.std(0,keepdims=True)+1e-4)
    return {'Y':Y,'tgt':np.asarray(outcomes,int),'chains':chains,'ctx_perm':ctx_perm,'cb_idx':cb_idx}

# ---------------------------------------------------------------------------
# Ontology grounder.
# ---------------------------------------------------------------------------
def feasible(comp:np.ndarray,fixed=None)->bool:
    c=comp.copy(); n=8
    if fixed is not None:
        i,j=fixed
        if not c[i,j]: return False
        c[i,:]=False; c[i,j]=True
        for ii in range(n):
            if ii!=i: c[ii,j]=False
    match=[-1]*n
    def dfs(i,seen):
        for j in range(n):
            if c[i,j] and not seen[j]:
                seen[j]=True
                if match[j]<0 or dfs(match[j],seen): match[j]=i; return True
        return False
    return all(dfs(i,[False]*n) for i in range(n))

def ontology_ground(packet_fn,true,budget:int=36):
    srcpred=packet_fn(ST).argmax(1).reshape(8,3)
    pats={}; masks={}
    for ci in range(24):
        for i,ch in enumerate(true['chains']):
            L=len(ch)
            for j in range(8):
                p=candidate_patterns(ci,j,L,srcpred)
                pats[(ci,i,j)]=p; masks[(ci,i,j)]=np.ones(len(p),bool)
    queried={}
    for _ in range(budget):
        viable=[]
        for ci in range(24):
            comp=np.array([[masks[(ci,i,j)].any() for j in range(8)] for i in range(8)],bool)
            if feasible(comp): viable.append((ci,comp))
        if not viable: raise RuntimeError('ontology hypothesis set became empty')
        counts=[np.zeros((len(ch),5),np.float64) for ch in true['chains']] # nuisance + 4 actions
        for ci,comp in viable:
            for i,ch in enumerate(true['chains']):
                for j in range(8):
                    if not comp[i,j] or not feasible(comp,(i,j)): continue
                    pp=pats[(ci,i,j)][masks[(ci,i,j)]]
                    if not len(pp): continue
                    local=np.zeros((len(ch),5),float)
                    for out in range(-1,4): local[:,out+1]=(pp==out).mean(0)
                    counts[i]+=local
        best=None; bestscore=-1
        for i,ch in enumerate(true['chains']):
            for lp,gidx in enumerate(ch):
                if gidx in queried: continue
                c=counts[i][lp]
                if c.sum()==0: continue
                p=c/c.sum(); ent=-np.sum(p[p>0]*np.log(p[p>0]+1e-12))
                score=ent*(1+.1*(1-p[0]))
                if score>bestscore: bestscore=score; best=(i,lp,gidx)
        if best is None: break
        i,lp,gidx=best; observed=int(true['tgt'][gidx]); queried[gidx]=observed
        for ci in range(24):
            for j in range(8): masks[(ci,i,j)] &= (pats[(ci,i,j)][:,lp]==observed)
    # posterior prediction over every local state
    viable=[]
    for ci in range(24):
        comp=np.array([[masks[(ci,i,j)].any() for j in range(8)] for i in range(8)],bool)
        if feasible(comp): viable.append((ci,comp))
    counts=[np.zeros((len(ch),5),np.float64) for ch in true['chains']]
    for ci,comp in viable:
        for i,ch in enumerate(true['chains']):
            for j in range(8):
                if not comp[i,j] or not feasible(comp,(i,j)): continue
                pp=pats[(ci,i,j)][masks[(ci,i,j)]]
                if not len(pp): continue
                local=np.zeros((len(ch),5),float)
                for out in range(-1,4): local[:,out+1]=(pp==out).mean(0)
                counts[i]+=local
    pred=np.full(len(true['tgt']),-9,int); probs=np.zeros((len(pred),5),float)
    for i,ch in enumerate(true['chains']):
        p=counts[i]/np.maximum(counts[i].sum(1,keepdims=True),1e-12)
        probs[ch]=p; pred[ch]=p.argmax(1)-1
    decision=true['tgt']>=0
    action_acc=float(np.mean(pred[decision]==true['tgt'][decision]))
    role_acc=float(np.mean((pred>=0)==decision))
    seq=[]
    for ch in true['chains']:
        ids=[x for x in ch if true['tgt'][x]>=0]
        seq.append(np.all(pred[ids]==true['tgt'][ids]))
    return {'pred':pred,'probs':probs,'action_acc':action_acc,'sequence_acc':float(np.mean(seq)),
            'role_acc':role_acc,'queries':list(queried),'viable_codebooks':len(viable)}

# ---------------------------------------------------------------------------
# Recipient architectures and cultural absorption.
# ---------------------------------------------------------------------------
class FeatureTransformer(nn.Module):
    def __init__(self,nin=8,actions=4,d=24,heads=4):
        super().__init__(); self.feature=nn.Parameter(torch.randn(nin,d)*.05); self.val=nn.Linear(1,d,bias=False)
        self.cls=nn.Parameter(torch.randn(1,1,d)*.05)
        layer=nn.TransformerEncoderLayer(d_model=d,nhead=heads,dim_feedforward=48,dropout=0.,activation='gelu',batch_first=True,norm_first=True)
        self.enc=nn.TransformerEncoder(layer,num_layers=1); self.out=nn.Linear(d,actions)
    def forward(self,x):
        if x.ndim==1: x=x[None,:]
        B=x.shape[0]; tok=self.feature[None,:,:]+self.val(x[:,:,None])
        return self.out(self.enc(torch.cat([self.cls.expand(B,-1,-1),tok],1))[:,0])
    def project(self): pass

def make_student(kind,seed,flyseed=None):
    torch.manual_seed(seed)
    if kind=='transformer': return FeatureTransformer()
    graph=ROOT/f'data/graph_{223 if flyseed==7102 else 239}.npz'
    return InternalFly(str(graph),flyseed,inputs=8,actions=4)

def metrics(model,world):
    with torch.no_grad(): pred=model(torch.tensor(world['Y'])).argmax(1).cpu().numpy()
    decision=world['tgt']>=0
    action=float(np.mean(pred[decision]==world['tgt'][decision]))
    seq=[]
    for ch in world['chains']:
        ids=[x for x in ch if world['tgt'][x]>=0]
        seq.append(np.all(pred[ids]==world['tgt'][ids]))
    return action,float(np.mean(seq))

def q_for_action(a):
    q=np.full(4,-1.,np.float32); q[int(a)]=1.; return q

def train_targets(model,world,indices,targets,seed,steps,lr=None):
    if lr is None: lr=.03 if isinstance(model,InternalFly) else .01
    rng=np.random.default_rng(seed); opt=torch.optim.Adam(model.parameters(),lr=lr); replay=[]
    checkpoints={0:metrics(model,world)}
    for it in range(1,steps+1):
        k=int(rng.choice(indices)); replay.append((world['Y'][k].copy(),targets[k].copy()))
        ids=rng.integers(len(replay),size=min(32,len(replay)))
        x=torch.tensor(np.stack([replay[j][0] for j in ids])); t=torch.tensor(np.stack([replay[j][1] for j in ids]))
        loss=F.mse_loss(model(x),t); opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.); opt.step()
        if hasattr(model,'project'): model.project()
        if it in (128,256,512,1024) or it==steps: checkpoints[it]=metrics(model,world)
    return checkpoints

def identity_targets(packet_fn,world):
    """Negative control: assume source and recipient ontologies are already aligned."""
    srcpred=packet_fn(ST).argmax(1).reshape(8,3)
    target=np.zeros((len(world['Y']),4),np.float32); idx=[]
    for i,ch in enumerate(world['chains']):
        L=len(ch)
        for lp,gid in enumerate(ch):
            stage=min(2,int(3*lp/max(1,L)))
            target[gid]=q_for_action(int(srcpred[i,stage])); idx.append(gid)
    return np.asarray(idx,int),target

def run_transfer(direction,reps=6,start=0,queries=36,steps=None):
    teacher='transformer' if direction=='t2f' else 'fly'; packet_fn=PACKETS[teacher][1]
    if steps is None: steps=1024 if direction=='t2f' else 512
    rows=[]
    for rep in range(start,start+reps):
        seed=1200000+(0 if direction=='t2f' else 100000)+rep
        world=make_world(seed); g=ontology_ground(packet_fn,world,queries)
        translated=np.stack([q_for_action(a) if a>=0 else np.zeros(4,np.float32) for a in g['pred']])
        cultural_idx=np.flatnonzero(g['pred']>=0)
        def mk(offset):
            if direction=='t2f': return make_student('fly',seed+offset,7102 if rep%2==0 else 7103)
            return make_student('transformer',seed+offset)
        m=mk(10); cp=train_targets(m,world,cultural_idx,translated,seed+101,steps); final=cp[steps]
        rows.append({'direction':direction,'rep':rep,'condition':'grounded_culture','queries':queries,
                     'ground_action':g['action_acc'],'ground_sequence':g['sequence_acc'],'ground_role':g['role_acc'],
                     'steps':steps,'final_action':final[0],'final_sequence':final[1],
                     'cp128_action':cp.get(128,('', ''))[0],'cp128_sequence':cp.get(128,('', ''))[1],
                     'cp256_action':cp.get(256,('', ''))[0],'cp256_sequence':cp.get(256,('', ''))[1]})
        # Same reward-bearing calibration states and same number of optimizer updates, but no packet.
        query_idx=[]; query_target=np.zeros((len(world['Y']),4),np.float32)
        for k in g['queries']:
            if world['tgt'][k]>=0:
                query_idx.append(k); query_target[k]=q_for_action(world['tgt'][k])
        m=mk(1010); cp=train_targets(m,world,np.asarray(query_idx,int),query_target,seed+201,steps); final=cp[steps]
        rows.append({'direction':direction,'rep':rep,'condition':'query_only_no_packet','queries':queries,
                     'ground_action':'','ground_sequence':'','ground_role':'','steps':steps,
                     'final_action':final[0],'final_sequence':final[1],
                     'cp128_action':cp.get(128,('', ''))[0],'cp128_sequence':cp.get(128,('', ''))[1],
                     'cp256_action':cp.get(256,('', ''))[0],'cp256_sequence':cp.get(256,('', ''))[1]})
        # Packet present but no ontology translation.
        ii,it=identity_targets(packet_fn,world); m=mk(2010); cp=train_targets(m,world,ii,it,seed+301,steps); final=cp[steps]
        rows.append({'direction':direction,'rep':rep,'condition':'ungrounded_identity','queries':0,
                     'ground_action':'','ground_sequence':'','ground_role':'','steps':steps,
                     'final_action':final[0],'final_sequence':final[1],
                     'cp128_action':cp.get(128,('', ''))[0],'cp128_sequence':cp.get(128,('', ''))[1],
                     'cp256_action':cp.get(256,('', ''))[0],'cp256_sequence':cp.get(256,('', ''))[1]})
    return rows

def write_csv(path,rows):
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode',choices=['ground','transfer'],default='ground')
    ap.add_argument('--teacher',choices=['fly','transformer'],default='transformer')
    ap.add_argument('--direction',choices=['f2t','t2f'],default='f2t')
    ap.add_argument('--budget',type=int,default=36); ap.add_argument('--reps',type=int,default=3); ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--steps',type=int,default=None); ap.add_argument('--out',default='gate2f_rerun.csv')
    a=ap.parse_args()
    if a.mode=='ground':
        rows=[]; fn=PACKETS[a.teacher][1]
        for rep in range(a.start,a.start+a.reps):
            world=make_world(1800000+(0 if a.teacher=='transformer' else 100000)+rep)
            g=ontology_ground(fn,world,a.budget)
            rows.append({'teacher':a.teacher,'budget':a.budget,'rep':rep,'local_states':len(world['Y']),
                         'decision_states':int((world['tgt']>=0).sum()),'action_acc':g['action_acc'],
                         'sequence_acc':g['sequence_acc'],'role_acc':g['role_acc']})
    else:
        rows=run_transfer(a.direction,a.reps,a.start,a.budget,a.steps)
    write_csv(a.out,rows); print({'rows':len(rows),'out':a.out})
if __name__=='__main__': main()
