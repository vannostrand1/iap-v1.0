# IAP Gate 1H — Induced Grammar + Proposal-Efficient Grounding

Gate 1H combines Gate 1G's learned semantic operators with Gate 1F-style self-bootstrapping proposal learning.

## What changed

The hand-authored signed-permutation grammar remains removed. The 3 operators induced in Gate 1G generate a 128-element semantic group. Gate 1H derives a subgroup chain of sizes 1 -> 8 -> 64 -> 128 and automatically obtains an 8 x 8 x 2 coset normal form. This is a factorized grammar induced from the learned group, not from coordinate/sign semantics.

The proposal model is trained only from reward scores of hypotheses it actually samples. It scores 20/128 meanings per training task (15.625%) and never uses the hidden transform ID as a target.

At inference it generates a beam from the induced 8 x 8 x 2 normal form, empirically verifies only that beam, and actively selects new calibration interactions by disagreement. It never performs a full 128-way reward scan.

## Final held-out results

Six seeds x 20 tasks = 120 held-out tasks per condition. Both observation and action transform components are held out.

|   beam |   N |   tasks |   policy_transfer |   ci95_low |   ci95_high |   full_exact |   mean_unique_scored |   fraction_language_per_step |
|-------:|----:|--------:|------------------:|-----------:|------------:|-------------:|---------------------:|-----------------------------:|
|      8 |   8 |     120 |          0.927995 |   0.902471 |    0.949743 |     0.816667 |              25.7417 |                      0.0625  |
|      8 |  12 |     120 |          0.95651  |   0.941667 |    0.967578 |     0.9      |              29.5667 |                      0.0625  |
|     12 |   8 |     120 |          0.951562 |   0.936979 |    0.963542 |     0.833333 |              35.2917 |                      0.09375 |
|     12 |  12 |     120 |          0.9625   |   0.954814 |    0.969271 |     0.9      |              39.725  |                      0.09375 |

Headline operating point: beam=12 (9.375% of the learned language per grounding step): 95.156% transfer at N=8 and 96.250% at N=12.

Tighter beam=8 (6.25% per step): 92.799% at N=8 and 95.651% at N=12.

## Training trajectory

The mean best reward-consistency MSE among the 20 sampled meanings fell from 0.2357 in round 1 to 0.0440 in round 8. No exhaustive 128-way reward oracle was used.

## Negative approaches retained

A raw stochastic group walk with 16-32 unique proposals reached only ~60-76% transfer. A categorical 128-class self-training shortcut reached only ~62-72%. A canonical BFS-tree autoregressive policy also failed (~82% at N=8). These failures motivated the induced coset normal form.

## Interpretation

Gate 1H demonstrates that the receiver can use a semantic language induced from environmental symmetry, learn where to search that language from its own sampled empirical survivors, and recover ~96% behavior without exhaustive semantic scoring in either training or inference.

## Remaining scaffolding

The semantic-operator induction still assumes a generic 4x4 orthogonal linear hypothesis class; action correspondence is solved exactly as a 4x4 assignment; the 16-byte codec is retained. Gate 1H removes the human-authored semantic grammar and exhaustive closure scans, not all structural assumptions.
