import argparse, itertools, json, math, os, random, time
from dataclasses import dataclass
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

# ---------------- World/task family ----------------
DIRS=[(dx,dy) for dx in (-1,0,1) for dy in (-1,0,1) if not(dx==0 and dy==0)]
STATES=np.array([(fx,fy,tx,ty) for fx,fy in DIRS for tx,ty in DIRS],dtype=np.float32)
MOVES=np.array([[-1,0],[1,0],[0,1],[0,-1]],dtype=np.float32)
# Only automorphisms that map the 64-state manifold onto itself.
OBS_PERMS=[p for p in itertools.permutations(range(4)) if (set(p[:2]) in ({0,1},{2,3}) and set(p[2:]) in ({0,1},{2,3}) and set(p[:2])!=set(p[2:]))]
FLIPS=list(itertools.product([-1,1],repeat=4))
OBS_TRANSFORMS=[(p,f) for p in OBS_PERMS for f in FLIPS]  # 128
ACTION_PERMS=list(itertools.permutations(range(4))) # 24

def build_basis():
    feats=[]
    for s in STATES:
        f=s[:2]; t=s[2:]; ft=float(np.dot(f,t)); det=float(f[0]*t[1]-f[1]*t[0])
        for m in MOVES:
            pf=float(np.dot(m,f)); pt=float(np.dot(m,t))
            cf=float(m[0]*f[1]-m[1]*f[0]); ct=float(m[0]*t[1]-m[1]*t[0])
            feats.append([
                pf,pt,abs(pf),abs(pt),float(pf>0),float(pt>0),float(pf<0),float(pt<0),
                pf*pt,pf*pf,pt*pt,ft,cf,ct,abs(cf),abs(ct),
                float((pf>0)&(pt<=0)),float((pf<=0)&(pt>0)),float((pf>0)&(pt>0)),
                m[0],m[1],det,pf*ft,pt*ft
            ])
    B=np.asarray(feats,dtype=np.float32)
    B=(B-B.mean(0,keepdims=True))/(B.std(0,keepdims=True)+1e-5)
    return B
BASIS=build_basis(); D_TASK=BASIS.shape[1]
BASE_THETA=np.array([.8,-1,.05,-.05,.4,-.65,-.1,-.15,-.15,.03,-.03,0,.04,-.04,0,0,.35,-.2,-.3,0,0,0,.05,-.05],dtype=np.float32)

def sample_q(batch,device,g=None):
    theta=torch.randn(batch,D_TASK,device=device,generator=g)*.55+torch.tensor(BASE_THETA,device=device)
    q=(theta@torch.tensor(BASIS,device=device).T)/math.sqrt(D_TASK/2)
    q=q.view(batch,64,4)+torch.randn(batch,1,4,device=device,generator=g)*.12
    return q

def build_maps():
    sti={tuple(map(int,s)):i for i,s in enumerate(STATES)}
    maps=[]; oi=[]; ai=[]
    for oidx,(p,f) in enumerate(OBS_TRANSFORMS):
        inv=[]
        for o in STATES.astype(np.int8):
            c=np.empty(4,dtype=np.int8)
            for k in range(4): c[p[k]]=int(o[k])*int(f[k])
            inv.append(sti[tuple(map(int,c))])
        for aidx,ap in enumerate(ACTION_PERMS):
            m=[]
            for os in range(64):
                for ao in range(4): m.append(inv[os]*4+ap[ao])
            maps.append(m); oi.append(oidx); ai.append(aidx)
    return np.asarray(maps,dtype=np.int16),np.asarray(oi),np.asarray(ai)
MAPS,MAP_OBS,MAP_ACT=build_maps(); T=len(MAPS)

@dataclass
class Split:
    train:np.ndarray; combo:np.ndarray; held_obs:np.ndarray; held_act:np.ndarray; held_both:np.ndarray
    tr_obs:np.ndarray; te_obs:np.ndarray; tr_act:np.ndarray; te_act:np.ndarray

def make_split(seed=123):
    rng=np.random.default_rng(seed); obs=np.arange(len(OBS_TRANSFORMS)); act=np.arange(24); rng.shuffle(obs); rng.shuffle(act)
    no=int(.8*len(obs)); na=int(.8*len(act)); tro=np.sort(obs[:no]); teo=np.sort(obs[no:]); tra=np.sort(act[:na]); tea=np.sort(act[na:])
    base=np.flatnonzero(np.isin(MAP_OBS,tro)&np.isin(MAP_ACT,tra)); pp=rng.permutation(base); nc=int(.15*len(pp)); combo=np.sort(pp[:nc]); train=np.sort(pp[nc:])
    ho=np.flatnonzero(np.isin(MAP_OBS,teo)&np.isin(MAP_ACT,tra)); ha=np.flatnonzero(np.isin(MAP_OBS,tro)&np.isin(MAP_ACT,tea)); hb=np.flatnonzero(np.isin(MAP_OBS,teo)&np.isin(MAP_ACT,tea))
    return Split(train,combo,ho,ha,hb,tro,teo,tra,tea)

# ---------------- Learned protocol codec ----------------
class Codec(nn.Module):
    def __init__(self,latent=16):
        super().__init__(); self.latent=latent
        self.enc=nn.Sequential(nn.Linear(256,192),nn.GELU(),nn.Linear(192,96),nn.GELU(),nn.Linear(96,latent),nn.Tanh())
        self.dec=nn.Sequential(nn.Linear(latent,96),nn.GELU(),nn.Linear(96,192),nn.GELU(),nn.Linear(192,256))
    def encode(self,x,quant=True):
        z=self.enc(x)
        if quant:
            zh=torch.round(z*127)/127
            z=z+(zh-z).detach()
        return z
    def decode(self,z): return self.dec(z)
    def forward(self,x):
        z=self.encode(x,True); return self.decode(z),z

def codec_loss(pred,target):
    mse=F.mse_loss(pred,target)
    ce=F.cross_entropy(pred.view(-1,4),target.view(-1,4).argmax(-1))
    return mse+.35*ce,mse.detach(),ce.detach()

def train_codec(args,device):
    torch.manual_seed(args.seed); np.random.seed(args.seed); random.seed(args.seed); torch.set_num_threads(args.threads)
    model=Codec(args.latent).to(device); opt=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=1e-5)
    g=torch.Generator(device=device); g.manual_seed(args.seed+10); hist=[]; t0=time.time()
    for step in range(1,args.steps+1):
        q=sample_q(args.batch,device,g).flatten(1)
        pred,z=model(q); loss,mse,ce=codec_loss(pred,q)
        opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),5); opt.step()
        if step==1 or step%args.log_every==0:
            with torch.no_grad():
                pa=pred.view(-1,64,4).argmax(-1); ta=q.view(-1,64,4).argmax(-1); acc=(pa==ta).float().mean().item()
                sat=(z.abs()>.98).float().mean().item()
            hist.append({'step':step,'loss':float(loss.detach()),'mse':float(mse),'ce':float(ce),'canonical_policy_acc':acc,'latent_saturation':sat,'elapsed_s':time.time()-t0})
            print(f'codec {step:5d} loss={loss.item():.4f} mse={mse.item():.4f} policy={acc:.3f} sat={sat:.2f} t={time.time()-t0:.1f}s',flush=True)
    return model,hist

# ---------------- Grounding/evaluation ----------------
def choose_transform(decoded_q_flat, calib_pos, calib_r, candidate_ids=None):
    # decoded_q_flat [256]; calibration positions index alien state-action coordinates.
    ids=np.arange(T) if candidate_ids is None else np.asarray(candidate_ids)
    mm=MAPS[ids][:,calib_pos] # [C,N] canonical positions hypothesized by each representation mapping
    pred=decoded_q_flat[mm]
    mse=((pred-calib_r[None,:])**2).mean(1)
    return int(ids[int(np.argmin(mse))]),float(np.min(mse))

def policy_metrics(decoded_q_flat,est_tid,true_q_flat,true_tid):
    pred_alien=decoded_q_flat[MAPS[est_tid]].reshape(64,4)
    true_alien=true_q_flat[MAPS[true_tid]].reshape(64,4)
    pa=pred_alien.argmax(1); ta=true_alien.argmax(1)
    opt=float(np.mean(pa==ta)); chosen=true_alien[np.arange(64),pa]; best=true_alien.max(1); worst=true_alien.min(1)
    reg=float(np.mean(best-chosen)); cap=float(1-reg/(float(np.mean(best-worst))+1e-8))
    return opt,reg,cap

def evaluate(model,split_ids,N,n_tasks,noise,seed,device,mean_q):
    rng=np.random.default_rng(seed); g=torch.Generator(device=device); g.manual_seed(seed+999)
    rows=[]
    with torch.no_grad():
        qs=sample_q(n_tasks,device,g).flatten(1); z=model.encode(qs,True); dec=model.decode(z).cpu().numpy(); qsnp=qs.cpu().numpy(); znp=z.cpu().numpy()
        # wrong task and random packets go through same learned decoder.
        zw=np.roll(znp,1,axis=0)
        zr=rng.integers(-127,128,size=znp.shape,dtype=np.int16).astype(np.float32)/127.0
        dw=model.decode(torch.tensor(zw,device=device)).cpu().numpy(); dr=model.decode(torch.tensor(zr,device=device)).cpu().numpy()
    cond_data={'Learned-IAP':dec,'Oracle-full-Q':qsnp,'Wrong-task-packet':dw,'Random-packet':dr,'No-packet-mean-Q':np.broadcast_to(mean_q,(n_tasks,256))}
    for i in range(n_tasks):
        tid=int(rng.choice(split_ids)); trueq=qsnp[i]
        pos=rng.integers(0,256,size=N); r=trueq[MAPS[tid][pos]]+rng.normal(0,noise,size=N)
        for cond,data in cond_data.items():
            est,mse=choose_transform(data[i],pos,r)
            op,rg,cp=policy_metrics(data[i],est,trueq,tid)
            rows.append({'task':i,'condition':cond,'optimal_action_rate':op,'mean_regret':rg,'value_capture':cp,'ground_mse':mse,'transform_exact':float(est==tid)})
    return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--steps',type=int,default=2500); ap.add_argument('--batch',type=int,default=256); ap.add_argument('--latent',type=int,default=16)
    ap.add_argument('--lr',type=float,default=2e-3); ap.add_argument('--threads',type=int,default=4); ap.add_argument('--seed',type=int,default=17); ap.add_argument('--split-seed',type=int,default=123)
    ap.add_argument('--log-every',type=int,default=250); ap.add_argument('--eval-tasks',type=int,default=160); ap.add_argument('--noise',type=float,default=.08); ap.add_argument('--out',default='learned_codec_results')
    args=ap.parse_args(); os.makedirs(args.out,exist_ok=True); device=torch.device('cpu'); split=make_split(args.split_seed)
    model,hist=train_codec(args,device); pd.DataFrame(hist).to_csv(os.path.join(args.out,'train_history.csv'),index=False)
    torch.save({'state_dict':model.state_dict(),'args':vars(args)},os.path.join(args.out,'codec.pt'))
    # Estimate no-packet prior from many training-distribution tasks.
    g=torch.Generator(); g.manual_seed(555)
    with torch.no_grad(): mean_q=sample_q(4096,device,g).flatten(1).mean(0).cpu().numpy()
    splits={'heldout_combo':split.combo,'heldout_observation_component':split.held_obs,'heldout_action_component':split.held_act,'heldout_both_components':split.held_both}
    allrows=[]
    for N in [4,8,16,32]:
        for j,(sn,ids) in enumerate(splits.items()):
            df=evaluate(model,ids,N,args.eval_tasks,args.noise,8000+N*37+j,device,mean_q); df.insert(0,'N',N); df.insert(0,'split',sn); allrows.append(df)
            ag=df.groupby('condition')[['optimal_action_rate','mean_regret','value_capture','ground_mse','transform_exact']].mean().round(4)
            print('\n',sn,'N=',N,'\n',ag,flush=True)
    raw=pd.concat(allrows,ignore_index=True); raw.to_csv(os.path.join(args.out,'evaluation_raw.csv'),index=False)
    agg=raw.groupby(['split','N','condition']).agg(
        optimal_action_rate=('optimal_action_rate','mean'),optimal_action_sd=('optimal_action_rate','std'),mean_regret=('mean_regret','mean'),
        value_capture=('value_capture','mean'),ground_mse=('ground_mse','mean'),transform_exact=('transform_exact','mean')).reset_index()
    agg.to_csv(os.path.join(args.out,'evaluation_summary.csv'),index=False)
    # packet semantics diagnostics: sensitivity / uniqueness across unseen tasks.
    g=torch.Generator(); g.manual_seed(777)
    with torch.no_grad():
        qd=sample_q(512,device,g).flatten(1); z=model.encode(qd,True); rec=model.decode(z)
        canon_acc=(rec.view(-1,64,4).argmax(-1)==qd.view(-1,64,4).argmax(-1)).float().mean().item(); rec_mse=F.mse_loss(rec,qd).item()
        zraw=model.encode(qd,False); qerr=(z-zraw).abs().mean().item(); zstd=z.std(0).mean().item()
        sample_bytes=torch.clamp(torch.round(zraw[0]*127),-127,127).to(torch.int8).numpy().tobytes()
    open(os.path.join(args.out,'sample_packet.iap1'),'wb').write(sample_bytes)
    # Task diversity: how good is a single mean policy on fresh canonical tasks?
    tq=qd.view(-1,64,4).cpu().numpy(); mp=mean_q.reshape(64,4).argmax(1); baseline=np.mean([np.mean(mp==x.argmax(1)) for x in tq])
    summary={
        'gate':'IAP Gate 1A: learned packet protocol + representation-neutral grounding search',
        'packet_payload_bytes':args.latent,'packet_bits':args.latent*8,'codec_shared_weights_not_counted':True,
        'packet_quantization':'signed int8, fixed global code range; straight-through quantization during training',
        'canonical_reconstruction_mse':rec_mse,'canonical_policy_accuracy_after_codec':canon_acc,'mean_abs_quantization_error':qerr,'mean_latent_dimension_std':zstd,
        'fresh_task_mean_policy_accuracy':float(baseline),
        'transforms':{'total':T,'obs_components':len(OBS_TRANSFORMS),'action_components':len(ACTION_PERMS),'train_exact':len(split.train),'heldout_combo':len(split.combo),'heldout_obs':len(split.held_obs),'heldout_act':len(split.held_act),'heldout_both':len(split.held_both)},
        'training':{'steps':args.steps,'batch':args.batch,'noise_sd_eval':args.noise},
        'evaluation':agg.to_dict(orient='records'),
        'limitation':'Packet encoder/decoder are learned end-to-end, but alien grounding still uses an explicit search over the permitted representation-transformation family. A fully amortized learned grounder is Gate 1B.'
    }
    with open(os.path.join(args.out,'summary.json'),'w') as f: json.dump(summary,f,indent=2)
    print('\nSUMMARY\n'+json.dumps(summary,indent=2),flush=True)

if __name__=='__main__': main()
