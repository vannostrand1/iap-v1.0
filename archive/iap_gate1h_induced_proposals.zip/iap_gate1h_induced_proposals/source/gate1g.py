import os,sys,time,json,itertools,math
import numpy as np,pandas as pd, torch
from scipy.optimize import linear_sum_assignment
HERE=os.path.dirname(os.path.abspath(__file__))
BASE=HERE
sys.path.insert(0,BASE)
import learned_codec as lc

S=lc.STATES.astype(np.float64)
STATES_I=lc.STATES.astype(np.int8)
ACTION_PERMS=np.asarray(lc.ACTION_PERMS,dtype=np.int64)
ID=np.arange(64,dtype=np.int16)

def rand_orth(rng):
    A=rng.normal(size=(4,4));Q,R=np.linalg.qr(A);sg=np.sign(np.diag(R));sg[sg==0]=1;Q*=sg[None,:];return Q

def icp_operator(rng,iters=10):
    W=rand_orth(rng)
    for _ in range(iters):
        Y=S@W.T
        C=((Y[:,None,:]-S[None,:,:])**2).sum(-1)
        _,cols=linear_sum_assignment(C)
        T=S[cols]
        U,_,Vt=np.linalg.svd(T.T@S)
        W=U@Vt
    Y=S@W.T;C=((Y[:,None,:]-S[None,:,:])**2).sum(-1);_,cols=linear_sum_assignment(C)
    ass=C[np.arange(64),cols]
    return W,cols.astype(np.int16),float(ass.mean()),float(ass.max())

def discover(n_starts=10000,seed=2,iters=10,tol=1e-8):
    rng=np.random.default_rng(seed);uniq={};valid=0;t=time.time();rows=[]
    checkpoints=set([100,250,500,1000,2000,5000,n_starts])
    for i in range(1,n_starts+1):
        W,sm,me,mx=icp_operator(rng,iters)
        if mx<tol and len(np.unique(sm))==64:
            valid+=1;uniq[tuple(map(int,sm))]=(W,sm,me,mx)
        if i in checkpoints:
            rows.append({'starts':i,'valid_convergences':valid,'unique_operators':len(uniq),'elapsed_s':time.time()-t})
            print('DISCOVER',rows[-1],flush=True)
    ops=list(uniq.values());maps=np.stack([x[1] for x in ops]);Ws=np.stack([x[0] for x in ops])
    return Ws,maps,pd.DataFrame(rows)

def comp(a,b): return a[b]
def closure(gens):
    seen={tuple(ID.tolist()):ID};front=[ID]
    while front:
        x=front.pop()
        for g in gens:
            for y in (comp(g,x),comp(x,g)):
                k=tuple(map(int,y))
                if k not in seen:seen[k]=y.copy();front.append(y.copy())
    return list(seen.values())

def greedy_generators(maps,target=128):
    selected=[];sel_idx=[];remaining=list(range(len(maps)));cur=closure([]);hist=[]
    while len(cur)<target and remaining:
        best=(-1,None,None)
        for i in remaining:
            c=closure(selected+[maps[i]])
            if len(c)>best[0]:best=(len(c),i,c)
        selected.append(maps[best[1]]);sel_idx.append(best[1]);remaining.remove(best[1]);cur=best[2]
        hist.append({'generator_count':len(selected),'added_operator_index':best[1],'closure_size':len(cur)})
        print('GEN',hist[-1],flush=True)
        if len(selected)>12: break
    return np.stack(selected),sel_idx,np.stack(cur),pd.DataFrame(hist)

def score_candidates(dq,pos,r,maps):
    pos=np.asarray(pos,dtype=np.int64);r=np.asarray(r,dtype=np.float32);si=pos//4;ao=pos%4;q=dq.reshape(64,4)
    ci=maps[:,si].astype(np.int64);qv=q[ci];err=(qv-r[None,:,None])**2
    K=len(maps);cost=np.zeros((K,4,4),dtype=np.float32)
    for aobs in range(4):
        mm=(ao==aobs)
        if np.any(mm):cost[:,aobs,:]=err[:,mm,:].sum(1)
    vals=np.zeros((K,24),dtype=np.float32)
    for pi,ap in enumerate(ACTION_PERMS):
        v=np.zeros(K,dtype=np.float32)
        for aobs in range(4):v+=cost[:,aobs,ap[aobs]]
        vals[:,pi]=v
    bi=vals.argmin(1);sc=vals[np.arange(K),bi]/max(1,len(pos))
    return sc,bi

def pred_for(dq,sm,ap): return dq.reshape(64,4)[sm][:,ap].reshape(-1)

def episode(dq,trueq,tid,maps,total,seed,active=True,topk=16,start=2):
    rng=np.random.default_rng(seed);pos=[];rr=[]
    for _ in range(start):
        p=int(rng.integers(256));pos.append(p);rr.append(trueq[lc.MAPS[tid][p]]+rng.normal(0,.08))
    while len(pos)<total:
        sc,bi=score_candidates(dq,np.asarray(pos),np.asarray(rr),maps)
        order=np.argsort(sc)[:min(topk,len(sc))]
        if active and len(order)>=2:
            preds=[];scores=[]
            for j in order:
                ap=ACTION_PERMS[int(bi[j])];preds.append(pred_for(dq,maps[j],ap));scores.append(sc[j])
            preds=np.stack(preds);scores=np.asarray(scores)
            tt=max(float(np.std(scores)),.02);w=np.exp(-(scores-scores.min())/(tt+1e-8));w/=w.sum()
            mu=(preds*w[:,None]).sum(0);var=((preds-mu[None])**2*w[:,None]).sum(0)
            if pos:var[np.asarray(pos,dtype=np.int64)]=-1
            p=int(np.argmax(var))
        else:p=int(rng.integers(256))
        pos.append(p);rr.append(trueq[lc.MAPS[tid][p]]+rng.normal(0,.08))
    sc,bi=score_candidates(dq,np.asarray(pos),np.asarray(rr),maps);j=int(np.argmin(sc));ap=ACTION_PERMS[int(bi[j])]
    pred=dq.reshape(64,4)[maps[j]][:,ap];tru=trueq[lc.MAPS[tid]].reshape(64,4)
    acc=float(np.mean(pred.argmax(1)==tru.argmax(1)))
    full=np.asarray([int(maps[j][s])*4+int(ap[a]) for s in range(64) for a in range(4)],dtype=np.int16)
    exact=float(np.array_equal(full,lc.MAPS[tid]))
    return acc,exact,float(sc[j]),j

def load_codec():
    ck=torch.load(os.path.join(HERE,'codec.pt'),map_location='cpu')
    m=lc.Codec(16);m.load_state_dict(ck['state_dict']);m.eval()
    for p in m.parameters():p.requires_grad=False
    return m

def evaluate(maps,codec,N,seeds=(1101,2202,3303,4404,5505,6606),tasks=20,label='induced',active=True):
    sp=lc.make_split(123);rows=[];t=time.time()
    for seed in seeds:
        rng=np.random.default_rng(seed);tg=torch.Generator();tg.manual_seed(seed+1)
        with torch.no_grad():
            q=lc.sample_q(tasks,torch.device('cpu'),tg).flatten(1);z=codec.encode(q,True);dq=codec.decode(z)
        qn=q.numpy();dn=dq.numpy()
        for i in range(tasks):
            tid=int(rng.choice(sp.held_both));acc,ex,mse,j=episode(dn[i],qn[i],tid,maps,N,seed*100000+i,active)
            rows.append({'library':label,'N':N,'seed':seed,'task':i,'policy_transfer':acc,'full_exact':ex,'ground_mse':mse,'chosen_operator':j})
        print('EVAL',label,'N',N,'seed',seed,'mean',np.mean([r['policy_transfer'] for r in rows if r['seed']==seed and r['N']==N and r['library']==label]),flush=True)
    return pd.DataFrame(rows)

def true_maps():
    sti={tuple(map(int,s)):i for i,s in enumerate(STATES_I)};out=[]
    for p,f in lc.OBS_TRANSFORMS:
        sm=[]
        for o in STATES_I:
            c=np.empty(4,dtype=np.int8)
            for k in range(4):c[p[k]]=int(o[k])*int(f[k])
            sm.append(sti[tuple(map(int,c))])
        out.append(np.asarray(sm,dtype=np.int16))
    return np.stack(out)

def main():
    out='/mnt/data/iap_gate1g_grammar_induction';os.makedirs(out,exist_ok=True)
    npzp=os.path.join(out,'induced_operators.npz')
    if os.path.exists(npzp):
        zz=np.load(npzp);Ws=zz['W'];maps=zz['state_maps'];disc=pd.read_csv(os.path.join(out,'discovery_curve.csv'))
        print('REUSE_DISCOVERY',len(maps),flush=True)
    else:
        Ws,maps,disc=discover();disc.to_csv(os.path.join(out,'discovery_curve.csv'),index=False)
    # compare only for audit; not used in discovery or grounding
    tm=true_maps();ts={tuple(map(int,x)) for x in tm};ds={tuple(map(int,x)) for x in maps}
    audit={'discovered_unique':len(ds),'true_symmetries_for_posthoc_audit':len(ts),'intersection_posthoc':len(ds&ts),'spurious_posthoc':len(ds-ts),'missed_posthoc':len(ts-ds),'hidden_transform_labels_used_in_discovery':False}
    print('AUDIT',audit,flush=True)
    gens,gidx,cl,gh=greedy_generators(maps,target=len(maps));gh.to_csv(os.path.join(out,'generator_closure.csv'),index=False)
    # verify closure equals discovered maps
    cs={tuple(map(int,x)) for x in cl};audit.update({'induced_generator_count':len(gens),'closure_size':len(cs),'closure_equals_discovered':cs==ds})
    np.savez_compressed(os.path.join(out,'induced_operators.npz'),W=Ws,state_maps=maps,generator_maps=gens,generator_indices=np.asarray(gidx),closure_maps=cl)
    # matrix structure diagnostic, post hoc only
    nearest=[]
    for W in Ws:
        nearest.append({'max_abs_entry':float(np.abs(W).max()),'orth_error':float(np.mean((W@W.T-np.eye(4))**2)),'integer_distance':float(np.mean(np.abs(W-np.round(W)))),'nonzero_rounded':int(np.count_nonzero(np.round(W)))})
    pd.DataFrame(nearest).to_csv(os.path.join(out,'operator_matrix_diagnostics.csv'),index=False)
    codec=load_codec();raw=[]
    for N in [8,12]:raw.append(evaluate(cl,codec,N,label='induced_3_generator_closure'))
    # control: equal-size random bijections, fixed across evaluation
    rng=np.random.default_rng(991);rmaps=np.stack([rng.permutation(64).astype(np.int16) for _ in range(len(cl))])
    for N in [8,12]:raw.append(evaluate(rmaps,codec,N,seeds=(1101,2202,3303),tasks=20,label='random_bijection_control'))
    raw=pd.concat(raw,ignore_index=True);raw.to_csv(os.path.join(out,'gate1g_raw.csv'),index=False)
    agg=raw.groupby(['library','N']).agg(tasks=('policy_transfer','size'),policy_transfer=('policy_transfer','mean'),policy_sd=('policy_transfer','std'),full_exact=('full_exact','mean'),ground_mse=('ground_mse','mean')).reset_index();agg.to_csv(os.path.join(out,'gate1g_aggregate.csv'),index=False)
    audit['remaining_scaffolding']=['generic orthogonal Procrustes/assignment manifold alignment','exact 4x4 action assignment','active disagreement querying','16-byte learned codec']
    audit['removed_scaffolding']=['hand-authored signed-permutation grammar','hand-authored 128 observation-transform vocabulary']
    open(os.path.join(out,'gate1g_audit.json'),'w').write(json.dumps(audit,indent=2))
    print('AGG\n',agg.to_string(index=False),flush=True);print('AUDIT_FINAL',json.dumps(audit,indent=2),flush=True)
if __name__=='__main__':main()
