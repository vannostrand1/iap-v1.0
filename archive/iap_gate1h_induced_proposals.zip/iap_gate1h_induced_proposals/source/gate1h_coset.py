import os,sys,math,time,json,random,itertools
import numpy as np,pandas as pd,torch
import torch.nn as nn, torch.nn.functional as F
HERE=os.path.dirname(__file__);sys.path.insert(0,HERE);import gate1g as g
ZZ=np.load('/mnt/data/work_gate1h/iap_gate1g_package/induced_operators.npz');DISC=ZZ['state_maps'].astype(np.int16);DW=ZZ['W'].astype(np.float32);GENS=ZZ['generator_maps'].astype(np.int16);ID=np.arange(64,dtype=np.int16)
def comp(a,b):return a[b]
def closure(gens):
 seen={tuple(ID.tolist()):ID.copy()};front=[ID.copy()]
 while front:
  x=front.pop()
  for gg in gens:
   for y in (comp(gg,x),comp(x,gg)):
    k=tuple(map(int,y))
    if k not in seen:seen[k]=y.copy();front.append(y.copy())
 return list(seen.values())
def left_reps(Hsmall,Hbig):
 unseen={tuple(map(int,x)):x for x in Hbig};R=[]
 while unseen:
  r=next(iter(unseen.values()));R.append(r.copy())
  for h in Hsmall:unseen.pop(tuple(map(int,comp(h,r))),None)
 return R
H1=closure([GENS[0]]);H2=closure([GENS[0],GENS[1]]);H3=closure(list(GENS));A=np.stack(H1);B=np.stack(left_reps(H1,H2));C=np.stack(left_reps(H2,H3));assert (len(A),len(B),len(C))==(8,8,2)
# induced coset normal form: a*b*c, 8x8x2 = 128 unique
TOKENS=[];MAPS=[]
for i,j,k in itertools.product(range(8),range(8),range(2)):
 TOKENS.append((i,j,k));MAPS.append(comp(comp(A[i],B[j]),C[k]))
TOKENS=np.asarray(TOKENS,np.int16);MAPS=np.stack(MAPS);assert len({tuple(map(int,x)) for x in MAPS})==128
WLOOK={tuple(map(int,m)):w for m,w in zip(DISC,DW)}
# Prefix -> leaves and symbolic possible-state mask, all derived from induced normal form
PREFIX={():np.arange(128,dtype=np.int64)}
for d in [1,2,3]:
 tmp={}
 for li,t in enumerate(TOKENS):tmp.setdefault(tuple(map(int,t[:d])),[]).append(li)
 for p,v in tmp.items():PREFIX[p]=np.asarray(v,dtype=np.int64)
PM={}
for p,ids in PREFIX.items():
 pm=np.zeros((64,64),bool)
 for li in ids:pm[np.arange(64),MAPS[li]]=True
 PM[p]=pm

def partial_map(prefix):
 if len(prefix)==0:return ID
 x=A[prefix[0]]
 if len(prefix)>1:x=comp(x,B[prefix[1]])
 if len(prefix)>2:x=comp(x,C[prefix[2]])
 return x

def candidate_tokens(prefix):return range([8,8,2][len(prefix)])
FD=16+4+16+3+16
class Net(nn.Module):
 def __init__(self,w=128):super().__init__();self.net=nn.Sequential(nn.Linear(FD,w),nn.GELU(),nn.Linear(w,w),nn.GELU(),nn.Linear(w,1))
 def forward(self,x):return self.net(x).squeeze(-1)

def partial_feature(dq,z,pos,r,prefix):
 pos=np.asarray(pos,np.int64);r=np.asarray(r,np.float32);si=pos//4;ao=pos%4;q=dq.reshape(64,4);pm=PM[prefix];per=np.full((len(pos),4),9,np.float32)
 for ii,s in enumerate(si):
  ids=np.flatnonzero(pm[int(s)])
  if len(ids):per[ii]=((q[ids]-r[ii])**2).min(0)
 cost=np.zeros((4,4),np.float32);cnt=np.zeros(4,np.float32)
 for a in range(4):
  m=ao==a;cnt[a]=m.sum()
  if np.any(m):cost[a]=per[m].sum(0)
 den=np.maximum(cnt[:,None],1);cn=cost/den;sc=max(float(cn.mean()),.02);cn/=sc;vals=[]
 for ap in g.ACTION_PERMS:vals.append(sum(cost[a,ap[a]] for a in range(4)))
 lb=min(vals)/max(1,len(pos));pmmap=partial_map(prefix);W=WLOOK[tuple(map(int,pmmap))].reshape(-1);meta=np.asarray([len(prefix)/3.0,math.log1p(lb),len(PREFIX[prefix])/128.0],np.float32)
 return np.concatenate([cn.reshape(-1),cnt/max(float(cnt.sum()),1),W,meta,np.asarray(z,np.float32).reshape(-1)]).astype(np.float32)

def leaf(prefix):
 ids=PREFIX[prefix];return int(ids[0]) if len(ids)==1 else None

def softmax_np(x,t):x=np.asarray(x,np.float64)/max(t,1e-5);x-=x.max();p=np.exp(x);return p/p.sum()
def sample(net,dq,z,pos,r,rng,temp,eps,cache):
 p=()
 for d in range(3):
  if p not in cache:
   ts=list(candidate_tokens(p));fe=np.stack([partial_feature(dq,z,pos,r,p+(t,)) for t in ts]);
   with torch.no_grad():lo=net(torch.tensor(fe)).numpy()
   cache[p]=(ts,softmax_np(lo,temp))
  ts,pp=cache[p];pr=(1-eps)*pp+eps/len(pp);t=int(rng.choice(ts,p=pr));p=p+(t,)
 return leaf(p),p

def mutate(p,rng):
 q=list(p);d=int(rng.integers(3));q[d]=int(rng.integers([8,8,2][d]));q=tuple(q);return leaf(q),q

def population(net,dq,z,pos,r,rng,K,temp,eps):
 cache={};cand={};n0=max(10,int(K*.7))
 for _ in range(n0):li,p=sample(net,dq,z,pos,r,rng,temp,eps,cache);cand[li]=p
 seeds=list(cand.values());tries=0
 while len(cand)<K and tries<K*10:
  tries+=1
  if seeds and rng.random()<.8:li,p=mutate(seeds[int(rng.integers(len(seeds)))],rng)
  else:li,p=sample(net,dq,z,pos,r,rng,temp,1.0,cache)
  cand[li]=p
 ids=np.asarray(list(cand),np.int64);sc,bi=g.score_candidates(dq,pos,r,MAPS[ids]);return sorted([(float(s),int(i),cand[int(i)]) for s,i in zip(sc,ids)],key=lambda x:x[0]),len(ids)

def groups_from(pop,dq,z,pos,r):
 score={tuple(p):s for s,li,p in pop};parents={()}
 for s,li,p in pop:
  parents.add((p[0],));parents.add((p[0],p[1]))
 out=[]
 for parent in parents:
  vals=[];ts=[]
  for t in candidate_tokens(parent):
   ch=parent+(int(t),);vv=[s for p,s in score.items() if p[:len(ch)]==ch]
   if vv:ts.append(int(t));vals.append(min(vv))
  if len(vals)<2:continue
  fe=np.stack([partial_feature(dq,z,pos,r,parent+(t,)) for t in ts]);vals=np.asarray(vals,np.float32);spread=max(float(np.std(vals)),.02);ta=softmax_np(-(vals-vals.min()),.35*spread+.01).astype(np.float32);out.append((fe,ta,vals))
 return out

def train_groups(net,groups,rng,epochs=3,lr=1e-3):
 opt=torch.optim.AdamW(net.parameters(),lr=lr,weight_decay=1e-5);L=Aa=0
 for ep in range(epochs):
  order=rng.permutation(len(groups));opt.zero_grad();acc=0;ls=[];acs=[]
  for ii in order:
   fe,ta,v=groups[int(ii)];log=net(torch.tensor(fe));loss=-(torch.tensor(ta)*F.log_softmax(log,dim=0)).sum();(loss/48).backward();ls.append(float(loss.detach()));acs.append(float(int(log.argmax())==int(np.argmin(v))));acc+=1
   if acc==48:nn.utils.clip_grad_norm_(net.parameters(),5);opt.step();opt.zero_grad();acc=0
  if acc:nn.utils.clip_grad_norm_(net.parameters(),5);opt.step();opt.zero_grad()
  L=float(np.mean(ls));Aa=float(np.mean(acs))
 return L,Aa

def train(rounds=8,B=100,K=20,seed=55331):
 torch.set_num_threads(4);torch.manual_seed(seed);rng=np.random.default_rng(seed);tg=torch.Generator();tg.manual_seed(seed+1);sp=g.lc.make_split(123);codec=g.load_codec();net=Net();rows=[];curr=[(12,16),(8,12,16),(6,8,12,16),(4,6,8,12),(2,4,6,8,12),(2,4,6,8,12,16)]
 for rd in range(rounds):
  with torch.no_grad():q=g.lc.sample_q(B,torch.device('cpu'),tg).flatten(1);z=codec.encode(q,True);dq=codec.decode(z)
  qn=q.numpy();zn=z.numpy();dn=dq.numpy();gr=[];best=[];sizes=[];eps=max(.08,.62-.07*rd);temp=max(.68,1.5-.09*rd);Ns=curr[min(rd,len(curr)-1)]
  for b in range(B):
   N=int(Ns[b%len(Ns)]);tid=int(rng.choice(sp.train));pos=rng.integers(0,256,size=N);rr=qn[b][g.lc.MAPS[tid][pos]]+rng.normal(0,.08,size=N);pop,sz=population(net,dn[b],zn[b],pos,rr,rng,K,temp,eps);gr.extend(groups_from(pop,dn[b],zn[b],pos,rr));best.append(pop[0][0]);sizes.append(sz)
  loss,acc=train_groups(net,gr,rng,3,1.4e-3 if rd<3 else 8e-4);row={'round':rd+1,'tasks':B,'K_cap':K,'fraction_language_scored':K/128,'groups':len(gr),'epsilon':eps,'temperature':temp,'mean_best_sampled_mse':float(np.mean(best)),'sampled_choice_acc':acc,'train_loss':loss};rows.append(row);print('ROUND',json.dumps(row),flush=True)
 torch.save(net.state_dict(),'/mnt/data/gate1h_coset_net.pt');pd.DataFrame(rows).to_csv('/mnt/data/gate1h_coset_training.csv',index=False);return net,codec

def beam(net,dq,z,pos,r,BM=16):
 beams=[(0.0,())]
 for d in range(3):
  nxt=[]
  for nlp,p in beams:
   ts=list(candidate_tokens(p));fe=np.stack([partial_feature(dq,z,pos,r,p+(t,)) for t in ts]);
   with torch.no_grad():lo=net(torch.tensor(fe)).numpy();pr=softmax_np(lo,1.0)
   for t,v in zip(ts,pr):nxt.append((nlp-math.log(max(float(v),1e-9)),p+(int(t),)))
  nxt.sort(key=lambda x:x[0]);beams=nxt[:BM]
 return [(nlp,leaf(p)) for nlp,p in beams]

def episode(net,dq,z,trueq,tid,N,seed,BM=16,start=2):
 rng=np.random.default_rng(seed);pos=[];rr=[];seen=set()
 for _ in range(start):p=int(rng.integers(256));pos.append(p);rr.append(trueq[g.lc.MAPS[tid][p]]+rng.normal(0,.08))
 while len(pos)<N:
  prop=beam(net,dq,z,pos,rr,BM);ids=np.asarray([j for _,j in prop],np.int64);seen.update(ids.tolist());sc,bi=g.score_candidates(dq,pos,rr,MAPS[ids]);order=np.argsort(sc)[:min(12,len(ids))];pred=[];ss=[]
  for o in order:pred.append(g.pred_for(dq,MAPS[ids[o]],g.ACTION_PERMS[int(bi[o])]));ss.append(sc[o])
  pred=np.stack(pred);ss=np.asarray(ss);tt=max(float(np.std(ss)),.02);w=np.exp(-(ss-ss.min())/(tt+1e-8));w/=w.sum();mu=(pred*w[:,None]).sum(0);var=((pred-mu[None])**2*w[:,None]).sum(0);var[np.asarray(pos,int)]=-1;p=int(np.argmax(var));pos.append(p);rr.append(trueq[g.lc.MAPS[tid][p]]+rng.normal(0,.08))
 prop=beam(net,dq,z,pos,rr,BM);ids=np.asarray([j for _,j in prop],np.int64);seen.update(ids.tolist());sc,bi=g.score_candidates(dq,pos,rr,MAPS[ids]);o=int(np.argmin(sc));j=int(ids[o]);ap=g.ACTION_PERMS[int(bi[o])];pred=dq.reshape(64,4)[MAPS[j]][:,ap];tru=trueq[g.lc.MAPS[tid]].reshape(64,4);acc=float(np.mean(pred.argmax(1)==tru.argmax(1)));full=np.asarray([int(MAPS[j][s])*4+int(ap[a]) for s in range(64) for a in range(4)],np.int16);ex=float(np.array_equal(full,g.lc.MAPS[tid]));return acc,ex,len(seen),float(sc[o])

def evaluate(net,codec,N,BM=16,seeds=(1101,2202,3303,4404,5505,6606),tasks=20):
 sp=g.lc.make_split(123);rows=[]
 for seed in seeds:
  rng=np.random.default_rng(seed);tg=torch.Generator();tg.manual_seed(seed+1)
  with torch.no_grad():q=g.lc.sample_q(tasks,torch.device('cpu'),tg).flatten(1);z=codec.encode(q,True);dq=codec.decode(z)
  qn=q.numpy();zn=z.numpy();dn=dq.numpy()
  for i in range(tasks):tid=int(rng.choice(sp.held_both));a,e,u,m=episode(net,dn[i],zn[i],qn[i],tid,N,seed*100000+i,BM);rows.append({'N':N,'beam':BM,'seed':seed,'task':i,'policy_transfer':a,'full_exact':e,'unique_scored':u,'ground_mse':m})
  print('EVAL',N,BM,seed,np.mean([r['policy_transfer'] for r in rows if r['seed']==seed]),flush=True)
 return pd.DataFrame(rows)

def main():
 net,codec=train();raw=[]
 for BM in [12,16,20]:
  for N in [8,12]:raw.append(evaluate(net,codec,N,BM))
 df=pd.concat(raw,ignore_index=True);df.to_csv('/mnt/data/gate1h_coset_raw.csv',index=False);agg=df.groupby(['beam','N']).agg(tasks=('policy_transfer','size'),policy_transfer=('policy_transfer','mean'),full_exact=('full_exact','mean'),unique_scored=('unique_scored','mean'),ground_mse=('ground_mse','mean')).reset_index();agg.to_csv('/mnt/data/gate1h_coset_aggregate.csv',index=False);print(agg.to_string(index=False))
if __name__=='__main__':main()
