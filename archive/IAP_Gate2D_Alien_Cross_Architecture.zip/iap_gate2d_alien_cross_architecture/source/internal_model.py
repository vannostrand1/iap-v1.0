"""Train existing fly-derived connections with fixed input and motor mappings.

This is a normalized, leaky tanh rate-model experiment, not the Eon LIF model.
An edge's sign is preserved; its positive gain is the only trainable quantity.
"""
from pathlib import Path
import hashlib
import numpy as np
from scipy import sparse
import torch
from torch import nn
from torch.nn import functional as F


class InternalFly(nn.Module):
    def __init__(self,graph_path,seed=0,inputs=3,actions=2,n=256,steps=6):
        super().__init__()
        graph=sparse.load_npz(graph_path).tocsr()[:n,:n].copy()
        graph.sum_duplicates(); graph.eliminate_zeros()
        row,col=graph.nonzero()
        base=graph.data.astype(np.float32)
        norm=np.asarray(abs(graph).sum(1)).ravel().astype(np.float32)
        base=base/np.maximum(1.,norm[row])*.9
        rng=np.random.default_rng(seed)
        permutation=rng.permutation(n)
        sensory=permutation[:min(n//3,inputs*8)]
        motor=permutation[n//2:n//2+actions*8].reshape(actions,8)
        drive=np.zeros((inputs,n),np.float32)
        for k,node in enumerate(sensory): drive[k%inputs,node]=3.
        decode=np.zeros((n,actions),np.float32)
        for a,nodes in enumerate(motor): decode[nodes,a]=4./len(nodes)
        self.n=n; self.steps=steps; self.actions=actions; self.inputs=inputs
        self.register_buffer('edge_flat',torch.from_numpy((row*n+col).astype(np.int64)))
        self.register_buffer('base',torch.from_numpy(base))
        self.register_buffer('drive',torch.from_numpy(drive))
        self.register_buffer('decode',torch.from_numpy(decode))
        self.log_gain=nn.Parameter(torch.zeros(len(base)))

    def weights(self):
        values=self.base*torch.exp(self.log_gain.clamp(-3.,3.))
        return torch.zeros(self.n*self.n,device=values.device).scatter(0,self.edge_flat,values).reshape(self.n,self.n)

    def forward(self,x):
        if x.ndim==1: x=x[None,:]
        w=self.weights()
        current=x @ self.drive
        h=torch.zeros((len(x),self.n),device=x.device)
        for _ in range(self.steps): h=.5*h+.5*torch.tanh(h @ w.T+current)
        return h @ self.decode

    def project(self):
        with torch.no_grad(): self.log_gain.clamp_(-3.,3.)

    def fingerprint(self):
        digest=hashlib.sha256()
        for key,value in self.state_dict().items():
            digest.update(key.encode());digest.update(value.detach().cpu().numpy().tobytes())
        return digest.hexdigest()


class MLPControl(nn.Module):
    def __init__(self,inputs=3,actions=2,width=64):
        super().__init__()
        self.network=nn.Sequential(nn.Linear(inputs,width),nn.Tanh(),nn.Linear(width,actions))
    def forward(self,x): return self.network(x)
    def project(self): pass
