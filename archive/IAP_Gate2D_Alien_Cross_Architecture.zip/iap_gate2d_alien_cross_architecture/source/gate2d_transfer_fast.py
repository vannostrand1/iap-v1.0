import sys,json,time
from pathlib import Path
import numpy as np
sys.path.insert(0,'/mnt/data')
import gate2d_work as g

def run_one(direction,rep):
    teacher,student,pfn,budget = ('transformer','fly',g.TR_P,512) if direction=='t2f' else ('fly','transformer',g.FLY_P,256)
    seed=440000+(0 if direction=='t2f' else 10000)+rep
    true=g.true_alien_transform(np.random.default_rng(seed))
    gg=g.autonomous_ground(pfn,true,budget=16,seed=seed+1)
    iq=g.identity_q(pfn,true); ip=iq.argmax(1); ident_acc=float(np.mean(ip==true['tgt'])); ident_seq=float(np.mean([np.all(ip[c*3:c*3+3]==true['tgt'][c*3:c*3+3]) for c in range(8)]))
    if student=='fly':
        flyseed=7102 if rep%2==0 else 7103;m=g.make_student('fly',seed+10,flyseed)
    else:
        flyseed=None;m=g.make_student('transformer',seed+10)
    t=time.time();cp=g.absorb_alien(m,true['Y'],gg['q'],true['tgt'],seed+99,budget);elapsed=time.time()-t
    return {'teacher':teacher,'student':student,'rep':rep,'calibration_queries':16,'ground_policy_acc':gg['policy_acc'],'ground_sequence_acc':gg['sequence_acc'],'survivors':gg['survivors'],'identity_packet_policy_acc':ident_acc,'identity_packet_sequence_acc':ident_seq,'final_action_acc':cp[budget][0],'final_sequence_acc':cp[budget][1],'checkpoints':{str(k):list(v) for k,v in cp.items()},'alien_perm':true['perm'].tolist(),'alien_sign':true['sign'].tolist(),'alien_action_swap':true['swap'],'flyseed':flyseed,'absorb_seconds':elapsed}

if __name__=='__main__':
    direction=sys.argv[1]; reps=[int(x) for x in sys.argv[2:]]
    out=[]
    for r in reps:
        x=run_one(direction,r);out.append(x);print(json.dumps(x),flush=True)
    p=Path(f'/mnt/data/gate2d_results/{direction}_{reps[0]}_{reps[-1]}.json');p.write_text(json.dumps(out,indent=2))
