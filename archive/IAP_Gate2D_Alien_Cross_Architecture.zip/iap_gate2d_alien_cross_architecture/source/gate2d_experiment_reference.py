import itertools, struct, json, hashlib, time, sys
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F

PKG=Path('/mnt/data/gate2d_src/extracted/iap_gate2c_cross_architecture')
sys.path.insert(0,str(PKG/'source'))
import cross_architecture_core as core

# ----- packet decoder -----
def load_packet(path):
    raw=Path(path).read_bytes()
    assert raw[:7]==b'IAPCV2\0' and len(raw)==97
    scales=struct.unpack('<4f',raw[7:23])
    off=23
    w1=np.frombuffer(raw[off:off+48],dtype=np.int8).astype(np.float32).reshape(8,6)*scales[0]; off+=48
    b1=np.frombuffer(raw[off:off+8],dtype=np.int8).astype(np.float32)*scales[1]; off+=8
    w2=np.frombuffer(raw[off:off+16],dtype=np.int8).astype(np.float32).reshape(2,8)*scales[2]; off+=16
    b2=np.frombuffer(raw[off:off+2],dtype=np.int8).astype(np.float32)*scales[3]
    def f(x):
        x=np.asarray(x,dtype=np.float32)
        return np.tanh(x@w1.T+b1)@w2.T+b2
    return raw,f

FLY_RAW,FLY_P=load_packet(PKG/'packets/fly_teacher_97b.iap')
TR_RAW,TR_P=load_packet(PKG/'packets/transformer_teacher_97b.iap')
ST=core.ST.astype(np.float32); TY=core.TY.astype(np.int64)

# Generic signed-permutation hypothesis class over all 6 coordinates.
PERMS=np.array(list(itertools.permutations(range(6))),dtype=np.int8) # candidate canonical dim k <- alien dim perms[k]
SIGNS=np.array(list(itertools.product([-1.,1.],repeat=6)),dtype=np.float32)
C_INVPERM=np.repeat(PERMS,len(SIGNS),axis=0)
C_INVSIGN=np.tile(SIGNS,(len(PERMS),1))
NOBS=len(C_INVPERM)


def true_alien_transform(rng):
    # y[j] = s[j] * x[perm[j]]
    perm=rng.permutation(6).astype(np.int64)
    sign=rng.choice(np.array([-1.,1.],dtype=np.float32),size=6)
    swap=int(rng.integers(2))
    Y=ST[:,perm]*sign[None,:]
    tgt=TY ^ swap
    invp=np.empty(6,dtype=np.int64); invs=np.empty(6,dtype=np.float32)
    for j,k in enumerate(perm):
        invp[k]=j; invs[k]=sign[j]
    return {'perm':perm,'sign':sign,'swap':swap,'Y':Y.astype(np.float32),'tgt':tgt,'invperm':invp,'invsign':invs}


def candidate_q(packet_fn,Y,chunk=2048):
    out=np.empty((NOBS,24,2),dtype=np.float32)
    for a in range(0,NOBS,chunk):
        b=min(a+chunk,NOBS)
        invp=C_INVPERM[a:b].astype(np.int64)
        s=C_INVSIGN[a:b]
        # x_cand[c,state,k] = sign[c,k] * y[state, invperm[c,k]]
        vals=np.take(Y,invp,axis=1) # (24,c,6)
        vals=np.transpose(vals,(1,0,2))*s[:,None,:]
        flat=vals.reshape(-1,6)
        out[a:b]=packet_fn(flat).reshape(b-a,24,2)
    return out


def autonomous_ground(packet_fn,true,budget=12,seed=0,max_ensemble=4096):
    Y=true['Y']; tgt=true['tgt']; rng=np.random.default_rng(seed)
    qtab=candidate_q(packet_fn,Y)
    pred=np.argmax(qtab,axis=2).astype(np.int8) # obs_candidate, state
    # survivor mask obs_candidate x action_swap
    surv=np.ones((NOBS,2),dtype=bool)
    queried=[]
    for t in range(budget):
        # disagreement across surviving full hypotheses
        oi,sw=np.nonzero(surv)
        if len(oi)==0: raise RuntimeError('no surviving hypotheses')
        # sample if huge to speed query selection, exact update remains exact
        if len(oi)>20000:
            sel=rng.choice(len(oi),20000,replace=False); ois=oi[sel]; sws=sw[sel]
        else: ois=oi;sws=sw
        pp=pred[ois] ^ sws[:,None]
        frac=pp.mean(axis=0)
        score=0.5-np.abs(frac-0.5)
        for q in queried: score[q]=-1
        sidx=int(np.argmax(score))
        queried.append(sidx)
        true_pref=int(tgt[sidx])
        # one reward query: take alien action 0. reward sign directly tells preferred action.
        reward=1 if true_pref==0 else -1
        cand_pref=pred[:,sidx,None] ^ np.array([0,1],dtype=np.int8)[None,:]
        surv &= (cand_pref==true_pref)
    oi,sw=np.nonzero(surv)
    if len(oi)==0: raise RuntimeError('no survivors final')
    if len(oi)>max_ensemble:
        sel=rng.choice(len(oi),max_ensemble,replace=False); oi=oi[sel];sw=sw[sel]
    # posterior mean culture target in local action coordinates
    qq=qtab[oi].copy()
    flip=(sw==1)
    qq[flip]=qq[flip][:,:,::-1]
    meanq=qq.mean(axis=0)
    policy=meanq.argmax(1)
    return {
        'q':meanq.astype(np.float32),
        'policy_acc':float(np.mean(policy==tgt)),
        'sequence_acc':float(np.mean([np.all(policy[c*3:c*3+3]==tgt[c*3:c*3+3]) for c in range(8)])),
        'survivors':int(surv.sum()),
        'ensemble':int(len(oi)),
        'queries':queried,
    }


def oracle_q(packet_fn,true):
    x=true['Y'][:,true['invperm']]*true['invsign'][None,:]
    q=packet_fn(x)
    if true['swap']: q=q[:,::-1]
    return q.astype(np.float32)


def identity_q(packet_fn,true):
    return packet_fn(true['Y']).astype(np.float32)


def alien_metrics(model,Y,tgt):
    model.eval();
    with torch.no_grad(): p=model(torch.tensor(Y)).argmax(1).cpu().numpy()
    seq=[np.all(p[c*3:c*3+3]==tgt[c*3:c*3+3]) for c in range(8)]
    return float(np.mean(p==tgt)),float(np.mean(seq))


def make_student(kind,seed,flyseed=None):
    torch.manual_seed(seed)
    if kind=='transformer': return core.FeatureTransformer()
    if kind=='mlp': return core.MLP()
    if kind=='fly': return core.InternalFly(core.GRAPHS[flyseed],flyseed,inputs=6,actions=2)
    raise ValueError(kind)


def absorb_alien(model,Y,target_q,tgt,seed,budget,lr=None):
    if lr is None: lr=.03 if isinstance(model,core.InternalFly) else .01
    opt=torch.optim.Adam(model.parameters(),lr=lr);rng=np.random.default_rng(seed);buf=[]
    cps={0:alien_metrics(model,Y,tgt)}
    checks=sorted(set([32,64,128,256,512,768,budget]))
    for i in range(1,budget+1):
        idx=int(rng.integers(24));buf.append((Y[idx].copy(),target_q[idx].copy()))
        ids=rng.integers(len(buf),size=min(32,len(buf)))
        xs=torch.tensor(np.stack([buf[j][0] for j in ids])); ts=torch.tensor(np.stack([buf[j][1] for j in ids]))
        loss=F.mse_loss(model(xs),ts);opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
        if hasattr(model,'project'):model.project()
        if i in checks and i<=budget:cps[i]=alien_metrics(model,Y,tgt)
    return cps


def grounding_sweep():
    rows=[]
    for teacher,pfn in [('fly',FLY_P),('transformer',TR_P)]:
      for b in [4,8,12,16]:
       for r in range(40):
        seed=100000+(0 if teacher=='fly' else 50000)+b*100+r
        true=true_alien_transform(np.random.default_rng(seed))
        g=autonomous_ground(pfn,true,budget=b,seed=seed+7)
        rows.append({'teacher':teacher,'budget':b,'rep':r,'policy_acc':g['policy_acc'],'sequence_acc':g['sequence_acc'],'survivors':g['survivors']})
       sub=[x for x in rows if x['teacher']==teacher and x['budget']==b]
       print('ground',teacher,b,np.mean([x['policy_acc'] for x in sub]),np.mean([x['sequence_acc'] for x in sub]),'surv',np.median([x['survivors'] for x in sub]),flush=True)
    return rows


def transfer_runs():
    rows=[]
    directions=[('transformer','fly',TR_P,768),('fly','transformer',FLY_P,256)]
    for teacher,student,pfn,budget in directions:
      for rep in range(6):
        seed=220000+(0 if teacher=='transformer' else 50000)+rep
        true=true_alien_transform(np.random.default_rng(seed))
        g=autonomous_ground(pfn,true,budget=12,seed=seed+1)
        oq=oracle_q(pfn,true); iq=identity_q(pfn,true)
        conditions=[('autonomous',g['q']),('oracle',oq),('ungrounded_identity',iq)]
        for cond,tq in conditions:
          if student=='fly':
            # alternate the two recipient graph substructures; exposure seed differs by rep
            flyseed=7102 if rep%2==0 else 7103
            m=make_student('fly',seed+10,flyseed)
          else:
            flyseed=None;m=make_student(student,seed+10)
          cp=absorb_alien(m,true['Y'],tq,true['tgt'],seed+99,budget)
          fin=cp[budget]
          row={'teacher':teacher,'student':student,'rep':rep,'condition':cond,'calibration_queries':12,'ground_policy_acc':g['policy_acc'] if cond=='autonomous' else (1.0 if cond=='oracle' else float(np.mean(iq.argmax(1)==true['tgt']))),'ground_sequence_acc':g['sequence_acc'] if cond=='autonomous' else (1.0 if cond=='oracle' else float(np.mean([np.all(iq.argmax(1)[c*3:c*3+3]==true['tgt'][c*3:c*3+3]) for c in range(8)]))),'survivors':g['survivors'] if cond=='autonomous' else None,'final_action_acc':fin[0],'final_sequence_acc':fin[1],'checkpoints':{str(k):list(v) for k,v in cp.items()},'alien_perm':true['perm'].tolist(),'alien_sign':true['sign'].tolist(),'alien_action_swap':true['swap'],'flyseed':flyseed}
          rows.append(row)
          print(teacher,'->',student,rep,cond,'ground',row['ground_policy_acc'],row['ground_sequence_acc'],'final',fin,flush=True)
    return rows

if __name__=='__main__':
    out=Path('/mnt/data/gate2d_results');out.mkdir(exist_ok=True)
    gr=grounding_sweep(); (out/'grounding_raw.json').write_text(json.dumps(gr,indent=2))
    tr=transfer_runs(); (out/'transfer_raw.json').write_text(json.dumps(tr,indent=2))
    # aggregate
    agg=[]
    for teacher,student in [('transformer','fly'),('fly','transformer')]:
      for cond in ['autonomous','oracle','ungrounded_identity']:
        sub=[r for r in tr if r['teacher']==teacher and r['student']==student and r['condition']==cond]
        agg.append({'teacher':teacher,'student':student,'condition':cond,'n':len(sub),'mean_ground_policy_acc':float(np.mean([r['ground_policy_acc'] for r in sub])),'mean_final_action_acc':float(np.mean([r['final_action_acc'] for r in sub])),'mean_final_sequence_acc':float(np.mean([r['final_sequence_acc'] for r in sub])),'perfect_replicates':int(sum(r['final_action_acc']==1 and r['final_sequence_acc']==1 for r in sub))})
    (out/'aggregate.json').write_text(json.dumps(agg,indent=2))
    print('AGG',json.dumps(agg,indent=2),flush=True)
